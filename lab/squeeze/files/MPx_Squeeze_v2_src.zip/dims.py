"""MPx Squeeze v2 ("Mini") — single source of truth (mm).
Axis along x; x = 0 at the bottle-side face of the inlet cap; flow +x:
bottle -> built-in prefilter cup (outside-in, sits inside the bottle neck) -> chamber above the disc -> removable disc
cassette (top-down) -> drainage ribs -> stem -> push-pull spout.
All metal parts 316L; seals food-grade silicone (FDA 21 CFR 177.2600)."""
import math
SS_RHO = 8.0e-3          # g/mm3, 316L
SINT_DENS = 0.62         # sintered media relative density

# ---- bottle interface (unchanged from v1): 28 mm PCO 1881
PCO = dict(T=27.40, T_tol=0.13, E=25.0, I=21.7, F=17.0, pitch=2.7)
PCO_F = dict(major=28.4, minor=26.0)

# ---- P01 inlet cap
CAP = dict(collar_D=32.4, collar_x=(0.0, 15.5), pco_depth=15.5, web=(15.5, 18.0), bore=15.0,     # Ø15 H7 for prefilter collar
           OD=52.0, flare_x=(15.5, 15.5), roof=18.0, land=19.5, land_r=(20.0, 22.6),
           groove=dict(r=(20.25, 21.75), depth=1.15),                                          # O-ring S2 face groove in the land
           relief_D=48.4, relief_x=(19.5, 21.0), thread="M48×1.0-6H", thread_x=(21.0, 28.7), x1=28.7,
           ribs=dict(n=8, w=1.2, h=2.3, r=(7.5, 19.0)))                                        # roof ribs: back-support for the disc in backflush
# ---- P02 prefilter cup (built in): sintered 316L laminate, 20 µm Dutch weave on 0.5 mm perforated support
PF = dict(OD=17.0, wall=0.7, x_tip=-12.5, x_open=15.5, collar_OD=15.0, collar_bore=12.0, collar_x=(14.8, 18.0), flange_D=17.0,
          rating="20 µm", media="316L 2-layer sintered laminate: 20 µm Dutch-weave + 0.5 mm perforated plate (Ø1.5 holes, 40 % open)")
# ---- P03 disc cassette (removable): disc laser-welded into a 316L frame
CAS = dict(OD=45.0, t=2.4, lip_ID=38.5, lip_t=0.8, disc_D=40.0, disc_t=1.6, x0=19.5)       # x0 = top (dirty) face in assembly
CAS["x1"] = CAS["x0"] + CAS["t"]
# ---- P04 base + spout stem
BASE = dict(OD_thread=48.0, thread="M48×1.0-6g", thread_x=(21.0, 28.7), relief_D=47.0, rim_x=19.9, pocket_D=45.2,
            seat_x=CAS["x0"] + CAS["t"], s3_groove=dict(r=(20.25, 21.75), depth=1.15),
            drain_D=38.0, drain_depth=0.8, floor=2.0, flange_D=52.0, flange_x=(29.0, 32.0), cup_ID=44.0, hub_D=12.0,
            ribs=dict(n=8, w=1.2), stem_thread="M12×1.0-6g", st_x=(32.0, 37.0), stem_D=9.0, stem_x=(37.0, 46.0),
            bore=3.0, port=2.0, port_x=44.5, pin_D=3.5, pin_x=(46.0, 49.5), groove=42.5, pin_groove=48.0, clip_x=37.8)
BASE["drain_x"] = (BASE["seat_x"], BASE["seat_x"] + BASE["drain_depth"])
BASE["floor_x"] = (BASE["drain_x"][1], BASE["drain_x"][1] + BASE["floor"])
# ---- P05 push-pull sleeve (closed position)
SL = dict(OD=12.0, bore=9.0, x=(37.0, 50.0), outlet=3.55, travel=4.0)
X_TIP = SL["x"][1]
# ---- accessories (own coordinates)
TAP = dict(L=44.0, D=27.0, bore=20.0, bore_depth=31.0, tap_thread="M22×1.0-6H", thread_x=(34.0, 44.0))   # P10 (prefilter fits its bore)
BF = dict(L=40.0, D=34.0, pco="28 PCO 1881 internal", stem="M12×1.0-6H", cavity=(14.5, 15.0))           # P13 backflush coupler
HOLD = dict(D=56.0, H=6.0, pocket_D=45.4, pocket_depth=3.0, glass="borosilicate cover glass Ø50 × 0.17")  # P14 inspection holder

# ---- seals
SEALS = [  # (id, type, where, size, qty, side)
    ("S1", "flat gasket", "bottle lip on P01 web; P10, P13", "Ø25.5/Ø19 × 1.5", 1, "dirty"),
    ("S2", "O-ring", "P01 land on cassette top face", "40.5 × 1.5", 1, "dirty"),
    ("S3", "O-ring", "P04 seat under cassette", "40.5 × 1.5", 1, "clean"),
    ("S4", "O-ring", "spout stem, sleeve seal", "7 × 1.5", 1, "clean"),
    ("S5", "O-ring", "plug pin in sleeve outlet", "2.5 × 1.0", 1, "clean"),
    ("S6", "flat washer", "tap face in P10; P12 ferrule", "Ø22/Ø16 × 2", 2, "dirty"),
    ("S7", "O-ring", "P13 coupler on stem thread shoulder", "10 × 1.5", 1, "backflush"),
]

# ---- media and flow model (same physics as the v1 bench model)
MU = 0.89e-3
def permeance_LMH_bar(KLt_mm):
    """Mott liquid formula dP[psid] = KL * flux[gpm/ft2] * visc[cP] * t[in]; KLt = KL x thickness (mm)."""
    return 1.0 / (KLt_mm * 0.89 / 25.4) * 2444.9 * 14.504
def Rm(KLt): return 1 / (MU * permeance_LMH_bar(KLt) / 1000 / 3600 / 1e5)

ASYM_GAIN = 3.0          # design value; GKN SIKA-R AS brochure claims "up to 4x" vs a symmetric element
CASSETTES = {
    "A": dict(name="Cassette A · fine (analysis)", media="asymmetric sintered 316L: ~0.2 mm fine layer on 1.4 mm coarse support",
              rating="≈1 µm (vendor to confirm, e.g. GKN SIKA-R 1 AS class)", KLt=26 * 1.5 / ASYM_GAIN, d50=0.75, k=10),
    "B": dict(name="Cassette B · catalogue fine", media="symmetric sintered 316L powder, media grade 0.2, 1.6 mm (off-the-shelf disc)",
              rating="≈1.4 µm absolute", KLt=26.0 * 1.6, d50=0.85, k=12),
    "C": dict(name="Cassette C · budget fast", media="symmetric sintered 316L powder, media grade 0.5, 1.6 mm",
              rating="≈2.5 µm (supplier to confirm)", KLt=8.0 * 1.6, d50=1.5, k=12),
}
def disc_area_m2(): return math.pi / 4 * CAS["lip_ID"] ** 2 / 1e6
def prefilter_area_cm2():
    L = PF["x_open"] - PF["x_tip"]
    return (math.pi * PF["OD"] * L + math.pi / 4 * PF["OD"] ** 2) / 100
def squeeze_bar(F, Aeff=34e-4, Fwall=4.0, level=1.0, body=120):
    return (max(0.0, F - Fwall) / Aeff + 1000 * 9.81 * (0.03 + level * body / 1000 * 0.8)) / 1e5
def flow_Lmin(bar, KLt, Rc=0.0):
    return disc_area_m2() * bar * 1e5 / (MU * (Rm(KLt) + Rc)) * 6e4
def force_for(Q, KLt):
    dP = Q / 6e4 * MU * Rm(KLt) / disc_area_m2()
    return (dP - squeeze_bar(0) * 1e5) * 34e-4 + 4.0
ALPHA = 1e13             # m/kg cake specific resistance (assumption, same as v1 bench)
C_TAP = 0.5e-3           # kg/m3 suspended solids > 1 µm in tap water (assumption)
PREFILTER_MASS_CUT = 0.4 # share of solids mass the 20 µm prefilter keeps off the disc (assumption, bench test 3)
def litres_to_half(KLt, prefilter=True):
    c = C_TAP * 0.9 * ((1 - PREFILTER_MASS_CUT) if prefilter else 1)
    return Rm(KLt) * disc_area_m2() / ALPHA / c * 1000
def capture(d, cas): return 1 / (1 + (cas["d50"] / d) ** cas["k"])
def hoop_SF(P_bar, r=24.0, t=1.6, yield_MPa=170):        # thinnest pressure wall: cap skirt under the thread
    return yield_MPa / (P_bar * 0.1 * r / t)

OVERALL_L = X_TIP                 # outside the bottle
INSIDE_BOTTLE = -PF["x_tip"]      # prefilter projection into the neck
MAX_D = CAP["OD"]

if __name__ == "__main__":
    print(f"disc active area {disc_area_m2()*1e4:.2f} cm2; prefilter area {prefilter_area_cm2():.1f} cm2")
    print(f"envelope: Ø{MAX_D:g} x {OVERALL_L:g} mm outside the bottle (+{INSIDE_BOTTLE:g} mm prefilter inside the neck)")
    p60 = squeeze_bar(60)
    print(f"squeeze 60 N -> {p60:.3f} bar")
    for k, c in CASSETTES.items():
        print(k, f"perm {permeance_LMH_bar(c['KLt']):,.0f} LMH/bar | Q60 {flow_Lmin(p60, c['KLt']):.3f} L/min | F for 0.3 L/min {force_for(0.3, c['KLt']):.0f} N"
              f" | 500 mL {0.5/flow_Lmin(p60, c['KLt'])*60:.0f} s | tap 1.5 bar {flow_Lmin(1.5, c['KLt']):.2f} L/min"
              f" | L to half {litres_to_half(c['KLt']):.1f} (no prefilter {litres_to_half(c['KLt'], False):.1f})"
              f" | capture 1/2/5 µm {capture(1,c):.2f}/{capture(2,c):.3f}/{capture(5,c):.4f}")
    print("hoop SF at 3 bar", round(hoop_SF(3), 1))
