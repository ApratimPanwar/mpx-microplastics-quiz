"""Tiny engineering-drawing kit: A3 landscape sheets (420 x 297 mm) rendered as standalone SVG, 4 px per mm.
First-angle projection, ISO-style dimensions, title block."""
import html, math
PX = 4.0
INK = "#111827"; THIN = "#374151"; DIM = "#1f4e8c"; CEN = "#b45309"; HID = "#6b7280"; HATCH = "#9ca3af"
FONT = "'Segoe UI', Helvetica, Arial, sans-serif"
DATE = "24 Oct 2026"
FOOTER = "MPx Squeeze v2 (Mini) · IISc CPDM · preliminary, not for manufacture"

class Sheet:
    def __init__(s, number, of, title, partno, material, finish, scale, mass=None, qty="1", notes=None):
        s.o = []; s.W, s.H = 420*PX, 297*PX
        s.meta = dict(number=number, of=of, title=title, partno=partno, material=material, finish=finish, scale=scale, mass=mass, qty=qty)
        s.notes = notes or []
    def a(s, x): s.o.append(x)
    # ---- raw px helpers
    def text(s, x, y, t, size=11, w=400, anchor="start", fill=INK, rot=0, italic=False):
        tr = f' transform="rotate({rot} {x:.1f} {y:.1f})"' if rot else ""
        st = ' font-style="italic"' if italic else ""
        s.a(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" font-weight="{w}" fill="{fill}" text-anchor="{anchor}"{tr}{st}>{html.escape(str(t))}</text>')
    def frame(s):
        W, H = s.W, s.H
        s.a(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')
        s.a(f'<rect x="{10*PX}" y="{10*PX}" width="{400*PX}" height="{277*PX}" fill="none" stroke="{INK}" stroke-width="2"/>')
        # zone marks
        for i in range(1, 8):
            x = 10*PX + i*400*PX/8; s.a(f'<line x1="{x}" y1="{10*PX}" x2="{x}" y2="{13*PX}" stroke="{INK}"/>')
        # title block 180 x 52 mm bottom right
        x0, y0 = (410-180)*PX, (287-52)*PX
        s.a(f'<rect x="{x0}" y="{y0}" width="{180*PX}" height="{52*PX}" fill="#fff" stroke="{INK}" stroke-width="2"/>')
        rows = [10, 10, 10, 10, 12]
        y = y0
        for r in rows[:-1]:
            y += r*PX; s.a(f'<line x1="{x0}" y1="{y}" x2="{x0+180*PX}" y2="{y}" stroke="{INK}"/>')
        for cx in (60, 120):
            s.a(f'<line x1="{x0+cx*PX}" y1="{y0+10*PX}" x2="{x0+cx*PX}" y2="{y0+40*PX}" stroke="{INK}"/>')
        m = s.meta
        s.text(x0+3*PX, y0+7*PX, f"{m['partno']} · {m['title']}", 15, 700)
        cells = [("MATERIAL", m["material"]), ("FINISH", m["finish"]), ("SCALE", m["scale"]),
                 ("QTY / UNIT", m["qty"]), ("MASS (est.)", m["mass"] or "—"), ("UNITS · TOL.", "mm · ISO 2768-m"),
                 ("PROJECTION", "First angle (IS/ISO)"), ("DRAWN", "MPx team (PD-298)"), ("DATE", DATE)]
        for i, (k, v) in enumerate(cells):
            cx = x0 + (i % 3)*60*PX + 2*PX; cy = y0 + (10 + (i//3)*10)*PX
            s.text(cx, cy+3.6*PX, k, 8.5, 600, fill=THIN)
            s.text(cx, cy+8.0*PX, v, 10.5, 500)
        s.text(x0+3*PX, y0+47*PX, FOOTER, 10, 500, fill=THIN)
        s.text(x0+177*PX, y0+47*PX, f"SHEET {m['number']} / {m['of']}", 12, 700, anchor="end")
        # first-angle symbol
        sx, sy = x0+150*PX, y0+33*PX
        s.a(f'<g stroke="{INK}" fill="none" stroke-width="1.2"><path d="M{sx-28},{sy-7} L{sx-8},{sy-11} L{sx-8},{sy+11} L{sx-28},{sy+7} Z"/>'
            f'<circle cx="{sx+14}" cy="{sy}" r="11"/><circle cx="{sx+14}" cy="{sy}" r="5"/></g>')
        # notes block above title block
        if s.notes:
            ny = y0 - 6*PX - len(s.notes)*4.6*PX
            s.text(x0, ny, "NOTES", 11, 700)
            for i, n in enumerate(s.notes):
                s.text(x0, ny + (i+1)*4.6*PX, f"{i+1}. {n}", 10)
    def save(s, path):
        s.frame_done = True
        body = "\n".join(s.o)
        head = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{int(s.W)}" height="{int(s.H)}" viewBox="0 0 {int(s.W)} {int(s.H)}" font-family="{FONT}">'
                '<defs><marker id="ah" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M0,1.5 L10,5 L0,8.5 z" fill="{DIM}"/></marker>'
                f'<pattern id="h45" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="7" stroke="{HATCH}" stroke-width="1"/></pattern>'
                f'<pattern id="h135" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(135)"><line x1="0" y1="0" x2="0" y2="7" stroke="{HATCH}" stroke-width="1"/></pattern>'
                f'<pattern id="hglass" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="9" stroke="#7fb3d5" stroke-width="1"/></pattern>'
                f'<pattern id="hins" width="6" height="6" patternUnits="userSpaceOnUse"><circle cx="3" cy="3" r="0.9" fill="#c2a46b"/></pattern>'
                '</defs>')
        open(path, "w", encoding="utf8").write(head + body + "</svg>\n")

class View:
    """A view on the sheet: origin (ox, oy) in sheet-mm, scale = drawing mm per real mm. y up."""
    def __init__(v, sh, ox, oy, scale, label=None, label_dy=0):
        v.sh, v.ox, v.oy, v.k = sh, ox, oy, scale
        v.label = label; v.label_dy = label_dy
    def X(v, x): return (v.ox + x*v.k)*PX
    def Y(v, y): return (v.oy - y*v.k)*PX
    def L(v, d): return d*v.k*PX
    def line(v, x1, y1, x2, y2, c=INK, w=1.6, dash=None):
        da = f' stroke-dasharray="{dash}"' if dash else ""
        v.sh.a(f'<line x1="{v.X(x1):.1f}" y1="{v.Y(y1):.1f}" x2="{v.X(x2):.1f}" y2="{v.Y(y2):.1f}" stroke="{c}" stroke-width="{w}"{da}/>')
    def poly(v, pts, c=INK, w=1.6, fill="none", close=False, dash=None):
        d = " ".join(f"{v.X(x):.1f},{v.Y(y):.1f}" for x, y in pts)
        tag = "polygon" if close else "polyline"
        da = f' stroke-dasharray="{dash}"' if dash else ""
        v.sh.a(f'<{tag} points="{d}" fill="{fill}" stroke="{c}" stroke-width="{w}"{da}/>')
    def rect(v, x0, y0, x1, y1, c=INK, w=1.6, fill="none", dash=None, rx=0):
        da = f' stroke-dasharray="{dash}"' if dash else ""
        v.sh.a(f'<rect x="{v.X(min(x0,x1)):.1f}" y="{v.Y(max(y0,y1)):.1f}" width="{abs(x1-x0)*v.k*PX:.1f}" height="{abs(y1-y0)*v.k*PX:.1f}" rx="{rx*v.k*PX:.1f}" fill="{fill}" stroke="{c}" stroke-width="{w}"{da}/>')
    def circle(v, x, y, r, c=INK, w=1.6, fill="none", dash=None):
        da = f' stroke-dasharray="{dash}"' if dash else ""
        v.sh.a(f'<circle cx="{v.X(x):.1f}" cy="{v.Y(y):.1f}" r="{r*v.k*PX:.1f}" fill="{fill}" stroke="{c}" stroke-width="{w}"{da}/>')
    def cl(v, x1, y1, x2, y2): v.line(x1, y1, x2, y2, CEN, 0.9, "18 4 3 4")
    def hidden(v, x1, y1, x2, y2): v.line(x1, y1, x2, y2, HID, 1.0, "6 4")
    def cross(v, x, y, r):
        v.cl(x-r, y, x+r, y); v.cl(x, y-r, x, y+r)
    def t(v, x, y, s, size=11, w=400, anchor="start", fill=INK, rot=0):
        v.sh.text(v.X(x), v.Y(y), s, size, w, anchor, fill, rot)
    def title(v, txt, sub=None, x=None, y=None):
        v.sh.text(v.X(x) if x is not None else v.ox*PX, v.Y(y) if y is not None else (v.oy+8)*PX, txt, 13, 700)
        if sub: v.sh.text(v.X(x) if x is not None else v.ox*PX, (v.Y(y) if y is not None else (v.oy+8)*PX)+15, sub, 10.5, 400, fill=THIN)
    # ---- dimensions (values in real mm; offsets in real mm)
    def _arrowline(v, x1, y1, x2, y2):
        v.sh.a(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{DIM}" stroke-width="1" marker-start="url(#ah)" marker-end="url(#ah)"/>')
    def _ext(v, x1, y1, x2, y2):
        v.sh.a(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{DIM}" stroke-width="0.7"/>')
    def dh(v, x1, x2, y, at, txt=None, tol=None):
        """horizontal dim between x1,x2 measured at feature y, dim line at y=at"""
        X1, X2, Y0, YA = v.X(x1), v.X(x2), v.Y(y), v.Y(at)
        sgn = -1 if YA < Y0 else 1
        v._ext(X1, Y0+sgn*3, X1, YA+sgn*6); v._ext(X2, Y0+sgn*3, X2, YA+sgn*6)
        v._arrowline(X1, YA, X2, YA)
        s = txt if txt is not None else f"{abs(x2-x1):g}"
        if tol: s += f" {tol}"
        v.sh.text((X1+X2)/2, YA-4, s, 11, 500, "middle", DIM)
    def dv(v, y1, y2, x, at, txt=None, tol=None):
        Y1, Y2, X0, XA = v.Y(y1), v.Y(y2), v.X(x), v.X(at)
        sgn = -1 if XA < X0 else 1
        v._ext(X0+sgn*3, Y1, XA+sgn*6, Y1); v._ext(X0+sgn*3, Y2, XA+sgn*6, Y2)
        v._arrowline(XA, Y1, XA, Y2)
        s = txt if txt is not None else f"{abs(y2-y1):g}"
        if tol: s += f" {tol}"
        v.sh.text(XA-5, (Y1+Y2)/2, s, 11, 500, "middle", DIM, rot=-90)
    def note(v, x, y, tx, ty, txt, anchor="start", lines=None):
        """leader from feature (x,y) to text at (tx,ty) real mm"""
        X1, Y1, X2, Y2 = v.X(x), v.Y(y), v.X(tx), v.Y(ty)
        v.sh.a(f'<line x1="{X2:.1f}" y1="{Y2:.1f}" x2="{X1:.1f}" y2="{Y1:.1f}" stroke="{DIM}" stroke-width="0.9" marker-end="url(#ah)"/>')
        ex = 30 if anchor == "start" else -30
        v.sh.a(f'<line x1="{X2:.1f}" y1="{Y2:.1f}" x2="{X2+ex:.1f}" y2="{Y2:.1f}" stroke="{DIM}" stroke-width="0.9"/>')
        tx_ = X2 + (ex + (4 if anchor == "start" else -4))
        v.sh.text(tx_, Y2+4, txt, 11, 500, anchor, DIM)
        for i, l in enumerate(lines or []): v.sh.text(tx_, Y2+18+i*13, l, 10, 400, anchor, THIN)
    def balloon(v, x, y, tx, ty, n):
        X1, Y1, X2, Y2 = v.X(x), v.Y(y), v.X(tx), v.Y(ty)
        v.sh.a(f'<line x1="{X2:.1f}" y1="{Y2:.1f}" x2="{X1:.1f}" y2="{Y1:.1f}" stroke="{INK}" stroke-width="0.9"/>')
        v.sh.a(f'<circle cx="{X1:.1f}" cy="{Y1:.1f}" r="2.2" fill="{INK}"/>')
        v.sh.a(f'<circle cx="{X2:.1f}" cy="{Y2:.1f}" r="13" fill="#fff" stroke="{INK}" stroke-width="1.3"/>')
        v.sh.text(X2, Y2+4.5, n, 11, 700, "middle")
    def label_view(v, txt, x, y):
        v.sh.text(v.X(x), v.Y(y), txt, 12.5, 700, "middle")

def table(sh, x, y, cols, rows, widths, size=10.5, rowh=6.0, head_fill="#eef2f7"):
    """x,y in sheet mm (top-left). cols = header list; rows = list of lists"""
    X = x*PX; Y = y*PX
    tw = sum(widths)*PX
    sh.a(f'<rect x="{X}" y="{Y}" width="{tw}" height="{rowh*PX}" fill="{head_fill}" stroke="{INK}" stroke-width="1"/>')
    cx = X
    for c, wd in zip(cols, widths):
        sh.text(cx+1.5*PX, Y+rowh*PX-1.8*PX, c, size, 700); cx += wd*PX
    for i, r in enumerate(rows):
        ry = Y + (i+1)*rowh*PX
        sh.a(f'<rect x="{X}" y="{ry}" width="{tw}" height="{rowh*PX}" fill="#fff" stroke="{INK}" stroke-width="0.6"/>')
        cx = X
        for c, wd in zip(r, widths):
            sh.text(cx+1.5*PX, ry+rowh*PX-1.8*PX, c, size, 400); cx += wd*PX
    cx = X
    for wd in widths[:-1]:
        cx += wd*PX; sh.a(f'<line x1="{cx}" y1="{Y}" x2="{cx}" y2="{Y+(len(rows)+1)*rowh*PX}" stroke="{INK}" stroke-width="0.6"/>')
    return y + (len(rows)+1)*rowh

def helix_side(v, Dm, d, pitch, turns, z0, cut=False, fill="#fff", c=INK, inner=None, silhouette=False):
    """side view of a helical coil (axis vertical at x=0): show tube sections on both sides as circles (section) or outline"""
    n = int(turns*2)+1
    for i in range(n):
        z = z0 + d/2 + i*pitch/2
        if z > z0 + d/2 + turns*pitch: break
        x = Dm/2 if i % 2 == 0 else -Dm/2
        v.circle(x, z, d/2, c, 1.3, fill)
        if inner: v.circle(x, z, inner/2, c, 1.0, "#fde2dc")
    if not silhouette: return
    for i in range(int(turns)):
        zA = z0 + d/2 + i*pitch; zB = zA + pitch/2
        v.line(-Dm/2, zB + d/2, Dm/2, zA + d/2 + pitch, THIN, 0.6)
        v.line(-Dm/2, zB - d/2, Dm/2, zA - d/2 + pitch, THIN, 0.6)
