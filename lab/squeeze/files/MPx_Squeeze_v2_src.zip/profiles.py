"""MPx Squeeze v2 — half-section profiles (x, r) in assembly coordinates (closed polygons, r >= 0).
CAD revolves these; drawings mirror them. Ribs, ports, slots and threads are features/notes."""
from dims import *

r = lambda d: d / 2
P = {}
c, g = CAP, CAP["groove"]
# P01 inlet cap: collar over the bottle neck, web with the prefilter bore, roof + land + S2 groove, skirt with M48x1 internal
P["P01"] = [(0, r(PCO_F["major"])), (0, r(c["collar_D"])), (c["collar_x"][1], r(c["collar_D"])), (c["flare_x"][1], r(c["OD"])),
            (c["x1"], r(c["OD"])), (c["x1"], r(BASE["OD_thread"])), (c["relief_x"][1], r(BASE["OD_thread"])),
            (c["relief_x"][1], r(c["relief_D"])), (c["land"], r(c["relief_D"])), (c["land"], c["land_r"][1]),
            (c["land"], g["r"][1]), (c["land"] - g["depth"], g["r"][1]), (c["land"] - g["depth"], g["r"][0]), (c["land"], g["r"][0]),
            (c["land"], c["land_r"][0]), (c["roof"], c["land_r"][0]), (c["roof"], r(c["bore"])), (c["web"][0], r(c["bore"])),
            (c["web"][0], r(PCO_F["major"]))]
# P02 prefilter cup (laminate) and its collar (316L, pressed into the web bore and laser-welded)
P["P02"] = [(PF["x_tip"], 0), (PF["x_tip"], r(PF["OD"])), (PF["collar_x"][0], r(PF["OD"])), (PF["collar_x"][0], r(PF["OD"]) - PF["wall"]),
            (PF["x_tip"] + PF["wall"], r(PF["OD"]) - PF["wall"]), (PF["x_tip"] + PF["wall"], 0)]
P["P02c"] = [(PF["collar_x"][0], r(PF["collar_bore"])), (PF["collar_x"][0], r(PF["flange_D"])), (c["web"][0], r(PF["flange_D"])),
             (c["web"][0], r(PF["collar_OD"])), (PF["collar_x"][1], r(PF["collar_OD"])), (PF["collar_x"][1], r(PF["collar_bore"]))]
# P03 cassette: frame + disc
x0, x1, xl = CAS["x0"], CAS["x1"], CAS["x0"] + CAS["lip_t"]
P["P03f"] = [(x0, r(CAS["lip_ID"])), (x0, r(CAS["OD"])), (x1, r(CAS["OD"])), (x1, r(CAS["disc_D"]) + 0.025), (xl, r(CAS["disc_D"]) + 0.025), (xl, r(CAS["lip_ID"]))]
P["P03d"] = [(xl, 0), (xl, r(CAS["disc_D"])), (x1, r(CAS["disc_D"])), (x1, 0)]
# P04 base + stem
b, s3 = BASE, BASE["s3_groove"]
dr, fl = b["drain_x"], b["floor_x"]
P["P04"] = [(dr[1], r(b["bore"])), (dr[1], r(b["drain_D"])), (b["seat_x"], r(b["drain_D"])), (b["seat_x"], s3["r"][0]),
            (b["seat_x"] + s3["depth"], s3["r"][0]), (b["seat_x"] + s3["depth"], s3["r"][1]), (b["seat_x"], s3["r"][1]),
            (b["seat_x"], r(b["pocket_D"])), (b["rim_x"], r(b["pocket_D"])), (b["rim_x"], r(b["relief_D"])),
            (b["thread_x"][0], r(b["relief_D"])), (b["thread_x"][0], r(b["OD_thread"])), (b["flange_x"][0], r(b["OD_thread"])),
            (b["flange_x"][0], r(b["flange_D"])), (b["flange_x"][1], r(b["flange_D"])), (b["flange_x"][1], r(b["cup_ID"])),
            (fl[1], r(b["cup_ID"])), (fl[1], r(b["hub_D"])), (b["flange_x"][1], r(b["hub_D"])),
            (b["st_x"][1], r(b["hub_D"])), (b["st_x"][1], r(b["stem_D"])), (b["stem_x"][1], r(b["stem_D"])), (b["stem_x"][1], r(b["pin_D"])),
            (b["pin_x"][1], r(b["pin_D"])), (b["pin_x"][1], 0), (b["port_x"] + 1.0, 0), (b["port_x"] + 1.0, r(b["bore"]))]
# P05 push-pull sleeve, closed
end_wall = 3.5
P["P05"] = [(SL["x"][0], r(SL["bore"])), (SL["x"][0], r(SL["OD"])), (SL["x"][1], r(SL["OD"])), (SL["x"][1], r(SL["outlet"])),
            (SL["x"][1] - end_wall, r(SL["outlet"])), (SL["x"][1] - end_wall, r(SL["bore"]))]
# accessories in own coordinates
P["P10"] = [(0, r(TAP["bore"])), (0, r(PCO["T"])), (PCO["F"], r(PCO["T"])), (PCO["F"], 16.5), (PCO["F"] + 2, 16.5), (PCO["F"] + 2, r(TAP["D"])),
            (TAP["L"], r(TAP["D"])), (TAP["L"], 11.0), (TAP["thread_x"][0], 11.0), (TAP["thread_x"][0], 9.0), (TAP["bore_depth"], 9.0),
            (TAP["bore_depth"], r(TAP["bore"]))]
P["P11"] = [(0, 7.0), (0, 12.0), (7, 12.0), (7, 13.5), (9, 13.5), (9, 11.0), (16, 11.0), (16, 7.0)]
P["P12"] = [(0, 6.0), (0, 11.0), (8, 11.0), (8, 12.5), (12, 12.5), (12, 9.0), (22, 9.0), (22, 6.0)]
P["P13"] = [(0, r(PCO_F["major"])), (0, 17.0), (17.5, 17.0), (17.5, 10.0), (BF["L"], 10.0), (BF["L"], 6.0), (35.0, 6.0), (35.0, 7.25),
            (17.5, 7.25), (17.5, 4.0), (15.5, 4.0), (15.5, r(PCO_F["major"]))]
P["P14"] = [(0, 0), (0, r(HOLD["D"])), (HOLD["H"], r(HOLD["D"])), (HOLD["H"], 25.1), (HOLD["H"] - 0.3, 25.1), (HOLD["H"] - 0.3, r(HOLD["pocket_D"])),
            (HOLD["H"] - HOLD["pocket_depth"], r(HOLD["pocket_D"])), (HOLD["H"] - HOLD["pocket_depth"], 0)]
NAMES = {
    "P01": "Inlet cap (bottle side)", "P02": "Prefilter cup, 20 µm (built in)", "P02c": "Prefilter collar", "P03f": "Cassette frame",
    "P03d": "Filter disc, sintered 316L", "P04": "Base + spout stem", "P05": "Push-pull sleeve",
    "P10": "Tap adapter (M22 female)", "P11": "M24 → M22 tap adapter", "P12": "Universal tap ferrule + silicone sleeve",
    "P13": "Backflush coupler", "P14": "Inspection holder",
}
