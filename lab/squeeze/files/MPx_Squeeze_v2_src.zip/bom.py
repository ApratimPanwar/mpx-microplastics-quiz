import json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter
from dims import *
MS = json.load(open("masses.json"))["mass_g"]

wb = Workbook()
F = "Arial"
H = Font(name=F, bold=True, color="FFFFFF"); HF = PatternFill("solid", fgColor="1F3A5F")
BLUE = Font(name=F, color="0000FF"); BLK = Font(name=F); BOLD = Font(name=F, bold=True)
YEL = PatternFill("solid", fgColor="FFF2CC")
thin = Side(style="thin", color="BFBFBF"); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)

def sheet(ws, headers, widths):
    for i, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(1, i, h); c.font = H; c.fill = HF; c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"; ws.row_dimensions[1].height = 30

# ---------------- BOM ----------------
ws = wb.active; ws.title = "BOM"
sheet(ws, ["Item", "Part no.", "Name", "Material / spec", "Stock / source form", "Process", "Make/Buy", "Qty per kit", "Mass g (CAD)",
           "Est. unit cost ₹ (proto)", "Line cost ₹", "Supplier candidates", "Notes"],
      [6, 12, 30, 40, 28, 30, 9, 9, 10, 13, 12, 40, 44])
rows = [
 (1, "MPx-SQ2-001", "Inlet cap (bottle side)", "316L; 28 PCO 1881 int. + M48×1.0-6H int.; 8 roof ribs", "Ø55 316L bar", "CNC turn, single-point PCO + M48 threads; mill ribs; knurl", "Make", 1, MS["P01"], 1300, "Peenya CNC job shops (Bangalore)", "Measure bottle thread starts before cutting (sheet 2)"),
 (2, "MPx-SQ2-002", "Prefilter cup, 20 µm (built in)", "316L 2-layer sintered laminate (20 µm Dutch weave + 0.5 perforated plate), Ø17×28 closed end", "Custom laminate cup", "Form + sinter-bond (supplier)", "Buy", 1, MS["P02"], 800, "Hengko (CN); Britomatics (Navi Mumbai); SS wire-mesh fabricators", "Or make: roll + seam-weld laminate sheet, weld end disc"),
 ("2a", "MPx-SQ2-002a", "Prefilter collar", "316L; press-fit Ø15 H7 + laser weld", "Ø18 316L bar", "CNC turn; laser weld", "Make", 1, MS["P02c"], 350, "CNC shop + laser-weld shop", ""),
 ("3A", "MPx-SQ2-003A", "Cassette A · fine (analysis)", "Frame 316L Ø45×2.4 + disc Ø40×1.6 asymmetric sintered 316L ~1 µm", "Custom disc + Ø48 bar", "Disc: supplier; frame: CNC; laser seam weld", "Make+Buy", 1, MS["P03f"] + MS["P03d"], 3500, "GKN Sinter Metals (SIKA-R AS); Shinkai (CN) asymmetric membrane; Mott (US)", "Highest-risk buy item: ask for liquid rating, bubble point, flux data on a Ø40 disc"),
 ("3B", "MPx-SQ2-003B", "Cassette B · catalogue fine", "Same frame + Ø40×1.6 symmetric sintered 316L, grade 0.2 (≈1.4 µm)", "Catalogue disc + Ø48 bar", "as 3A", "Make+Buy", 1, MS["P03f"] + MS["P03d"], 1200, "Hengko; Britomatics; Aris Filtration; Porvair India", "Fallback if 3A is slow to source; 3× slower flow"),
 ("3C", "MPx-SQ2-003C", "Cassette C · budget fast", "Same frame + Ø40×1.6 symmetric sintered 316L, grade 0.5 (≈2.5 µm)", "Catalogue disc + Ø48 bar", "as 3A", "Make+Buy", 1, MS["P03f"] + MS["P03d"], 1100, "as 3B", "Same flow as A, coarser capture"),
 (4, "MPx-SQ2-004", "Base + spout stem", "316L; M48×1.0-6g, M12×1.0-6g; 8 drain ribs; cross-port Ø2", "Ø55 316L bar", "CNC turn, mill ribs + tweezer slots, drill port", "Make", 1, MS["P04"], 1300, "Peenya CNC job shops", ""),
 (5, "MPx-SQ2-005", "Push-pull sleeve", "316L", "Ø14 316L bar", "CNC turn", "Make", 1, MS["P05"], 300, "Peenya CNC job shops", ""),
 (10, "MPx-SQ2-010", "Tap adapter (M22 female)", "316L; 28 PCO male neck + M22×1 int.; bore Ø20×31", "Ø35 316L bar", "CNC turn", "Make", 1, MS["P10"], 900, "Peenya CNC job shops", "Neck lip Ra ≤ 0.8 to seal on S1"),
 (11, "MPx-SQ-011", "M24 → M22 tap adapter", "v1 part", "Hex 27 316L bar", "CNC turn", "Make", 1, MS["P11"], 400, "CNC shop", ""),
 (12, "MPx-SQ-012", "Universal tap ferrule + silicone sleeve", "v1 part", "Ø25 bar + bought sleeve/clamp", "CNC turn; buy sleeve + clamp", "Make/Buy", 1, MS["P12"], 450, "CNC shop; food-grade silicone moulder", ""),
 (13, "MPx-SQ2-013", "Backflush coupler", "316L; 28 PCO 1881 int. + M12×1 int.", "Ø35 316L bar", "CNC turn", "Make", 1, MS["P13"], 800, "Peenya CNC job shops", ""),
 (14, "MPx-SQ2-014", "Inspection holder + cover glass", "316L dish Ø56×6 + borosilicate Ø50×0.17", "Ø58 bar + bought glass", "CNC turn; buy glass", "Make/Buy", 1, MS["P14"], 650, "CNC shop; lab-glass suppliers", ""),
 ("S", "MPx-SQ2-020", "Seal kit S1–S7", "Silicone 60 ShA, FDA 21 CFR 177.2600", "O-rings + cut gaskets", "Buy / cut from sheet", "Buy", 1, 2, 350, "AMI Polymer (India) or food-grade O-ring stockists", "See Seals tab"),
 ("F", "—", "Electropolish + passivation (lot)", "ASTM A967", "—", "Subcontract", "Buy", 1, 0, 1500, "SS finishing shops (Peenya)", "Per batch of parts"),
]
for i, r_ in enumerate(rows, 2):
    for j, v in enumerate(r_[:9], 1):
        c = ws.cell(i, j, v); c.font = BLK; c.border = BOX; c.alignment = Alignment(wrap_text=True, vertical="top")
    c = ws.cell(i, 10, r_[9]); c.font = BLUE; c.fill = YEL; c.border = BOX; c.number_format = "₹#,##0"
    c = ws.cell(i, 11, f"=H{i}*J{i}"); c.font = BLK; c.border = BOX; c.number_format = "₹#,##0"
    for j, v in ((12, r_[10]), (13, r_[11])):
        c = ws.cell(i, j, v); c.font = BLK; c.border = BOX; c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(i, 9).number_format = "0"
n = len(rows) + 1
ws.cell(2, 10).comment = Comment("Rough prototype estimates (one-off CNC in Bangalore). Replace every yellow cell with RFQ quotes.", "MPx")
ws.cell(5, 10).comment = Comment("No public price for asymmetric sintered discs; this is a placeholder until GKN / Shinkai quote.", "MPx")
t = n + 2
ws.cell(t, 3, "Core unit mass, items 1–5 with cassette A + seals (g)").font = BOLD
ws.cell(t, 9, f"=SUM(I2:I5)+I8+I9+I15").font = BOLD; ws.cell(t, 9).number_format = "0"
ws.cell(t + 1, 3, "Accessories mass, items 10–14 (g)").font = BOLD
ws.cell(t + 1, 9, "=SUM(I10:I14)").font = BOLD; ws.cell(t + 1, 9).number_format = "0"
ws.cell(t + 2, 3, "Prototype kit cost, all lines (₹)").font = BOLD
ws.cell(t + 2, 11, f"=SUM(K2:K{n})").font = BOLD; ws.cell(t + 2, 11).number_format = "₹#,##0"
ws.cell(t + 3, 3, "Number of prototype kits").font = BOLD
c = ws.cell(t + 3, 11, 3); c.font = BLUE; c.fill = YEL
ws.cell(t + 4, 3, "Prototype budget needed (₹)").font = BOLD
ws.cell(t + 4, 11, f"=K{t + 2}*K{t + 3}").font = BOLD; ws.cell(t + 4, 11).number_format = "₹#,##0"
ws.cell(t + 5, 3, "PD-298 department prototyping cap (₹)").font = BOLD
c = ws.cell(t + 5, 11, 50000); c.font = BLUE; c.number_format = "₹#,##0"
ws.cell(t + 6, 3, "Within cap?").font = BOLD
ws.cell(t + 6, 11, f'=IF(K{t + 4}<=K{t + 5},"yes","no")').font = BOLD
ws.cell(t + 8, 3, "Legend: yellow cells with blue text are estimates or choices to edit; everything else is calculated or from the drawings / CAD.").font = Font(name=F, italic=True)

# ---------------- Suppliers ----------------
ws2 = wb.create_sheet("Suppliers")
sheet(ws2, ["Item", "Supplier", "Location", "What they list", "Ask in the RFQ", "Source"], [8, 30, 22, 46, 60, 50])
sup = [
 ("3A", "GKN Sinter Metals Filters (SIKA-R AS)", "Germany / GKN Powder Metallurgy India", "Asymmetric 316L: ~0.2 mm membrane on a coarse support, grades 0.1–3 AS, tubes or discs, 'up to 4×' flow vs standard", "Ø40 × ~1.6 disc, finest liquid grade that passes 1 µm; flux at 0.2 bar; bubble point; weldable rim", "https://admin.gknpm.com/globalassets/downloads/gkn-sinter-metal-filters/brochures/sika-r-is-as.pdf"),
 ("3A", "Shinkai Filter", "China", "Asymmetric sintered porous metal membrane, ~0.3 mm layer, down to 0.1 µm, 316L", "Same as above; sample discs", "https://www.shinkaifilter.com/products/sinter-metal-filter-elements-2/asymmetric-sinter-porous-metal-filter-membrane/"),
 ("3B, 3C", "Hengko", "China", "Sintered 316L powder or mesh discs 0.2–120 µm; ±0.05 mm; MOQ 100", "Ø40 × 1.6 discs, grades for ≈1.4 µm and ≈2.5 µm liquid rating; samples", "https://www.hengko.com/sintered-0-2-120-micron-bronze-316l-stainless-steel-metal-mesh-powder-filter-disc-for-wastewater-treatment-products/"),
 ("3B, 3C", "Indian sintered-disc makers (IndiaMART)", "India", "Porous SS filter discs", "Ø40 × 1.6, 316L, finest grade; liquid absolute rating", "https://m.indiamart.com/impcat/porous-filter-disc.html"),
 ("2", "Hengko / mesh laminators", "China / India", "Sintered multilayer 316L wire-mesh discs and laminates", "20 µm Dutch weave + perforated plate laminate, formed cup Ø17×28 closed end", "https://www.hengko.com/sintered-304-316l-stainless-steel-wire-mesh-filter-screen-products/"),
 ("1, 2a, 4, 5, 10–14", "CNC turning job shops", "Peenya, Bangalore", "316L turning, threading, knurling, laser welding", "Drawing set sheets 2–5; 3 kits; electropolish + passivation", "local"),
 ("S1–S7", "AMI Polymer Pvt Ltd (Imaseal) or similar", "India", "O-rings incl. silicone, food grade", "FDA 21 CFR 177.2600 silicone, sizes on Seals tab", "https://www.directindustry.com/prod/ami-polymer-pvt-ltd/product-238681-2835732.html"),
]
for i, r_ in enumerate(sup, 2):
    for j, v in enumerate(r_, 1):
        c = ws2.cell(i, j, v); c.font = BLK; c.border = BOX; c.alignment = Alignment(wrap_text=True, vertical="top")

# ---------------- Seals ----------------
ws3 = wb.create_sheet("Seals")
sheet(ws3, ["ID", "Type", "Location", "Size (ID × CS or OD/ID × t), mm", "Qty", "Side of filter"], [6, 14, 44, 30, 6, 22])
for i, r_ in enumerate(SEALS, 2):
    for j, v in enumerate(r_, 1):
        c = ws3.cell(i, j, v); c.font = BLK; c.border = BOX
ws3.cell(len(SEALS) + 3, 1, "All silicone 60 ShA, FDA 21 CFR 177.2600, post-cured, unpigmented.").font = Font(name=F, italic=True)

# ---------------- Flow ----------------
ws4 = wb.create_sheet("Flow")
sheet(ws4, ["Input / result", "Value", "Unit", "Note"], [40, 14, 16, 70])
inp = [
 ("Active disc diameter", CAS["lip_ID"], "mm", "Inside the frame lip"),
 ("KL × thickness, cassette A", round(CASSETTES["A"]["KLt"], 2), "mm", f"26 × 1.5 / {ASYM_GAIN:g} (asymmetric gain, GKN claims up to 4)"),
 ("KL × thickness, cassette B", round(CASSETTES["B"]["KLt"], 2), "mm", "grade 0.2: KL 26 × 1.6"),
 ("KL × thickness, cassette C", round(CASSETTES["C"]["KLt"], 2), "mm", "grade 0.5: KL 8 × 1.6"),
 ("Water viscosity", 0.89, "cP", "25 °C"),
 ("Hand force", 60, "N", "comfortable one-hand squeeze (assumption)"),
 ("Palm contact area", 34, "cm²", "500 mL PET (assumption, bench test 2)"),
 ("Bottle wall stiffness", 4, "N", ""),
 ("Water column above disc", 0.126, "m", "full 500 mL bottle, inverted"),
 ("Tap pressure", 1.5, "bar", ""),
]
for i, (a, b, c_, d) in enumerate(inp, 2):
    ws4.cell(i, 1, a).font = BLK; x = ws4.cell(i, 2, b); x.font = BLUE; x.fill = YEL; ws4.cell(i, 3, c_).font = BLK; ws4.cell(i, 4, d).font = BLK
res = [
 ("Disc area", "=PI()/4*B2^2/1e6", "m²", ""),
 ("Squeeze pressure", "=((B7-B9)/(B8/1e4)+1000*9.81*B10)/1e5", "bar", "(F − wall) / palm area + water column"),
 ("Permeance A", "=1/(B3*B6/25.4)*2444.9*14.504", "L/(m²·h·bar)", "Mott: ΔP[psi] = KL·flux[gpm/ft²]·µ[cP]·t[in]"),
 ("Permeance B", "=1/(B4*B6/25.4)*2444.9*14.504", "L/(m²·h·bar)", ""),
 ("Permeance C", "=1/(B5*B6/25.4)*2444.9*14.504", "L/(m²·h·bar)", ""),
 ("Squeeze flow A", "=B14*B12*B13/60", "L/min", "clean media"),
 ("Squeeze flow B", "=B15*B12*B13/60", "L/min", ""),
 ("Squeeze flow C", "=B16*B12*B13/60", "L/min", ""),
 ("Time for 500 mL, A", "=0.5/B17*60", "s", ""),
 ("Tap flow A", "=B14*B12*B11/60", "L/min", ""),
]
for i, (a, f, u, d) in enumerate(res, 12):
    ws4.cell(i, 1, a).font = BOLD; c = ws4.cell(i, 2, f); c.font = BLK; c.number_format = "#,##0.00"; ws4.cell(i, 3, u).font = BLK; ws4.cell(i, 4, d).font = BLK
for wsx in wb.worksheets:
    for row in wsx.iter_rows():
        for c in row:
            if c.font and c.font.name != F: c.font = Font(name=F, bold=c.font.bold, color=c.font.color, italic=c.font.italic)
out = "/mnt/user-data/outputs/squeeze_v2/MPx_Squeeze_v2_BOM.xlsx"
wb.save(out); print(out)
