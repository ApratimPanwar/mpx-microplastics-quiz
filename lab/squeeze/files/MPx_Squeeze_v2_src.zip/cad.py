"""CadQuery solids of MPx Squeeze v2 from profiles.py: STEP per part + assembly; volumes and masses."""
import json, os, math, cadquery as cq
from dims import *
from profiles import P, NAMES
OUT = "/mnt/user-data/outputs/squeeze_v2/step/"; os.makedirs(OUT, exist_ok=True)
def revolve(pts): return cq.Workplane("XY").polyline(pts).close().revolve(360, (0, 0, 0), (1, 0, 0))
def radial_boxes(n, w, r0, r1, x0, x1, phase=0.0):
    out = None
    for i in range(n):
        a = phase + 360 * i / n
        bx = cq.Workplane("XY").box(x1 - x0, r1 - r0, w).translate(((x0 + x1) / 2, (r0 + r1) / 2, 0)).rotate((0, 0, 0), (1, 0, 0), a)
        out = bx if out is None else out.union(bx)
    return out
S = {k: revolve(v) for k, v in P.items()}
# roof ribs on the cap (back-support of the disc during backflush), drainage ribs in the base pocket
S["P01"] = S["P01"].union(radial_boxes(CAP["ribs"]["n"], CAP["ribs"]["w"], *CAP["ribs"]["r"], CAP["roof"], CAP["roof"] + CAP["ribs"]["h"], 22.5))
S["P04"] = S["P04"].union(radial_boxes(BASE["ribs"]["n"], BASE["ribs"]["w"], BASE["bore"] / 2, BASE["drain_D"] / 2, BASE["drain_x"][0], BASE["drain_x"][1], 0))
# two tweezer slots through the base rim, cross-port in the stem
S["P04"] = S["P04"].cut(radial_boxes(2, 5.0, BASE["pocket_D"] / 2 - 0.1, BASE["relief_D"] / 2 + 0.1, BASE["rim_x"] - 0.1, BASE["seat_x"], 90))
S["P04"] = S["P04"].cut(cq.Workplane("YZ").circle(BASE["port"] / 2).extrude(6, both=True).translate((BASE["port_x"], 0, 0)))
dens = {"P03d": SINT_DENS, "P02": 0.55}
mass = {}
for k, s in S.items():
    mass[k] = round(s.val().Volume() * SS_RHO * dens.get(k, 1.0), 1)
    fn = f"{k}_{NAMES[k].split(' (')[0].replace(' ', '_').replace(',', '').replace('+', 'and').replace('→', 'to').replace('µ', 'u')}.step"
    cq.exporters.export(s, OUT + fn)
CORE = ("P01", "P02", "P02c", "P03f", "P03d", "P04", "P05")
asm = cq.Assembly(name="MPx_Squeeze_v2")
for k in CORE:
    asm.add(S[k], name=k, color=cq.Color(0.55, 0.58, 0.62) if k in ("P03d", "P02") else cq.Color(0.8, 0.82, 0.85))
asm.save(OUT + "MPx_Squeeze_v2_ASSEMBLY.step")
unit = sum(mass[k] for k in CORE) + 1.5
json.dump({"mass_g": mass, "unit_mass_g": round(unit, 1)}, open("masses.json", "w"), indent=1)
print(json.dumps(mass), "\nunit (with ~1.5 g seals):", round(unit, 1), "g")
