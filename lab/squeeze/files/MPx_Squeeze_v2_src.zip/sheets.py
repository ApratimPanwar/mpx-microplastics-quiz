"""MPx Squeeze v2 (Mini) engineering drawing set: 6 A3 sheets, standalone SVG. Geometry from profiles.py / dims.py."""
import json, os, math
from lib import *
from dims import *
from profiles import P, NAMES
OUT = "/mnt/user-data/outputs/squeeze_v2/drawings/"; os.makedirs(OUT, exist_ok=True)
NS = 6
MS = json.load(open("masses.json"))["mass_g"]
UNIT = json.load(open("masses.json"))["unit_mass_g"]
g = lambda *ks: f"{sum(MS[k] for k in ks):.0f}"
BLUE = "#2f80c0"
P60 = squeeze_bar(60)
A, B_, C_ = CASSETTES["A"], CASSETTES["B"], CASSETTES["C"]

def sec(v, key, dx=0.0, hatch="h45", mirror=True, lw=1.4, fill=None, flip=False):
    up = [((-x if flip else x) + dx, y) for x, y in P[key]]
    v.poly(up, INK, lw, fill or f"url(#{hatch})", close=True)
    if mirror: v.poly([(x, -y) for x, y in up], INK, lw, fill or f"url(#{hatch})", close=True)
def thread_ext(v, x0, x1, R, pitch=1.0):
    rm = R - 0.6134 * pitch
    for s_ in (1, -1): v.line(x0, s_ * rm, x1, s_ * rm, THIN, 0.7)
def thread_int(v, x0, x1, R):
    for s_ in (1, -1): v.line(x0, s_ * R, x1, s_ * R, THIN, 0.7)
def arrow(s, v, x1, y1, x2, y2, c=BLUE, w=2.0):
    s.a(f'<line x1="{v.X(x1):.1f}" y1="{v.Y(y1):.1f}" x2="{v.X(x2):.1f}" y2="{v.Y(y2):.1f}" stroke="{c}" stroke-width="{w}" marker-end="url(#ah)"/>')
def oring(v, x, r_, cs):
    for s_ in (1, -1): v.circle(x, s_ * r_, cs / 2, INK, 0.6, "#111")
def ribs_cap(v, dx=0.0):     # roof ribs seen beyond the cutting plane (thin outline)
    k = math.cos(math.radians(22.5)); x0, x1 = CAP["roof"] + dx, CAP["roof"] + CAP["ribs"]["h"] + dx
    for s_ in (1, -1): v.rect(x0, s_ * CAP["ribs"]["r"][0] * k, x1, s_ * CAP["ribs"]["r"][1] * k, THIN, 0.8, "#eef1f5")
def ribs_base(v, dx=0.0):
    x0, x1 = BASE["drain_x"][0] + dx, BASE["drain_x"][1] + dx
    for s_ in (1, -1): v.rect(x0, s_ * BASE["bore"] / 2, x1, s_ * BASE["drain_D"] / 2, THIN, 0.8, "#eef1f5")
def assembly(v, dx=0.0, sleeve_open=False):
    for k, h in (("P01", "h135"), ("P02c", "h45"), ("P03f", "h45"), ("P04", "h45")): sec(v, k, dx=dx, hatch=h)
    sec(v, "P02", dx=dx, fill="url(#hins)"); sec(v, "P03d", dx=dx, fill="url(#hins)")
    sx = SL["travel"] if sleeve_open else 0.0
    sec(v, "P05", dx=dx + sx, hatch="h135")
    ribs_cap(v, dx); ribs_base(v, dx)
    # seals
    for s_ in (1, -1): v.rect(CAP["web"][0] - 1.5 + dx, s_ * 9.5, CAP["web"][0] + dx, s_ * 12.75, INK, 0.6, "#111")       # S1
    oring(v, CAP["land"] - 0.6 + dx, 21.0, 1.5); oring(v, BASE["seat_x"] + 0.6 + dx, 21.0, 1.5)                            # S2, S3
    oring(v, BASE["groove"] + dx, 4.25, 1.5); oring(v, BASE["pin_groove"] + dx, 1.75, 1.0)                                   # S4, S5

# ====================================================== S01 · GENERAL ASSEMBLY ======================================================
s = Sheet(1, NS, "General assembly", "MPx-SQ2-000", "316L (see parts list)", "Electropolished, passivated (ASTM A967)", "2:1",
          mass=f"~{UNIT:.0f} g core unit", notes=[
          "Section A-A on axis, cassette A fitted, spout closed. Flow left to right (bottle inverted in use).",
          "Only plastic in the water path: the PET bottle itself and silicone seals (FDA 21 CFR 177.2600).",
          f"Clean flow, cassette A: ~{flow_Lmin(P60, A['KLt']):.2f} L/min at 60 N squeeze ({P60:.2f} bar); ~{flow_Lmin(1.5, A['KLt']):.1f} L/min at 1.5 bar tap.",
          "Leak test 1.5 bar air under water, 60 s; bubble-point every cassette (ISO 4003)."])
s.frame()
v = View(s, 52, 82, 2.0)
# bottle neck ghost
for s_ in (1, -1):
    v.poly([(-16, s_ * 13.7), (14.4, s_ * 13.7), (14.4, s_ * 10.85), (-16, s_ * 10.85)], HID, 1.0, "none", dash="5 3")
    v.rect(-4.1, s_ * 13.7, -2.6, s_ * 16.5, HID, 1.0, "none", dash="5 3")
v.t(-17, 19, "PET bottle neck", 9.5, 400, "start", HID)
assembly(v)
v.cl(-18, 0, 56, 0)
thread_int(v, 0, 13.5, 14.2); thread_int(v, BASE["thread_x"][0], BASE["thread_x"][1], 24.0)
for (x1, y1, x2, y2) in ((-15, 4, -6, 4), (-6, 12.5, -6, 9.2), (6, 12.5, 6, 9.2), (8, 0, 17, 0), (19.2, 8, 19.2, 16), (12, 16, 12, -1.0)):
    pass
for (x1, y1, x2, y2) in ((-15, 4.5, -8, 4.5), (-2, 10.2, -2, 8.0), (6, 10.2, 6, 8.0), (4, 2.5, 16, 2.5), (19.1, 9, 19.1, 16.5), (22.3, 14, 22.3, 5), (26, 0.8, 47, 0.8)):
    arrow(s, v, x1, y1, x2, y2)
v.dh(0, X_TIP, -16.2, -30, f"{X_TIP:g} outside the bottle")
v.dh(PF["x_tip"], 0, -8.5, -30, f"{-PF['x_tip']:g} in neck")
v.dv(-26, 26, CAP["x1"], 62, "Ø52 max")
v.dv(-CAS["lip_ID"] / 2, CAS["lip_ID"] / 2, 21, 58, f"Ø{CAS['lip_ID']:g} active disc")
for x, y, tx, ty, n in ((6, 16.2, 3, 29, "1"), (-8, 8.5, -11, 25, "2"), (17, 6.8, 10, 29, "2a"), (19.8, 22, 17, 29, "3"),
                        (30, 25, 33, 29, "4"), (44, 6, 48, 22, "5"), (14.3, 11.0, 24, 29, "S1"), (18.9, -21, 12, -23.5, "S2"),
                        (22.5, -21, 27, -23.5, "S3"), (42.5, -4.25, 50, -18, "S4")):
    v.balloon(x, y, tx, ty, n)
v.label_view("SECTION A-A  (2:1)", 25, -35)
# parts list
rows = [
 ["1", "MPx-SQ2-001", NAMES["P01"], "316L bar Ø55; 28 PCO 1881 int., M48×1 int.; 8 roof ribs", "Make", "1", g("P01")],
 ["2", "MPx-SQ2-002", NAMES["P02"], "316L sintered laminate cup Ø17×28, 20 µm", "Buy*", "1", g("P02")],
 ["2a", "MPx-SQ2-002a", NAMES["P02c"], "316L bar Ø18; press + laser weld to 1 and 2", "Make", "1", g("P02c")],
 ["3", "MPx-SQ2-003A", "Disc cassette A (fine)", "Frame 316L Ø45×2.4 + disc Ø40×1.6 asym. sintered 316L", "Make+Buy", "1", g("P03f", "P03d")],
 ["3B/C", "MPx-SQ2-003B/C", "Disc cassettes B, C (options)", "same frame; grade 0.2 / grade 0.5 symmetric discs", "Make+Buy", "opt.", g("P03f", "P03d")],
 ["4", "MPx-SQ2-004", NAMES["P04"], "316L bar Ø55; M48×1 ext., M12×1 stem, 8 drain ribs", "Make", "1", g("P04")],
 ["5", "MPx-SQ2-005", NAMES["P05"], "316L bar Ø14; slides 4 mm", "Make", "1", g("P05")],
 ["10", "MPx-SQ2-010", NAMES["P10"], "316L; 28 PCO male neck + M22×1 int.", "Make", "1", g("P10")],
 ["11", "MPx-SQ-011", NAMES["P11"], "carried over from v1", "Make", "1", g("P11")],
 ["12", "MPx-SQ-012", NAMES["P12"], "carried over from v1", "Make/Buy", "1", g("P12")],
 ["13", "MPx-SQ2-013", NAMES["P13"], "316L; 28 PCO int. + M12×1 int.", "Make", "1", g("P13")],
 ["14", "MPx-SQ2-014", NAMES["P14"], "316L dish + Ø50 borosilicate cover glass", "Make/Buy", "1", g("P14")],
 ["S1–S7", "MPx-SQ2-020", "Seal kit (sheet 6)", "Silicone 60 ShA, FDA 21 CFR 177.2600", "Buy", "1 kit", "2"],
]
s.text(12 * PX, 156 * PX, "PARTS LIST", 13, 700)
yend = table(s, 12, 159, ["#", "Part no.", "Name", "Material / spec", "M/B", "Qty", "g"], rows, [11, 25, 50, 86, 17, 10, 9], size=9.2, rowh=5.6)
s.text(12 * PX, (yend + 5) * PX, f"Core unit (items 1–5 + seals) ≈ {UNIT:.0f} g from CAD volumes (v1: 315 g). Items 10–14 are accessories.", 10, 400)
s.text(12 * PX, (yend + 10) * PX, "* Sintered laminate cups and asymmetric discs are bought from porous-metal suppliers to drawing (sheets 2, 3).", 10, 400)
# right column: size, key numbers, use modes
mx = 232
s.text(mx * PX, 22 * PX, "WHAT CHANGED FROM v1", 13, 700)
chg = [f"Envelope Ø{MAX_D:g} × {OVERALL_L:g} mm outside the bottle (v1: Ø35 × 155.5 mm).",
       "Two stages: built-in 20 µm prefilter cup that sits inside the bottle neck,",
       "  then one removable disc cassette (~1 µm) that comes out flat for the microscope.",
       "Tube element, body, element base and dust cap removed: 5 core parts (v1: 9).",
       "Cassettes A / B / C share one frame, so the disc grade is a user choice."]
for i, l in enumerate(chg): s.text(mx * PX, (28 + i * 4.8) * PX, l, 10.2, 400)
s.text(mx * PX, 58 * PX, "USE MODES", 13, 700)
modes = [("A · Squeeze", ["PET bottle", "2 prefilter", "3 cassette", "5 spout", "cup / mouth"], "bottle inverted; ~0.2 bar at 60 N"),
         ("B · Tap", ["tap", "12 / 11", "10 neck", "2 → 3", "5 spout"], "tap 1–2 bar; open the tap gently"),
         ("C · Backflush", ["tap / bottle", "10 / bottle", "13 on stem", "3 → 2 (rev.)", "out at 1"], "reverse flow 10–20 s, catch in a dish"),
         ("D · Inspect", ["unscrew 4", "lift 3", "14 holder", "cover glass", "phone lens"], "disc is the slide; Nile red for < 20 µm")]
for i, (title, boxes, sub) in enumerate(modes):
    y0 = 64 + i * 21
    s.text(mx * PX, y0 * PX, title, 11.5, 700)
    for j, b in enumerate(boxes):
        bx = mx + j * 35
        s.a(f'<rect x="{bx * PX}" y="{(y0 + 2.5) * PX}" width="{29 * PX}" height="{7.5 * PX}" rx="6" fill="#f3f6fa" stroke="{INK}" stroke-width="1"/>')
        s.text((bx + 14.5) * PX, (y0 + 7.4) * PX, b, 9.5, 500, "middle")
        if j < len(boxes) - 1: s.a(f'<line x1="{(bx + 29.5) * PX}" y1="{(y0 + 6.2) * PX}" x2="{(bx + 34.5) * PX}" y2="{(y0 + 6.2) * PX}" stroke="{BLUE}" stroke-width="1.8" marker-end="url(#ah)"/>')
    s.text(mx * PX, (y0 + 14.2) * PX, sub, 9.5, 400, fill=THIN)
s.text(mx * PX, 152 * PX, "Two size fractions for analysis: the prefilter keeps ≥ 20 µm (backflush it", 9.8, 400, fill=THIN)
s.text(mx * PX, 156.6 * PX, "into a dish); the disc keeps ~1–20 µm, about 96 % of microplastics by count.", 9.8, 400, fill=THIN)
s.save(OUT + "MPx-SQ2-S01_Assembly.svg")

# ====================================================== S02 · INLET CAP + PREFILTER ======================================================
s = Sheet(2, NS, "Inlet cap and built-in prefilter", "MPx-SQ2-001/002", "316L bar Ø55 · sintered 316L laminate", "Electropolished, passivated; knurl", "2.5:1",
          mass=f"{g('P01')} + {g('P02', 'P02c')} g", notes=[
          "Bottle thread 28 PCO 1881 internal, major Ø28.4 / minor Ø26.0; confirm starts on 5 local bottles first (as v1).",
          "Gasket S1 on the web face at 15.5; the bottle lip compresses it ~0.4 mm. The prefilter passes through the lip.",
          "M48×1.0-6H from 21.0 to 28.7. Land at 19.5 carries the S2 face groove (Ø40.5/Ø43.5 × 1.15 deep).",
          "8 radial roof ribs 1.2 wide, 2.3 high, r 7.5–19, at 22.5° + n·45°: they hold the disc during backflush.",
          "Prefilter: press collar 2a into the Ø15 H7 bore, laser-weld round from the chamber side, then weld cup 2 to the flange.",
          "Diamond knurl 0.8 pitch on Ø52 from 15.5 to 28.7; break sharp edges 0.2."])
s.frame()
v = View(s, 95, 112, 2.5)
sec(v, "P01"); sec(v, "P02c", hatch="h45"); sec(v, "P02", fill="url(#hins)"); ribs_cap(v)
for s_ in (1, -1): v.rect(CAP["web"][0] - 1.5, s_ * 9.5, CAP["web"][0], s_ * 12.75, INK, 0.6, "#111")
oring(v, CAP["land"] - 0.6, 21.0, 1.5)
v.cl(-16, 0, 34, 0)
thread_int(v, 0, 13.5, 14.2); thread_int(v, BASE["thread_x"][0], BASE["thread_x"][1], 24.0)
v.dh(0, CAP["x1"], 26, 33.5, f"{CAP['x1']:g}"); v.dh(0, 15.5, 16.2, 30, "15.5"); v.dh(15.5, 18.0, -26, -30, "2.5 web")
v.dh(PF["x_tip"], 15.5, -8.5, -33, f"{15.5 - PF['x_tip']:g}"); v.dh(18.0, 19.5, 26, 37, "1.5")
v.dv(-26, 26, CAP["x1"], 36, "Ø52"); v.dv(-16.2, 16.2, 0, -21, "Ø32.4"); v.dv(-8.5, 8.5, -6, -15, "Ø17")
v.note(24, 24.0, 40, 32, "M48×1.0-6H")
v.note(19.5, 21.0, 40, 16, "S2 groove", lines=["Ø40.5/Ø43.5 × 1.15"])
v.note(19.2, 12, 40, 5, "roof ribs ×8 (beyond plane)")
v.note(16.8, -7.5, 40, -12, "Ø15 H7, collar 2a")
v.note(5, -14.2, 10, -40, "28 PCO 1881 int.")
v.note(-5, 8.5, -8, 22, "prefilter cup, 20 µm", anchor="end", lines=["sits inside the bottle neck"])
v.label_view("P01 + P02 · SECTION (2.5:1)", 10, -50)
# prefilter detail
v2 = View(s, 300, 60, 3.0)
cup = [(x - PF["x_tip"], y) for x, y in P["P02"]]
v2.poly(cup, INK, 1.2, "url(#hins)", close=True); v2.poly([(x, -y) for x, y in cup], INK, 1.2, "url(#hins)", close=True)
v2.cl(-3, 0, 31, 0); v2.dh(0, PF["collar_x"][0] - PF["x_tip"], 8.5, 13, f"{PF['collar_x'][0] - PF['x_tip']:g}")
v2.dv(-8.5, 8.5, 0, -5, "Ø17"); v2.note(15, -8.15, 18, -16, "wall 0.7", lines=["20 µm Dutch weave outside", "0.5 perforated support inside"])
v2.label_view("P02 PREFILTER CUP (3:1)", 14, -26)
rows = [["Media", "316L sintered 2-layer laminate"], ["Rating", "20 µm (nominal 98 %)"], ["Area", f"{prefilter_area_cm2():.1f} cm² (outside)"],
        ["Max ΔP", "3 bar both directions"], ["Role", "keeps sand, hair, fibres, ≥ 20 µm off the disc"]]
table(s, 262, 118, ["Prefilter", "Value"], rows, [30, 72], size=9.6, rowh=5.8)
s.save(OUT + "MPx-SQ2-S02_Cap_Prefilter.svg")

# ====================================================== S03 · CASSETTES ======================================================
s = Sheet(3, NS, "Removable disc cassettes A / B / C", "MPx-SQ2-003", "316L frame · sintered 316L disc", "Frame passivated; disc as sintered", "2:1 · 6:1",
          mass=f"{g('P03f', 'P03d')} g", notes=[
          "Disc enters the frame from below (clean side) against the 0.8 lip; laser seam-weld disc to frame all round on the clean side.",
          "Fine (membrane) side faces UP = dirty side; engrave 'IN ↑' and the letter A/B/C on the frame top face, outside the S2 track.",
          "Frame faces flat 0.02 and Ra ≤ 0.8 where S2 (top) and S3 (bottom) seal; weld must not reach the seal tracks (Ø40.5–43.5).",
          "Every cassette: bubble point (ISO 4003, IPA) and clean-water flux at 0.2 bar; reject below 80 % of nominal.",
          "In use the cake lies on the top face, 0.8 below the frame top: it can sit under a cover glass without being touched."])
s.frame()
v = View(s, 70, 70, 2.0)            # plan view
v.circle(0, 0, CAS["OD"] / 2, INK, 1.4, "#f3f4f6"); v.circle(0, 0, CAS["lip_ID"] / 2, INK, 1.4, "url(#hins)")
v.circle(0, 0, 21.0, DIM, 0.8, dash="5 3"); v.cross(0, 0, 26)
v.t(0, 20.2, "IN ↑  A", 10, 700, "middle")
v.dh(-CAS["OD"] / 2, CAS["OD"] / 2, -22.5, -28, f"Ø{CAS['OD']:g} -0.05"); v.dh(-CAS["lip_ID"] / 2, CAS["lip_ID"] / 2, 0, 3, f"Ø{CAS['lip_ID']:g} active")
v.note(14.8, 14.8, 28, 24, "S2 / S3 track Ø42")
v.label_view("PLAN, DIRTY SIDE (2:1)", 0, -34)
v = View(s, 160, 70, 2.0)           # section
sec(v, "P03f", dx=-CAS["x0"], hatch="h45", flip=False); sec(v, "P03d", dx=-CAS["x0"], fill="url(#hins)")
v.t(1.2, 25, "dirty ↓", 9.5, 500, "middle", THIN)
v.cl(-3, 0, 6, 0)
v.label_view("SECTION (2:1), flow →", 1.2, -30)
# 6:1 edge detail
v = View(s, 200, 128, 6.0)
fr = [(x - CAS["x0"], y - 19.0) for x, y in P["P03f"]]; dk = [(x - CAS["x0"], y - 19.0) for x, y in P["P03d"] if True]
v.poly(fr, INK, 1.4, "url(#h45)", close=True)
v.poly([(CAS["lip_t"], -3.0), (CAS["lip_t"], 1.0), (CAS["t"], 1.0), (CAS["t"], -3.0)], INK, 1.4, "url(#hins)", close=True)
v.poly([(CAS["lip_t"], -3.0), (CAS["lip_t"] + 0.2, -3.0), (CAS["lip_t"] + 0.2, 1.0), (CAS["lip_t"], 1.0)], "#b45309", 1.0, "#e9c58f", close=True)
v.dh(0, CAS["t"], 3.5, 4.6, f"{CAS['t']:g}"); v.dh(0, CAS["lip_t"], 0.25, -4.3, f"{CAS['lip_t']:g}"); v.dh(CAS["lip_t"], CAS["t"], -3, -5.6, "1.6 disc")
v.note(CAS["t"], 1.0, 3.6, -1.2, "laser seam weld", lines=["clean side, full circle"])
v.note(CAS["lip_t"] + 0.1, -1.5, -0.8, -3.6, "0.2 fine layer (A)", anchor="end")
v.label_view("EDGE DETAIL (6:1)", 1.2, -6.2)
# options table
rows = []
for k, c in CASSETTES.items():
    rows.append([k, c["name"].split("· ")[1], c["rating"].split(" (")[0], f"{flow_Lmin(P60, c['KLt']):.2f}", f"{0.5 / flow_Lmin(P60, c['KLt']) * 60:.0f} s",
                 f"{flow_Lmin(1.5, c['KLt']):.1f}", f"{litres_to_half(c['KLt']):.1f} L"])
s.text(230 * PX, 24 * PX, "CASSETTE OPTIONS (same frame, same seals)", 12, 700)
yend = table(s, 230, 28, ["", "Use", "Rating", "L/min 60 N", "500 mL", "L/min tap", "Clean every"], rows, [7, 32, 26, 22, 18, 21, 25], size=9.2, rowh=6.0)
lines = [f"Disc media:  A  {A['media']}.", f"B  {B_['media']}.", f"C  {C_['media']}.",
         f"Flow model: Darcy with Mott KL; A uses {ASYM_GAIN:g}× the permeability of a symmetric 1.5 mm",
         "grade-0.2 disc (GKN quotes 'up to 4×' for its SIKA-R AS asymmetric media).",
         f"'Clean every' = litres of tap water until flow halves; assumes {C_TAP*1000:g} mg/L solids, cake",
         f"resistance {ALPHA:.0e} m/kg and the prefilter taking {PREFILTER_MASS_CUT*100:.0f} % of the mass. To be measured.",
         "A gives grade-0.2 capture at grade-0.5 flow: that is why it is the default."]
for i, l in enumerate(lines): s.text(230 * PX, (yend + 6 + i * 4.6) * PX, l, 9.6, 400, fill=THIN if i > 2 else INK)
s.save(OUT + "MPx-SQ2-S03_Cassettes.svg")

# ====================================================== S04 · BASE, STEM, SLEEVE ======================================================
s = Sheet(4, NS, "Base, spout stem, push-pull sleeve", "MPx-SQ2-004/005", "316L bar Ø55 / Ø14", "Electropolished, passivated; knurl", "2.5:1 · 4:1",
          mass=f"{g('P04')} · {g('P05')} g", notes=[
          "Cassette pocket Ø45.2 H8 × 2.0 deep; S3 face groove Ø40.5/Ø43.5 × 1.15 in the seat; two tweezer slots 5 wide through the rim at 90°/270°.",
          "8 radial drain ribs 1.2 wide × 0.8 high support the disc; water runs between them to the Ø3 bore.",
          "M48×1.0-6g from 21.0 to 29.0; M12×1.0-6g on the stem hub (backflush coupler / UV cap interface).",
          "Push-pull: S4 (7 × 1.5) seals the sleeve on the stem; S5 (2.5 × 1.0) on the Ø3.5 pin closes the outlet. Pull 4 mm to open.",
          "Cross-port Ø2 at x 44.5 stays inside the sleeve in both positions. Sleeve retained by a 316L wire circlip at the stem root."])
s.frame()
v = View(s, 50, 100, 2.5)
dx = -BASE["rim_x"]
sec(v, "P04", dx=dx); sec(v, "P05", dx=dx, hatch="h135"); ribs_base(v, dx)
oring(v, BASE["seat_x"] + 0.6 + dx, 21.0, 1.5); oring(v, BASE["groove"] + dx, 4.25, 1.5); oring(v, BASE["pin_groove"] + dx, 1.75, 1.0)
for s_ in (1, -1): v.rect(BASE["port_x"] - 1 + dx, s_ * 1.5, BASE["port_x"] + 1 + dx, s_ * 4.5, INK, 0.6, "#fff")
v.cl(-3, 0, 34, 0)
thread_ext(v, BASE["thread_x"][0] + dx, BASE["flange_x"][0] + dx, 24.0); thread_ext(v, BASE["st_x"][0] + dx, BASE["st_x"][1] + dx, 6.0)
v.dh(0, X_TIP + dx, 26, 32, f"{X_TIP - BASE['rim_x']:g}"); v.dh(0, BASE["flange_x"][1] + dx, 26, 29, f"{BASE['flange_x'][1] - BASE['rim_x']:g}")
v.dv(-26, 26, BASE["flange_x"][1] + dx, 36, "Ø52"); v.dv(-22.6, 22.6, 0, -6, "Ø45.2 H8")
v.note(BASE["thread_x"][0] + dx + 4, -24, 20, -36, "M48×1.0-6g")
v.note(BASE["seat_x"] + dx + 0.6, -21, 34, -26, "S3 seat groove")
v.note(BASE["drain_x"][0] + dx + 0.4, 12, 34, 18, "drain ribs ×8")
v.note(BASE["st_x"][0] + dx + 2, 6, 34, 10, "M12×1.0-6g")
v.label_view("P04 + P05 · SECTION, CLOSED (2.5:1)", 15, -42)
v3 = View(s, 280, 60, 4.0)
sp = [(x - SL["x"][0] + SL["travel"], y) for x, y in P["P05"]]
v3.poly(sp, INK, 1.4, "url(#h135)", close=True); v3.poly([(x, -y) for x, y in sp], INK, 1.4, "url(#h135)", close=True)
stem = [(0, 4.5), (BASE["stem_x"][1] - SL["x"][0], 4.5), (BASE["stem_x"][1] - SL["x"][0], 1.75), (BASE["pin_x"][1] - SL["x"][0], 1.75),
        (BASE["pin_x"][1] - SL["x"][0], -1.75), (BASE["stem_x"][1] - SL["x"][0], -1.75), (BASE["stem_x"][1] - SL["x"][0], -4.5), (0, -4.5)]
v3.poly(stem, INK, 1.2, "#f3f4f6", close=True); v3.cl(-3, 0, 22, 0)
arrow(s, v3, 8, 0, 21, 0)
v3.dh(SL["travel"], SL["travel"] + SL["x"][1] - SL["x"][0], 6, 9, f"{SL['x'][1] - SL['x'][0]:g}"); v3.dv(-6, 6, SL["travel"] + 13, 20, "Ø12")
v3.label_view("SLEEVE OPEN (+4 mm) · 4:1", 9, -12)
s.save(OUT + "MPx-SQ2-S04_Base_Spout.svg")

# ====================================================== S05 · ACCESSORIES ======================================================
s = Sheet(5, NS, "Tap, backflush and inspection accessories", "MPx-SQ2-010…014", "316L bar · silicone · borosilicate glass", "Electropolished, passivated", "2:1",
          mass=f"{g('P10')} · {g('P11')} · {g('P12')} · {g('P13')} · {g('P14')} g", notes=[
          f"10: 28 PCO male neck; bore Ø{TAP['bore']:g} × {TAP['bore_depth']:g} deep so the prefilter cup fits inside it in tap mode.",
          "11 and 12 are the v1 parts unchanged (M24 female taps; plain spouts Ø14–22).",
          "13: PCO side takes a bottle of clean water or item 10; M12×1 side screws onto the stem with the sleeve pulled open.",
          "14: cassette drops into the Ø45.4 pocket; a drop of water or Nile red stain, then the Ø50 cover glass on the 0.3 step.",
          "All tap faces sealed with S6; S7 on the face of 13."])
s.frame()
for (k, ox, oy, lab, dmin) in (("P10", 30, 70, "10 · TAP ADAPTER", (0, TAP["L"], 13.5, 20, f"{TAP['L']:g}")),
                               ("P11", 150, 70, "11 · M24 → M22", (0, 16, 13.5, 18, "16")),
                               ("P12", 230, 70, "12 · UNIVERSAL FERRULE", (0, 22, 12.5, 17, "22")),
                               ("P13", 30, 182, "13 · BACKFLUSH COUPLER", (0, BF["L"], 17, 22, f"{BF['L']:g}"))):
    v = View(s, ox, oy, 2.0)
    sec(v, k); v.cl(-4, 0, max(x for x, _ in P[k]) + 4, 0)
    v.dh(*dmin); rmax = max(y for _, y in P[k]); v.dv(-rmax, rmax, 0, -7, f"Ø{2 * rmax:g}")
    v.label_view(lab, max(x for x, _ in P[k]) / 2, -rmax - 10)
v = View(s, 30, 70, 2.0)
v.poly([(0, 8.5), (26.5, 8.5), (26.5, -8.5), (0, -8.5)], HID, 1.0, "none", dash="5 3"); v.t(2, 2, "prefilter (tap mode)", 9, 400, "start", HID)
v.note(8, 13.7, 14, 26, "28 PCO 1881 male"); v.note(39, -11, 44, -24, "M22×1.0-6H")
v = View(s, 30, 182, 2.0); v.note(8, 14.2, 16, 26, "28 PCO 1881 int."); v.note(37.5, -6, 46, -22, "M12×1.0-6H"); v.note(26, 7.25, 46, 14, "cavity for open sleeve")
v = View(s, 205, 175, 2.0)
hp = [(y, x) for x, y in P["P14"]]                                         # holder drawn lying flat: radius across, height up
v.poly(hp, INK, 1.4, "url(#h45)", close=True); v.poly([(-x, y) for x, y in hp], INK, 1.4, "url(#h45)", close=True)
v.rect(-20, HOLD["H"] - HOLD["pocket_depth"], 20, HOLD["H"] - HOLD["pocket_depth"] + CAS["t"], INK, 1.0, "url(#hins)")
v.rect(-25, HOLD["H"] - 0.3, 25, HOLD["H"] - 0.13, "#7fb3d5", 1.2, "#d6e9f5")
v.cl(0, -3, 0, 10)
v.dh(-28, 28, 0, -5, "Ø56"); v.dh(-22.7, 22.7, HOLD["H"] - HOLD["pocket_depth"], 11, "Ø45.4 pocket"); v.dv(0, HOLD["H"], 28, 33, f"{HOLD['H']:g}")
v.note(18, HOLD["H"] - 0.2, 32, 18, "Ø50 × 0.17 cover glass")
v.label_view("14 · INSPECTION HOLDER, CASSETTE IN (2:1)", 0, -12)
s.save(OUT + "MPx-SQ2-S05_Accessories.svg")

# ====================================================== S06 · SEALS, MATERIALS, PERFORMANCE ======================================================
s = Sheet(6, NS, "Seals, materials, interfaces, performance", "MPx-SQ2-020", "see tables", "—", "—", mass="—")
s.frame()
s.text(14 * PX, 22 * PX, "SEAL KIT · food-grade silicone 60 ShA, FDA 21 CFR 177.2600", 12, 700)
yend = table(s, 14, 26, ["ID", "Type", "Location", "Size", "Qty", "Side"], [list(map(str, r_)) for r_ in SEALS], [10, 22, 70, 34, 10, 30], size=9.4, rowh=5.6)
s.text(14 * PX, (yend + 8) * PX, "MATERIALS", 12, 700)
mats = [["316L stainless (EN 1.4404)", "1, 2a, 4, 5, frame, 10–14", "machine, electropolish + passivate (ASTM A967)"],
        ["Sintered 316L laminate", "2 prefilter cup", "20 µm Dutch weave on 0.5 perforated plate, sinter-bonded"],
        ["Sintered 316L, asymmetric", "disc A", "~0.2 mm fine layer on coarse 316L support; ISO 4003"],
        ["Sintered 316L powder", "discs B, C", "grade 0.2 / grade 0.5, 1.6 mm"],
        ["Silicone rubber 60 ShA", "S1–S7, 12 cone", "post-cured, unpigmented"],
        ["Borosilicate glass", "14 cover glass", "Ø50 × 0.17; inspection only, never in the water path"]]
yend = table(s, 14, yend + 11, ["Material", "Used in", "Requirement"], mats, [46, 40, 90], size=9.2, rowh=5.6)
s.text(14 * PX, (yend + 8) * PX, "INTERFACES", 12, 700)
itf = [["Bottle", "28 mm PCO 1881; 500 mL and 1 L PET (prefilter Ø17 needs neck bore ≥ Ø19)"],
       ["Tap", "M22×1 male → 10; M24×1 female → 11 + 10; plain Ø14–22 → 12 + 10"],
       ["Stem", "M12×1.0-6g: backflush coupler 13 now, optional UV cap later"],
       ["Microscope", "cassette in holder 14, Ø56 × 6; fits clip-on phone lenses and Foldscope stages"]]
table(s, 14, yend + 11, ["Interface", "Definition"], itf, [26, 150], size=9.2, rowh=5.6)
s.text(230 * PX, 22 * PX, "PERFORMANCE, CASSETTE A (model; verify by bench tests)", 12, 700)
perf = [["Envelope", f"Ø{MAX_D:g} × {OVERALL_L:g} mm + {INSIDE_BOTTLE:g} mm inside neck"], ["Core unit mass (CAD)", f"{UNIT:.0f} g (v1 315 g)"],
        ["Disc area / prefilter area", f"{disc_area_m2() * 1e4:.1f} cm² / {prefilter_area_cm2():.1f} cm²"],
        ["Squeeze 60 N → pressure", f"{P60:.2f} bar"], ["Clean flow at 60 N", f"{flow_Lmin(P60, A['KLt']):.2f} L/min (500 mL in {0.5 / flow_Lmin(P60, A['KLt']) * 60:.0f} s)"],
        ["Force for 0.3 L/min", f"{force_for(0.3, A['KLt']):.0f} N"], ["Tap 1.5 bar", f"{flow_Lmin(1.5, A['KLt']):.1f} L/min"],
        ["Capture 1 / 2 µm", f"≈{capture(1, A) * 100:.0f} % / ≥ 99 %"], ["Clean (backflush) every", f"≈{litres_to_half(A['KLt']):.1f} L tap water"],
        ["Wall safety factor, 3 bar", f"{hoop_SF(3):.0f}×"]]
yend = table(s, 230, 26, ["Quantity", "Value"], perf, [58, 117], size=9.2, rowh=5.6)
s.text(230 * PX, (yend + 8) * PX, "VALIDATION PLAN", 12, 700)
plan = ["1  Flux of each cassette vs ΔP (0.1–1.5 bar) on a rig; confirm the A-disc gain",
        "2  Squeeze: bottle pressure vs hand force on 5 local 500 mL / 1 L bottles",
        "3  Fouling: litres to half flow on tap and borewell water, with and without prefilter",
        "4  Backflush: flow recovered after each cycle, 10 cycles",
        "5  Challenge: 1, 2, 5, 10 µm PS beads; count before/after",
        "6  Inspection: Nile red on disc A vs bare disc; particles counted by phone lens",
        "7  Leak 1.5 bar air; drop 1 m on to concrete, 3 orientations"]
for i, l in enumerate(plan): s.text(230 * PX, (yend + 14 + i * 5.0) * PX, l, 10, 400)
s.text(14 * PX, 168 * PX, "v1 → v2", 12, 700)
cmp_ = [["Envelope", "Ø35 × 155.5 mm", f"Ø{MAX_D:g} × {OVERALL_L:g} mm (+{INSIDE_BOTTLE:g} in neck)"], ["Core mass", "315 g", f"{UNIT:.0f} g"],
        ["Core parts", "9", "5 (+ cassette)"], ["Stages", "40 µm screen + tube element", "20 µm prefilter cup + disc cassette"],
        ["Filter area", "55.6 cm²", f"{disc_area_m2() * 1e4:.1f} cm² disc + {prefilter_area_cm2():.0f} cm² prefilter"],
        ["Flow at 60 N", "0.33 L/min", f"{flow_Lmin(P60, A['KLt']):.2f} L/min (cassette A)"], ["Clean every", "≈26 L", f"≈{litres_to_half(A['KLt']):.0f} L"],
        ["Microplastic access", "unscrew head, rinse tube", "lift the disc out; it is the slide"]]
table(s, 14, 172, ["", "v1", "v2"], cmp_, [36, 60, 80], size=9.2, rowh=5.6)
s.save(OUT + "MPx-SQ2-S06_Seals_Materials_Performance.svg")
print("sheets ok")
