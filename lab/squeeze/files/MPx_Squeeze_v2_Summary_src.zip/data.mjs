import * as M from "./model.mjs";
const base = { F: 60, Ptap: 1.5, T: 25, cas: "A", bottle: "500", water: "tap", valve: true, mag: "140", stain: true, palm: 34, alpha: 1e13, pfCut: 0.4, mpPerL: 1000 };
const out = {};
const b5 = M.BOTTLES["500"];
// 1 flow vs force
out.force = { F: [], A: [], B: [], C: [] };
for (let F = 10; F <= 100; F += 5) { out.force.F.push(F); for (const k of ["A","B","C"]) out.force[k].push(M.flowLmin(M.handBar(F, b5, base, 1), { ...base, cas: k })); }
out.forceFor = Object.fromEntries(["A","B","C"].map(k => [k, M.forceFor(0.25, b5, { ...base, cas: k })]));
out.q60 = Object.fromEntries(["A","B","C"].map(k => [k, M.flowLmin(M.handBar(60, b5, base, 1), { ...base, cas: k })]));
out.hand60 = M.handBar(60, b5, base, 1);
// 2 valve vs no valve: cumulative mL vs time (60 s)
function runSq(inp, T, dt = 0.05) { const s = M.fresh(b5); const pts = []; for (let t = 0; t <= T; t += dt) { M.stepSqueeze(s, inp, dt); if (Math.round(t / dt) % 10 === 0) pts.push([s.t, s.litres * 1000, s.P]); } return { pts, s }; }
const rv = runSq(base, 185), rn = runSq({ ...base, valve: false }, 185);
out.valve = { yes: rv.pts, no: rn.pts, squeezes: rv.s.squeezes, tEnd: null };
// time to 500 mL with valve
{ const s = M.fresh(b5); let dt = 0.02; while (s.litres < 0.4995 && s.t < 400) M.stepSqueeze(s, base, dt); out.valve.t500 = s.t; out.valve.squeezes = s.squeezes; }
out.valve.noMax = rn.s.litres * 1000; out.valve.noVac = Math.min(...rn.pts.map(p => p[2]));
// 3 fouling: flow at 60N vs litres, tap water, backflush when flow < 50% clean; 0..20 L
function foul(inp, L = 20, bf = true) {
  const s = M.fresh(b5); const q0 = M.flowLmin(M.handBar(60, b5, inp, 1), inp); const pts = [[0, q0]]; const bfs = [];
  const step = 0.05;
  for (let l = step; l <= L + 1e-9; l += step) {
    const w = M.WATERS[inp.water];
    s.mPf += w.c * step / 1000 * inp.pfCut; s.mDisc += w.c * step / 1000 * (1 - inp.pfCut) * 0.9;
    let q = M.flowLmin(M.handBar(60, b5, inp, 1), inp, s);
    if (bf && q < 0.5 * q0) { pts.push([l, q]); for (let i = 0; i < 400; i++) M.stepBackflush(s, inp, 0.1); q = M.flowLmin(M.handBar(60, b5, inp, 1), inp, s); bfs.push([l, q / q0]); }
    pts.push([l, q]);
  }
  return { pts, bfs, q0 };
}
out.foul = { bf: foul(base), nobf: foul(base, 20, false) };
out.half = {};
for (const w of ["tap","bore","turbid"]) out.half[w] = Object.fromEntries(["A","B","C"].map(k => [k, M.litresToHalf({ ...base, water: w, cas: k }, M.fresh())]));
// fixes: prefilter catches more (pfCut 0.7), bigger disc area (Ø44 -> area ratio)
out.fix = {
  base: M.litresToHalf(base, M.fresh()),
  pf70: M.litresToHalf({ ...base, pfCut: 0.7 }, M.fresh()),
  pf90: M.litresToHalf({ ...base, pfCut: 0.9 }, M.fresh()),
  d44: M.litresToHalf(base, M.fresh()) * (44/38.5)**2 ** 1, // cake mass to double scales with area; litres ∝ area² (Rm/A and cake/A)
};
// 4 capture
out.bands = M.BANDS; out.share = M.bandShare();
out.cap = Object.fromEntries(["A","B","C"].map(k => [k, M.bandCapture(M.CASSETTES[k])]));
out.capPF = M.bandCapture(M.PREFILTER);
out.sub = Object.fromEntries(["A","B","C"].map(k => [k, M.bandCapture(M.CASSETTES[k], [M.SUB])[0]]));
out.curve = { d: [], A: [], B: [], C: [], PF: [] };
for (let i = 0; i <= 60; i++) { const d = 0.3 * (100/0.3) ** (i/60); out.curve.d.push(d); for (const k of ["A","B","C"]) out.curve[k].push(M.capture(d, M.CASSETTES[k])); out.curve.PF.push(M.capture(d, M.PREFILTER)); }
// 5 temperature
out.temp = { T: [], q: [], t500: [] };
for (let T = 5; T <= 40; T += 5) { const q = M.flowLmin(M.handBar(60, b5, base, 1), { ...base, T }); out.temp.T.push(T); out.temp.q.push(q); out.temp.t500.push(30 / q); }
// tap
out.tap = { P: [], q: [] }; for (let P = 0.5; P <= 4; P += 0.5) { out.tap.P.push(P); out.tap.q.push(M.flowLmin(P, base)); }
out.bubble = M.bubbleBar(1.0); out.sf = M.hoopSF(3);
out.Rm = Object.fromEntries(["A","B","C"].map(k => [k, M.Rm(M.CASSETTES[k].KLt)])); out.mu25 = M.mu(25); out.mu5 = M.mu(5);
const s = M.fresh(); s.lastRecovery = out.foul.bf.bfs[0]?.[1] ?? null;
out.req = M.requirements(base, s);
out.reqNoValve = M.requirements({ ...base, valve: false }, s)[3];
console.log(JSON.stringify(out));
