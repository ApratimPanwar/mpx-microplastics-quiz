import json, math
from lib import *

D = json.load(open("data.json"))
TOTAL = 17
SL = []          # (filename, title, body)


def add(fn, title, body):
    SL.append((fn, title, body))


def bullets(x, y, items, size=20, maxw=600, gap=14, dot=ORANGE, lh=None):
    s, yy = "", y
    for it in items:
        s += f'<circle cx="{x + 5}" cy="{yy - size * 0.33:.1f}" r="4" fill="{dot}"/>'
        p, h = P(x + 22, yy, it, size, maxw - 22, lh)
        s += p
        yy += h + gap
    return s, yy - y


# =====================================================================================
# 01 title
def s01():
    b = img(900, 0, 1020, 1080, "img/hero_clean.jpg")
    b += label(M, 120, "MPx · PD-298 · design review", 16, ORANGE)
    b += T(M, 250, "MPx Squeeze v2", 92, 600, INK, ls=-2.5)
    b += T(M, 316, "A pocket microplastic filter for PET bottles and taps", 32, 500, INK, ls=-0.3)
    p, h = P(M, 384, "What it does, what the virtual test bench showed, which of our 22 technical requirements it meets and misses, "
             "and the **design FMEA** that opens the next CED stage: embodiment design.", 23, 720, 34, 400, MUTED, bfill=INK)
    b += p
    stats = [("Ø52 × 50 mm", "outside the bottle"), ("202 g", "core unit, all 316L"), ("1 µm", "steel disc + 20 µm prefilter"), ("99.5 %", "of 1–100 µm particles caught*")]
    for i, (v, k) in enumerate(stats):
        x, y = M + (i % 2) * 380, 600 + (i // 2) * 150
        b += line(x, y, x + 340, y, INK, 1.5)
        b += T(x, y + 62, v, 50, 600, INK, ls=-1)
        b += T(x, y + 96, k, 19, 400, MUTED)
    b += T(M, 940, "* simulated on the virtual test bench; physical tests pending", 15, 400, FAINT)
    b += label(M, 1010, "Conceptual design ✓   →   Embodiment design (now)", 15, INK)
    add("01_title", "MPx Squeeze v2 — design review", b)


# =====================================================================================
# 02 CED
def s02():
    b, y0 = header(2, TOTAL, "Concepts chosen. The next CED stage is embodiment design",
                   "Our course puts **embodiment design** after concept selection, and names **FMEA** as its method for finding errors (lecture 2, slide 36). "
                   "Pahl & Beitz §10.4 says a design FMEA checks that the functions in the requirements list are fulfilled.")
    stages = [("Task clarification", "Lec 3–5", "Requirements list (22), SNPS, objective tree", "done"),
              ("Conceptual design", "Lec 6–8", "Function structure, ideation, morphological chart, 10 concepts", "done"),
              ("Simulation", "Lec 9", "Analytical + virtual test bench (this deck)", "done"),
              ("Evaluation & selection", "Lec 10", "Concepts 04, 07, 05 chosen; squeeze → v2", "done"),
              ("Embodiment design", "Now", "Layout, form, scale drawings, FMEA, optimisation", "now"),
              ("Detail design", "Next", "Tolerances, fits, final drawings, process FMEA", "next"),
              ("Production", "Later", "Production instructions, prototype ×3", "next")]
    n = len(stages); gap = 14; bw = (W - 2 * M - gap * (n - 1)) / n; y = 268; bh = 168
    for i, (t, l, d, st) in enumerate(stages):
        x = M + i * (bw + gap)
        fill, stroke, fg = (CARD, LINE, INK) if st == "done" else ((ORANGE, ORANGE, "#fff") if st == "now" else (BG, "#D3D1CA", MUTED))
        b += card(x, y, bw, bh, fill, stroke, 12)
        b += label(x + 18, y + 32, l, 13, "#fff" if st == "now" else (GREEN if st == "done" else FAINT))
        if st == "done":
            b += status_icon(x + bw - 26, y + 27, "done", 8)
        p, h = P(x + 18, y + 66, t, 21, bw - 30, 26, 600, fg)
        b += p
        p2, _ = P(x + 18, y + 72 + h, d, 15, bw - 30, 20, 400, "#FFE9DF" if st == "now" else MUTED)
        b += p2
        if i < n - 1:
            b += T(x + bw + gap / 2, y + bh / 2 + 6, "›", 22, 600, FAINT, "middle")
    # embodiment checklist
    y = 470
    b += card(M, y, 1140, 520)
    b += label(M + 32, y + 44, "Embodiment design steps (lecture 2, slide 36) and where v2 stands", 14, INK)
    rows = [("done", "Overall layout: general arrangement, spatial compatibility", "v2 drawing set S01–S06, STEP models, Ø52 × 50 mm envelope"),
            ("done", "Preliminary form design: shapes, materials, processes", "316L CNC parts, sintered 316L disc and prefilter, silicone seals; BOM ₹14,900/kit"),
            ("half", "Apply all major criteria: technical, economic, environmental, aesthetic, ergonomic", "Technical by simulation (slides 5–12). Cost at volume and grip ergonomics still open"),
            ("half", "Develop with scale drawings and critical reviews", "Drawings done; this deck is the first critical review"),
            ("now", "Use methods for identification of errors (e.g. FMEA)", "Draft design FMEA in this deck (slides 13–16): 20 failure modes, 12 critical"),
            ("next", "Apply methods for optimisation", "v2.1 changes from the FMEA, then re-simulate with bench-measured values"),
            ("next", "Outcome: embodiment (layout) ready for detail design", "After bench tests 1–7 confirm the model")]
    ty = y + 74
    for k, (st, step, ev) in enumerate(rows):
        if k:
            b += line(M + 32, ty - 8, M + 1108, ty - 8, "#EFEDE7")
        b += status_icon(M + 46, ty + 15, st)
        p, h1 = P(M + 70, ty + 22, step, 18, 470, 23, 600 if st == "now" else 500, INK)
        p2, h2 = P(M + 570, ty + 22, ev, 17, 540, 23, 400, MUTED)
        b += p + p2
        ty += max(h1, h2) + 16
    # right callout
    x = M + 1170; w = W - M - x
    b += card(x, y, w, 520, ORANGE_BG, "#F4C9B5")
    b += label(x + 32, y + 44, "So: can we do an FMEA now?", 14, ORANGE)
    p, h = P(x + 32, y + 88, "**Yes, and it is the right next step.** The layout and forms exist, and the simulation tells us how each part behaves, "
             "so we can rate occurrence and severity with numbers rather than guesses.", 19, w - 64, 27)
    b += p
    bl, h2 = bullets(x + 32, y + 100 + h + 18, [
        "Design FMEA: every part and use step (squeeze, tap, backflush, inspect)",
        "Risk number RN = O × S × D, each rated 1–10; **RN > 125 is critical** (Pahl & Beitz)",
        "Ratings here are a first draft from the simulation; the team should review them together, as P&B recommend",
        "Process FMEA (CNC, sintering, welding) belongs to detail design"], 17, w - 64, 10)
    b += bl
    b += footer("Sources: CED lec02 sl. 36–37, lec06 process slide; Pahl & Beitz, Engineering Design 3e, §10.4")
    add("02_ced_next_step", "Where we are in the CED process", b)


# =====================================================================================
# 03 what it does
def s03():
    b, y0 = header(3, TOTAL, "What the product does",
                   "It screws onto a 28 mm PET bottle (or a tap) and filters microplastics as you squeeze. The removable steel disc is also the sample: "
                   "lift it out and look at what it caught under a phone microscope.")
    y = 262; bot = 990
    b += img(M, y, 470, bot - y, "img/bottle_crop.jpg", r=14)
    x = M + 500; w = 640
    steps = [("Fit", "Screw onto any 500 mL or 1 L PET bottle (28 mm PCO 1881 neck). A tap adapter lets tap pressure do the work: **2.2 L/min at 1.5 bar**."),
             ("Squeeze", "Water goes through the built-in **20 µm prefilter**, then the removable **1 µm sintered steel disc**. "
                         "At 60 N, **27 squeezes** empty 500 mL: **115 s** of squeezing, about **170 s** with the pauses to let go. On release, an umbrella valve lets air back in."),
             ("Inspect", "Lift the disc into the holder. Nile red stain + blue LED + a 140× clip-on lens shows plastic particles **down to 2 µm**."),
             ("Clean", "Backflush with tap water through the spout: the cake comes off and **97 %** of the clean flow returns.")]
    hs = [56 + plines(d, 18, w - 50) * 26 for _, d in steps]
    gap_ = (bot - y - 6 - sum(hs)) / (len(steps) - 0.6)
    yy = y + 6
    for i, (t, d) in enumerate(steps):
        b += num_badge(x + 18, yy + 16, i + 1, 18, INK, size=16)
        b += T(x + 50, yy + 23, t, 23, 600)
        p, h = P(x + 50, yy + 56, d, 18, w - 50, 26, 400, MUTED, bfill=INK)
        b += p
        if i < len(steps) - 1:
            b += line(x + 50, yy + hs[i] + gap_ / 2 - 10, x + w, yy + hs[i] + gap_ / 2 - 10, LINE)
        yy += hs[i] + gap_
    # spec card
    x2 = x + w + 30; w2 = W - M - x2
    spec = [("Size", "Ø52 × 50 mm outside the bottle, +12.5 mm inside the neck"),
            ("Mass", "202 g core unit; accessories 326 g"),
            ("Materials", "316L body, sintered 316L filters, FDA silicone seals. No plastic in the water path"),
            ("Prefilter", "20 µm laminate cup, 17.2 cm², built in"),
            ("Disc", "Ø40 cassette, 11.6 cm² active: A 1 µm (default), B 1.4 µm, C 2.5 µm"),
            ("Flow", "0.26 L/min squeezed at 60 N; 2.2 L/min on a 1.5 bar tap"),
            ("Capture", "99.5 % of 1–100 µm particles by count; 99 % at 1–2 µm (simulated)"),
            ("Cost", "Prototype kit ₹14,900; 3 kits ₹44,700, inside the ₹50,000 cap")]
    rows, yy = "", y + 86
    for k, v in spec:
        rows += T(x2 + 28, yy, k, 16, 600, MUTED)
        p, h = P(x2 + 140, yy, v, 17, w2 - 168, 23)
        rows += p
        yy += h + 15
        rows += line(x2 + 28, yy - 8, x2 + w2 - 28, yy - 8, "#EFEDE7")
    ch = yy - y + 6
    b += card(x2, y, w2, ch) + label(x2 + 28, y + 42, "Key numbers", 13, INK) + rows
    sy = y + ch + 20
    b += card(x2, sy, w2, bot - sy, GREY_BG, GREY_BG)
    b += label(x2 + 28, sy + 40, "Covers all three parts of our SNPS", 13, INK)
    cols = [("Remove", "the filter on the bottle"), ("Detect", "the disc is the slide"), ("Contain", "the catch stays on steel")]
    cw = (w2 - 56) / 3
    for i, (a_, c_) in enumerate(cols):
        b += T(x2 + 28 + i * cw, sy + 84, a_, 22, 600, ORANGE)
        p, _ = P(x2 + 28 + i * cw, sy + 112, c_, 16, cw - 16, 21, 400, MUTED)
        b += p
    b += footer("Numbers from the v2 drawing set, BOM and the test-bench model (sq2 model.mjs)")
    add("03_what_it_does", "What the product does", b)


# =====================================================================================
# 04 inside
def s04():
    b, y0 = header(4, TOTAL, "How water moves through it",
                   "Two filter stages in series, sealed by two O-rings above and below the disc cassette. Those O-rings are the only barrier between dirty and clean water.")
    y = 250
    cw_ = 960
    b += card(M, y, cw_, 740)
    sc_ = 720 / 2972; iw = 3596 * sc_; ix = M + (cw_ - iw) / 2; iy = y + 10
    b += img(ix, iy, iw, 720, "img/cut.jpg", fit="meet")
    pts = [(2481, 1169, 1), (2700, 1868, 2), (2126, 1990, 3), (2481, 3083, 4), (1790, 1610, 5)]
    for ox, oy, n_ in pts:
        px, py = ix + (ox - 587) * sc_, iy + (oy - 268) * sc_
        b += f'<circle cx="{px:.1f}" cy="{py:.1f}" r="17" fill="#fff"/>' + num_badge(round(px, 1), round(py, 1), n_, 14, ORANGE if n_ < 5 else BLUE, size=14)
    x = M + cw_ + 30; w = W - M - x
    steps = [("Into the prefilter", "Bottle water passes outside-in through the 20 µm cup. Sand, fibres and plastic over 20 µm stay in the bottle side."),
             ("Over the disc", "It spreads under 8 roof ribs across the full 38.5 mm disc face."),
             ("Through the 1 µm disc", "The sintered 316L disc catches particles on its top face. The cake that forms there is what you inspect."),
             ("Out of the spout", "Filtered water runs between 8 drain ribs to a Ø2 port in the stem and out through the push-pull sleeve."),
             ("Air back in", "When you let go, the silicone umbrella valve opens at 0.03 bar and the bottle springs back. The wet disc cannot pass air: it needs 2.9 bar.")]
    yy = y + 20
    for i, (t, d) in enumerate(steps):
        b += num_badge(x + 16, yy + 12, i + 1, 16, ORANGE if i < 4 else BLUE, size=15)
        b += T(x + 46, yy + 19, t, 21, 600)
        p, h = P(x + 46, yy + 48, d, 17, w - 46, 24, 400, MUTED)
        b += p
        yy += 48 + h + 18
    b += card(x, y + 740 - 110, w, 110, GREY_BG, GREY_BG)
    p, h = P(x + 22, y + 740 - 70, "**Not yet in the v2 drawings or BOM:** the air-return valve and the silicone grip ring. Both are shown here and used in the simulation.", 16, w - 44, 23, 400, MUTED, bfill=INK)
    b += p
    b += footer("Cutaway: teardown drawing built from the v2 drawing-set profiles; threads omitted")
    add("04_how_it_works", "How water moves through it", b)


# =====================================================================================
# 05 bench screenshots
def s05():
    b, y0 = header(5, TOTAL, "The virtual test bench: four experiments",
                   "An interactive simulation of the bench we plan to build. A press squeezes the bottle with a set force and every number on screen comes from one physics model.")
    shots = [("sq", "Squeeze, valve fitted", "60 N on a 500 mL bottle gives **0.17 bar** and **0.26 L/min**. The bottle refills with air after each squeeze: 500 mL in **27 squeezes**, 168 s including release pauses."),
             ("nv", "Same squeeze, no valve", "No air can get back in. Near **140 mL** the dented bottle holds **0.17 bar of vacuum**, equal to the squeeze, and flow stops."),
             ("bf", "Backflush", "Tap water runs backwards: spout → disc → prefilter → out of the inlet. The cake lifts in about 9 s; **97 %** of clean flow returns."),
             ("insp", "Lift the cassette and look", "The disc goes into the holder, cake up. With Nile red at 140×, particles from **2 µm** are visible (20 µm unstained).")]
    gap = 24; w = (W - 2 * M - gap * 3) / 4; y = 262; ih = w
    for i, (f, t, d) in enumerate(shots):
        x = M + i * (w + gap)
        b += img(x, y, w, ih, f"img/{f}_sq.jpg", r=12, stroke=LINE)
        b += T(x, y + ih + 40, t, 20, 600)
        p, h = P(x, y + ih + 72, d, 16, w - 4, 23, 400, MUTED, bfill=INK)
        b += p
    yb = 900
    b += card(M, yb, W - 2 * M, 92, GREY_BG, GREY_BG)
    p, h = P(M + 28, yb + 38, "**What the model includes:** hand force → bottle pressure · Darcy flow through prefilter, cake and disc in series · water viscosity vs temperature · "
             "bottle vacuum without a valve · cake build-up and backflush · capture curve per particle size · Nile red visibility. "
             "Open it from Desktop › MPx › Squeeze_v2 › simulation.", 16, W - 2 * M - 56, 23, 400, MUTED, bfill=INK)
    b += p
    b += footer("Screenshots: MPx_Squeeze_v2_test_bench.html, cassette A, tap water, 25 °C")
    add("05_sim_bench", "Virtual test bench screenshots", b)


# =====================================================================================
# 06 readouts
def s06():
    b, y0 = header(6, TOTAL, "What the bench reads out while it runs",
                   "Live charts, a requirements table that turns red or green as you change inputs, and the view through the phone microscope.")
    y = 250
    lw = 860
    rh = lw * 545 / 1200
    b += img(M, y, lw, rh, "img/req.jpg", r=10, stroke=LINE)
    mh = lw * 452 / 1200
    b += img(M, y + rh + 24, lw, mh, "img/micro.jpg", r=10, stroke=LINE)
    x = M + lw + 30; w = W - M - x
    cw = (w - 20) / 2; ch = cw * 590 / 700
    b += img(x, y, cw, ch, "img/chart1.jpg", r=10, stroke=LINE)
    b += img(x + cw + 20, y, cw, ch, "img/chart2.jpg", r=10, stroke=LINE)
    yy = y + ch + 24
    b += card(x, yy, w, y + rh + 24 + mh - yy)
    b += label(x + 28, yy + 40, "How to read them", 13, INK)
    bl, _ = bullets(x + 28, yy + 82, [
        "**Force needed for flow:** cassettes A and C reach 0.25 L/min at 58 N; B (catalogue 0.2 grade) needs about 180 N.",
        "**Flow as the disc loads:** on tap water the flow halves after about 2.2 L. That is the one engineering check that fails.",
        "**Requirements table:** 12 pass, 1 fail (filter life), 1 not claimed (below 1 µm).",
        "**Microscope:** after 1 L there are only 0.1–0.2 particles per 0.64 mm field, so counting 100 particles means scanning about 560 fields."],
        17, w - 56, 12)
    b += bl
    b += footer("Screenshots from the test bench at default settings")
    add("06_sim_readouts", "Bench readouts", b)


# =====================================================================================
# 07 calculations
def s07():
    b, y0 = header(7, TOTAL, "The calculations behind the numbers",
                   "Eight hand-checkable equations. Each card shows the formula, our values, and the result the simulation uses.")
    cards = [
        ("1  Squeeze pressure", "P = (F − F_{wall}) / A_{palm} + ρ·g·h",
         "(60 − 4) N ÷ 34 cm² + 1000 × 9.81 × 0.126 m\n= 0.165 + 0.012 bar", "0.177 bar", "Hand force spreads over the palm; the water column adds a little."),
        ("2  Flow, resistances in series", "Q = ΔP / [µ (R_{disc}/A_{disc} + R_{pf}/A_{pf})]",
         "Mott: K·t = 26 × 1.5 / 3 = 13 → R = 5.2×10⁹ m⁻¹\nµ(25 °C) = 0.89 mPa·s → 1.47 L/min per bar\n0.177 bar × 1.47", "0.26 L/min", "115 s per 500 mL of squeezing; 168 s with release pauses."),
        ("3  Force for 15 L/h", "F = (Q / q_{1} − ρgh) · A_{palm} + F_{wall}",
         "(0.25 / 1.471 − 0.012) bar × 34 cm² + 4 N\n= 0.158 bar × 34 cm² + 4 N", "58 N", "Above the team's 50 N wish (5.1)."),
        ("4  Why the valve is needed", "P_{vac} = k·ΔV/V ;  P_{bubble} = 4γ / d",
         "0.6 bar × 0.30 = 0.18 bar ≥ 0.177 bar squeeze\n4 × 0.072 N/m ÷ 1 µm = 2.9 bar to push air back", "stalls ~140 mL", "Air can't return through the wet disc; a 0.03 bar umbrella valve fixes it."),
        ("5  When flow halves (cake)", "R = R_{m} + α·m/A  →  m_{½} = R_{m}·A / α",
         "5.2×10⁹ m⁻¹ × 11.64 cm² ÷ 10¹³ m/kg = 0.60 mg\n0.5 mg/L × (1 − 0.4) × 0.9 = 0.27 mg/L reaches the disc", "2.2 L", "Target 20 L: fails. Fix the prefilter."),
        ("6  Capture by size", "E(d) = 1 / (1 + (d_{50} / d)ᵏ)",
         "Cassette A: d₅₀ = 0.75 µm, k = 10\nParticle count ~ d⁻², so the 1–2 µm band holds 51 % of all 1–100 µm particles", "99.5 %", "99.0 % at 1–2 µm; 15 % below 1 µm (not claimed)."),
        ("7  Cap strength", "σ_{hoop} = P·r / t ;  SF = σ_{y} / σ",
         "3 bar × 24 mm ÷ 1.6 mm = 4.5 MPa\n170 MPa (316L yield) ÷ 4.5 MPa", "SF 38", "Wall is sized by machining and threads, not pressure."),
        ("8  Cold water", "µ(T) = 2.414×10⁻⁵ · 10^(247.8 / (T + 133.15))",
         "µ(5 °C) = 1.52 mPa·s vs 0.89 mPa·s at 25 °C\nflow ~ 1 / µ", "−41 % flow", "500 mL takes 194 s at 5 °C (8.2)."),
    ]
    cols, gap = 4, 22
    w = (W - 2 * M - gap * (cols - 1)) / cols; h = 360; y = 252
    for i, (t, f, sub, res, note) in enumerate(cards):
        x = M + (i % cols) * (w + gap); yy = y + (i // cols) * (h + gap)
        b += card(x, yy, w, h)
        b += T(x + 24, yy + 40, t, 18, 600)
        b += rect(x + 24, yy + 60, w - 48, 54, GREY_BG, 8)
        fs = 19
        while fw(f, fs, 500) > w - 72 and fs > 12:
            fs -= 0.5
        b += F(x + 36, yy + 94, f, fs, 500, INK)
        p, ph = P(x + 24, yy + 148, sub, 16, w - 48, 23, 400, MUTED)
        b += p
        b += T(x + 24, yy + 148 + ph + 44, res, 38, 600, ORANGE, ls=-0.5)
        p, _ = P(x + 24, yy + 148 + ph + 78, note, 16, w - 48, 22, 400, MUTED)
        b += p
    b += footer("Inputs: v2 drawings (areas), Mott sintered-media K, assumed palm 34 cm², α = 10¹³ m/kg, 0.5 mg/L solids, prefilter takes 40 %")
    add("07_calculations", "Calculations", b)


# =====================================================================================
# 08 flow results
def s08():
    b, y0 = header(8, TOTAL, "Result 1 · Flow: a 60 N squeeze meets 15 L/h only while squeezing",
                   "The asymmetric disc A is what makes this work: it flows like the coarse 2.5 µm disc C while filtering like a 1 µm membrane.")
    y = 250; w = (W - 2 * M - 30) / 2; h = 740
    # chart 1
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Flow vs hand force, 500 mL bottle, 25 °C", 20, 600)
    c = Chart(M + 10, y + 70, w - 30, 515, (10, 100), (0, 0.45), pad=(80, 20, 20, 64))
    c.zone(60, 100, 0.25, 0.45, "#EAF4ED")
    c.axes([20, 40, 60, 80, 100], [0, 0.1, 0.2, 0.3, 0.4], "hand force, N", "flow, L/min", yfmt=lambda v: f"{v:.1f}")
    c.hline(0.25, MUTED, "6 5", "15 L/h target (2.1)", "left", 14, -8)
    c.vline(50, RED, "4 4", "team wish 50 N (5.1)", 14, -6, c.py1 + 16)
    c.vline(60, MUTED, "6 5", "comfortable 60 N", 14, 6, c.py1 + 16)
    F = D["force"]["F"]
    c.path(list(zip(F, D["force"]["C"])), SERIES["C"], 2.2, "7 6")
    c.path(list(zip(F, D["force"]["B"])), SERIES["B"], 2.6)
    c.path(list(zip(F, D["force"]["A"])), SERIES["A"], 3)
    c.text(100, D["force"]["A"][-1], "A 1 µm · C 2.5 µm", 15, 600, INK, "end", 0, -14)
    c.text(100, D["force"]["B"][-1], "B 1.4 µm", 15, 600, SERIES["B"], "end", 0, -12)
    c.dot(60, D["q60"]["A"], ORANGE)
    c.text(60, D["q60"]["A"], "0.26 L/min", 16, 600, ORANGE, "start", 12, 26)
    b += c.svg()
    bl, _ = bullets(M + 30, y + 636, [
        "**58 N** gives 0.25 L/min with A. **Passes** our 60 N comfort limit, **misses** the team's 50 N wish (5.1): 50 N gives 13 L/h.",
        "B, the catalogue 0.2-grade disc, needs about **180 N**. A is the highest-risk buy item, so the RFQ must ask for flux data."],
        17, w - 60, 10)
    b += bl
    # chart 2
    x = M + w + 30
    b += card(x, y, w, h)
    b += T(x + 30, y + 46, "Squeezing time for 500 mL vs water temperature, 60 N", 20, 600)
    c = Chart(x + 10, y + 70, w - 30, 515, (0, 8), (0, 220), pad=(80, 20, 20, 64))
    c.axes([], [0, 50, 100, 150, 200], "", "seconds for 500 mL", yfmt=lambda v: f"{v:.0f}")
    c.hline(120, INK, "6 5", "120 s target", "right", 14, -8)
    bwid = (c.px1 - c.px0) / 8 * 0.62
    for i, (T_, t5) in enumerate(zip(D["temp"]["T"], D["temp"]["t500"])):
        cx = c.X(i + 0.5)
        col = RED if t5 > 120 else ("#3D3D39" if T_ != 25 else ORANGE)
        c.parts.append(rect(cx - bwid / 2, c.Y(t5), bwid, c.Y(0) - c.Y(t5), col, 4))
        c.parts.append(T(cx, c.Y(t5) + 26, f"{t5:.0f} s", 16, 600, "#fff", "middle"))
        c.parts.append(T(cx, c.py0 + 26, f"{T_} °C", 14, 500, MUTED, "middle"))
    c.parts.append(T((c.px0 + c.px1) / 2, c.py0 + 54, "water temperature", 15, 500, MUTED, "middle"))
    b += c.svg()
    bl, _ = bullets(x + 30, y + 636, [
        "Squeezing time only. At 25 °C, 500 mL takes **115 s**; below about **20 °C** it misses 120 s.",
        "Counting the 1.4 s release after each 5 s squeeze, 500 mL takes **168 s**: an average of **10.7 L/h**.",
        "At **5 °C** viscosity cuts flow by **41 %**. Usable over 5–45 °C (8.2), but slow."],
        17, w - 60, 10)
    b += bl
    b += footer("Computed with model.mjs: flowLmin(handBar(F)), viscosity µ(T)")
    add("08_results_flow", "Results: flow", b)


# =====================================================================================
# 09 valve + fouling
def s09():
    b, y0 = header(9, TOTAL, "Result 2 · The air valve is essential, and the disc fouls fast",
                   "Without a way for air to return, a bottle stalls after one squeeze. With it, the limit becomes how quickly fine solids clog the 1 µm disc.")
    y = 250; w = (W - 2 * M - 30) / 2; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Water delivered vs time, 60 N squeezes, 500 mL bottle", 20, 600)
    c = Chart(M + 10, y + 70, w - 30, 515, (0, 185), (0, 540), pad=(80, 20, 30, 64))
    c.axes([0, 30, 60, 90, 120, 150, 180], [0, 100, 200, 300, 400, 500], "time, s", "filtered water, mL", yfmt=lambda v: f"{v:.0f}")
    c.vline(120, MUTED, "6 5", "120 s target", 14, -6, c.py1 + 16)
    yes = [(t, v) for t, v, p in D["valve"]["yes"] if t <= D["valve"]["t500"] + 0.3]
    no = [(t, v) for t, v, p in D["valve"]["no"]]
    c.path(no, RED, 3)
    c.path(yes, INK, 3)
    c.dot(D["valve"]["t500"], 500, ORANGE)
    c.text(D["valve"]["t500"], 500, "500 mL in 168 s", 16, 600, ORANGE, "end", -12, -12)
    c.text(183, 144, "no valve: stops near 140 mL", 16, 600, RED, "end", 0, -14)
    c.text(8, 330, "with valve: 27 squeezes", 16, 600, INK, "start", 0, 0)
    b += c.svg()
    bl, _ = bullets(M + 30, y + 636, [
        "Without a valve, a dented bottle pulls **0.17 bar** of vacuum, as much as the squeeze. Flow stops near **140 mL**.",
        "Air can't come back through the wet 1 µm disc: that needs **2.9 bar** (bubble point). A **0.03 bar umbrella valve** solves it."],
        17, w - 60, 10)
    b += bl
    x = M + w + 30
    b += card(x, y, w, h)
    b += T(x + 30, y + 46, "Flow at 60 N vs litres filtered, tap water (0.5 mg/L)", 20, 600)
    c = Chart(x + 10, y + 70, w - 30, 515, (0, 20), (0, 0.3), pad=(80, 20, 30, 64))
    c.axes([0, 5, 10, 15, 20], [0, 0.1, 0.2, 0.3], "litres filtered", "flow, L/min", yfmt=lambda v: f"{v:.1f}")
    q0 = D["foul"]["bf"]["q0"]
    c.hline(q0 / 2, AMBER, "6 5", "half the clean flow → backflush", "right", 14, 18)
    c.path(D["foul"]["nobf"]["pts"], FAINT, 2.4, "7 6")
    c.path(D["foul"]["bf"]["pts"], INK, 2.4)
    for l, r in D["foul"]["bf"]["bfs"]:
        c.dot(l, r * q0, ORANGE, 4.5, False)
    c.text(3.4, 0.272, "backflush every ~2 L", 15, 600, ORANGE)
    c.text(11, 0.058, "no backflush", 15, 600, MUTED)
    b += c.svg()
    bl, _ = bullets(x + 30, y + 636, [
        "Flow halves after **2.2 L** of tap water: **fails** our 20 L target and the team's 100 L filter rating (9.1).",
        "Backflush returns **97 %**, falling to **80 %** after 9 flushes (3 % stays each time). The disc is spent after **~75 L**."],
        17, w - 60, 10)
    b += bl
    b += footer("Computed with model.mjs: stepSqueeze (valve on/off), cake filtration + stepBackflush")
    add("09_results_valve_fouling", "Results: valve and fouling", b)


# =====================================================================================
# 10 capture + life
def s10():
    b, y0 = header(10, TOTAL, "Result 3 · It catches what we claim; filter life needs a better prefilter",
                   "Capture is strong down to 1 µm. Filter life fails, and the simulation points at the fix: stop fine solids before they reach the disc.")
    y = 250; w = (W - 2 * M - 30) / 2; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Share of particles caught vs particle size", 20, 600)
    c = Chart(M + 10, y + 70, w - 30, 515, (0.3, 100), (0, 1.05), xlog=True, pad=(80, 64, 30, 64))
    c.parts.append(T(c.px0 - 10, c.py1 - 30, "share of", 13, 500, MUTED, "end"))
    c.parts.append(T(c.px0 - 10, c.py1 - 12, "all particles", 13, 500, MUTED, "end"))
    shares = D["share"]
    for (a, bb), s_ in zip(D["bands"], shares):
        c.zone(a, bb, 0, 1.0, "#F6F4EF" if a in (1, 5) else "#FFFFFF")
        c.parts.append(T((c.X(a) + c.X(bb)) / 2, c.py1 - 30, f"{s_ * 100:.0f} %", 16, 600, INK, "middle"))
        c.parts.append(T((c.X(a) + c.X(bb)) / 2, c.py1 - 12, f"{a}–{bb} µm", 13, 400, MUTED, "middle"))
    c.axes([0.3, 1, 2, 5, 20, 100], [0, 0.25, 0.5, 0.75, 1.0], "particle size, µm (log)", "share caught", xfmt=lambda v: f"{v:g}", yfmt=lambda v: f"{v * 100:.0f} %", grid=False)
    cv = D["curve"]
    c.path(list(zip(cv["d"], cv["PF"])), ORANGE, 2.4, "7 6")
    c.path(list(zip(cv["d"], cv["C"])), SERIES["C"], 2.4, "3 5")
    c.path(list(zip(cv["d"], cv["B"])), SERIES["B"], 2.4)
    c.path(list(zip(cv["d"], cv["A"])), INK, 3)
    c.text(0.55, 0.62, "A", 17, 700, INK, "end")
    c.text(1.05, 0.55, "B", 17, 700, SERIES["B"], "start")
    c.text(1.75, 0.45, "C", 17, 700, SERIES["C"], "start")
    c.text(26, 0.5, "prefilter 20 µm", 15, 600, ORANGE, "start")
    b += c.svg()
    bl, _ = bullets(M + 30, y + 636, [
        "Cassette A: **99.0 %** at 1–2 µm, **100 %** above 2 µm, **99.5 %** overall by count. **Passes** 6.1 including the 99 % stretch.",
        "Below 1 µm only **15 %**, so we don't claim nanoplastics. C (2.5 µm) lets **65 %** of 1–2 µm particles through."],
        17, w - 60, 10)
    b += bl
    x = M + w + 30
    b += card(x, y, w, h)
    b += T(x + 30, y + 46, "Litres until flow halves (between backflushes)", 20, 600)
    rows = [("A on tap water (v2 today)", D["half"]["tap"]["A"], RED),
            ("A on borewell water", D["half"]["bore"]["A"], RED),
            ("A on turbid surface water", D["half"]["turbid"]["A"], RED),
            ("Ø44 disc instead of Ø38.5", D["fix"]["d44"], AMBER),
            ("Prefilter that catches 70 %", D["fix"]["pf70"], AMBER),
            ("5–10 µm depth prefilter (90 %)", D["fix"]["pf90"], GREEN),
            ("Depth prefilter + Ø44 disc", D["fix"]["pf90"] * (44 / 38.5) ** 2, GREEN)]
    cx0 = x + 330; cx1 = x + w - 60; yy = y + 100; rh = 58
    sc = lambda v: cx0 + v / 20 * (cx1 - cx0)
    for v in [0, 5, 10, 15, 20]:
        b += line(sc(v), yy - 10, sc(v), yy + rh * len(rows), "#EFEDE7")
        b += T(sc(v), yy + rh * len(rows) + 24, f"{v}", 14, 400, MUTED, "middle")
    b += T((cx0 + cx1) / 2, yy + rh * len(rows) + 50, "litres", 15, 500, MUTED, "middle")
    b += line(sc(20), yy - 22, sc(20), yy + rh * len(rows), INK, 1.5, "6 5")
    b += T(sc(20), yy - 30, "20 L target", 14, 600, INK, "end")
    for i, (k, v, col) in enumerate(rows):
        ry = yy + i * rh
        if i == 3:
            b += label(x + 30, ry - 4, "Fixes, tap water", 12, FAINT)
        b += T(x + 30, ry + 26, k, 16, 500 if i else 600, INK)
        b += rect(cx0, ry + 8, max(3, sc(v) - cx0), 28, col, 4)
        b += T(sc(v) + 8, ry + 28, f"{v:.1f}" if v >= 1 else f"{v:.2f}", 15, 600, col)
    bl, _ = bullets(x + 30, y + 636, [
        "Today only 40 % of the solids stop at the 20 µm prefilter. A **5–10 µm depth prefilter** that stops 90 % gives **13 L** between backflushes.",
        "With a Ø44 disc as well: **18 L**. Borewell and turbid water need settling first."],
        17, w - 60, 10)
    b += bl
    b += footer("Computed with model.mjs: bandCapture(), litresToHalf(); fixes scale disc area and prefilter share")
    add("10_results_capture_life", "Results: capture and filter life", b)


# =====================================================================================
# 11 requirements (team list)
REQ = [
    (1, "6.1", "Removal ≥ 90 % by count, 1 µm–5 mm (stretch 99 %)", "99.5 % overall; 99.0 % at 1–2 µm", "Sim", "pass"),
    (2, "3.2", "Filter medium sheds no secondary micro/nanoplastic", "All-metal filters; silicone seals in the water path", "Design", "design"),
    (3, "6.2", "Detection false +/− ≤ 10 % vs reference microscopy", "Sees ≥ 2 µm with Nile red; error rate not measured", "Sim (partly)", "open"),
    (4, "10.2", "Captured microplastics stay contained", "Backflush moves 97 % of the cake out; where it goes is up to the user", "Sim", "risk"),
    (5, "4.1", "Result through ≥ 1 user feedback channel", "Phone microscope view of the disc; manual count", "Design", "partial"),
    (6, "11.1", "Retail price ₹1,500–6,000", "Prototype ₹14,900/kit at qty 3; volume cost not estimated", "BOM", "open"),
    (7, "3.1", "Water-contact parts food-contact safe", "316L + FDA 21 CFR 177.2600 silicone", "Spec", "design"),
    (7, "3.4", "No leachables above IS 10500", "Electropolished, passivated 316L (ASTM A967)", "Spec", "design"),
    (9, "2.1", "Flow rate ≥ 15 L/h", "15.6 L/h while squeezing, 10.7 L/h with pauses; 132 L/h on a tap", "Sim", "partial"),
    (9, "1.1", "Per-use capacity for 1–3 L/day", "3 L ≈ 17 min of squeezing and pauses; backflush about daily", "Sim", "partial"),
    (9, "10.1", "Disposal pathway for spent filters (W)", "316L is recyclable scrap; process not defined", "—", "open"),
    (9, "1.2", "Non-destructive sampling (W)", "The disc itself is the slide", "Design", "met"),
    (9, "5.3", "Display legible outdoors (W)", "No own display; uses the phone", "—", "na"),
    (14, "9.1", "Filter rated ≥ 100 L or 3 months", "Flow halves at 2.2 L; disc spent at ~75 L with backflush", "Sim", "fail"),
    (14, "7.1", "Filter swap tool-free in ≤ 30 s", "Unscrew by hand, lift cassette; not timed", "Design", "design"),
    (14, "4.2", "Alert near filter end-of-life", "None; only slower flow", "Design", "fail"),
    (14, "5.2", "Spout parts detachable and washable", "Push-pull sleeve slides off the stem", "Design", "met"),
    (14, "8.2", "Usable at 5–45 °C", "Works; at 5 °C flow is 41 % lower (9.3 L/h)", "Sim", "partial"),
    (19, "3.3", "Housing UV and impact resistant (W)", "316L", "Design", "design"),
    (19, "3.5", "Survives 1 m drop (W)", "Cap SF 38 at 3 bar; drop not tested", "Calc", "open"),
    (21, "5.1", "Actuation force ≤ 50 N (W)", "58 N needed for 15 L/h; 50 N gives 13 L/h", "Sim", "fail"),
    (21, "8.1", "Noise ≤ 60 dB(A) (W)", "No motor", "Design", "met"),
]


def s11():
    b, y0 = header(11, TOTAL, "Our 22 technical requirements: what v2 meets and what it doesn't",
                   "Ranked by our weighted objective tree. **Pass · sim**: the simulation shows it. **By design**: the choice should meet it, but nothing has tested it yet.")
    # summary chips
    y = 238
    cnt = {}
    for r in REQ:
        cnt[r[5]] = cnt.get(r[5], 0) + 1
    xx = M
    for k in ["pass", "met", "design", "partial", "fail", "risk", "open", "na"]:
        t, fg, bg = STATUS[k]
        cs, cw = chip(xx, y, f"{t}  {cnt.get(k, 0)}", fg, bg, 15, 32)
        b += cs
        xx += cw + 10
    cols = [("Rank", 70), ("#", 64), ("Requirement", 560), ("v2 result", 660), ("Checked by", 140), ("Status", 266)]
    tx = M; ty = 270
    b += rect(M, ty, W - 2 * M, 36, GREY_BG, 6)
    cx = M + 14
    xs = []
    for k, cw in cols:
        xs.append(cx)
        b += T(cx, ty + 24, k, 14, 600, MUTED)
        cx += cw
    rh = 29.4
    for i, (rank, num, req, res, how, st) in enumerate(REQ):
        ry = ty + 36 + i * rh
        if i % 2:
            b += rect(M, ry, W - 2 * M, rh, "#FAF9F6")
        base = ry + rh / 2 + 6
        b += T(xs[0], base, str(rank), 16, 500, MUTED)
        b += T(xs[1], base, num, 16, 600, INK)
        b += T(xs[2], base, req, 16, 500, INK)
        fz = 16
        while tw(res, fz) > cols[3][1] - 16:
            fz -= 0.5
        b += T(xs[3], base, res, fz, 400, MUTED)
        b += T(xs[4], base, how, 15, 400, MUTED)
        t, fg, bg = STATUS[st]
        cs, _ = chip(xs[5], ry + rh / 2, t, fg, bg, 13, 22)
        b += cs
        if rank in (5, 9, 19) and (i == 0 or REQ[i - 1][0] != rank):
            b += line(M, ry, W - M, ry, "#CFCDC6", 1.2)
    yb = ty + 36 + len(REQ) * rh + 16
    p, h = P(M, yb + 14, "Tier 1 (rank 1–4): removal passes, but **shedding, detection accuracy and containment** are unproven. The three fails each get a design fix in the FMEA (slides 14–16).", 17, W - 2 * M, 24, 400, MUTED, bfill=INK)
    b += p
    b += footer("Requirements: MPx_Weighted_Objective_Tree.docx (22 items, D/W). W = wish")
    add("11_requirements_team_list", "Requirements met and not met", b)


# =====================================================================================
# 12 sim checks + assumptions
def s12():
    b, y0 = header(12, TOTAL, "What the simulation proves, and what only a bench can",
                   "12 of 14 bench checks pass, but under assumptions we chose. Each assumption maps to a bench test that will measure it.")
    y = 250; lw = 780
    b += card(M, y, lw, 740)
    b += label(M + 28, y + 40, "Validated by the simulation (bench readout)", 13, INK)
    ih = (lw - 40) * 545 / 1200
    b += img(M + 20, y + 62, lw - 40, ih, "img/req.jpg", r=8, stroke=LINE)
    yy = y + 62 + ih + 40
    items = [("pass", "Size, flow at 60 N, force, valve, bubble point, capture 1–5 µm, tap flow, disc ΔP, visibility, cap strength"),
             ("fail", "Filter life: 2.2 L until flow halves vs 20 L"),
             ("open", "Below 1 µm: 15 %, not claimed"),
             ("caveat", "The 120 s check counts squeezing time only; with release pauses 500 mL takes 168 s (10.7 L/h)"),
             ("open", "Not modelled at all: seal leaks, thread wear, shedding, leaching, cost, user behaviour")]
    for st, t in items:
        t_, fg, bg = STATUS["partial" if st == "caveat" else st]
        cs, cw = chip(M + 28, yy, {"pass": "12 pass", "fail": "1 fail", "caveat": "caveat"}[st] if st != "open" else ("not claimed" if "1 µm" in t else "not modelled"), fg, bg, 13, 24)
        b += cs
        p, h = P(M + 28 + 140, yy + 5, t, 16, lw - 200, 22, 400, INK)
        b += p
        yy += max(h, 24) + 16
    x = M + lw + 30; w = W - M - x
    b += card(x, y, w, 740)
    b += label(x + 28, y + 40, "Assumptions to replace with measurements", 13, INK)
    cols = [("Assumption", 300), ("Value used", 190), ("Drives", 190), ("Bench test", 250)]
    rows = [("Palm contact area, bottle wall stiffness", "34 cm², 4 N", "Squeeze pressure, force", "2 · pressure vs hand force, 5 users, 2 bottles"),
            ("Asymmetric disc permeability", "K·t = 13 (3× gain)", "Flow, force (6.1, 2.1)", "1 · flux vs ΔP for A, B, C"),
            ("Bottle spring-back vacuum", "0.6 bar per volume share", "Need for the valve", "2b · sealed bottle, vacuum gauge"),
            ("Cake resistance α, prefilter share", "10¹³ m/kg, 40 %", "Filter life (9.1)", "3 · fouling on tap + borewell water"),
            ("Irreversible fouling per backflush", "3 %", "Disc service life", "4 · 10 backflush cycles"),
            ("Capture curve d₅₀, sharpness", "A: 0.75 µm, k = 10", "Removal (6.1)", "5 · PS bead challenge 1, 2, 5 µm"),
            ("Nile red visibility", "2 µm at 140×", "Detection (6.2)", "6 · count vs reference microscope"),
            ("Seals, threads, drop", "not modelled", "Leaks, galling (3.5)", "7 · leak, 1 m drop, 200 thread cycles")]
    cx = x + 28; xs = []
    for k, cw in cols:
        xs.append(cx); cx += cw
    ty = y + 66
    b += rect(x + 16, ty, w - 32, 34, GREY_BG, 6)
    for (k, _), xx in zip(cols, xs):
        b += T(xx, ty + 23, k, 14, 600, MUTED)
    ry = ty + 34
    for i, r in enumerate(rows):
        hs = []
        parts = ""
        for j, (val, (k, cw)) in enumerate(zip(r, cols)):
            p, h = P(xs[j], ry + 28, val, 15.5, cw - 18, 21, 600 if j == 0 else 400, INK if j in (0, 3) else MUTED)
            parts += p; hs.append(h)
        rh = max(hs) + 22
        if i % 2:
            b += rect(x + 16, ry, w - 32, rh, "#FAF9F6")
        b += parts
        ry += rh
    b += rect(x + 16, y + 740 - 132, w - 32, 116, ORANGE_BG, 10)
    b += label(x + 40, y + 740 - 96, "CED lecture 9: three kinds of simulation", 13, ORANGE)
    b += status_icon(x + 52, y + 740 - 52, "done") + T(x + 72, y + 740 - 46, "Analytical (slide 7)", 17, 600)
    b += status_icon(x + 302, y + 740 - 52, "done") + T(x + 322, y + 740 - 46, "Virtual (slides 5–6)", 17, 600)
    b += status_icon(x + 552, y + 740 - 52, "now") + T(x + 572, y + 740 - 46, "Physical: bench tests 1–7, next", 17, 600)
    b += footer("Bench tests 1–7 from the v2 specification; numbers in the readout are at default bench settings")
    add("12_validated_vs_not", "What the simulation proves", b)


# =====================================================================================
# FMEA data: (component, failure mode, effect, cause, current control, O, S, D, action, O2, S2, D2, req)
FMEA = [
    ("Backflush output", "Cake washed into the sink", "Caught microplastics go back to the environment", "Backflush runs to the drain by habit; the dish is optional", "Instructions only", 8, 6, 8, "Backflush into a lidded catch cup with a paper filter; dry and bin the paper", 3, 6, 4, "10.2"),
    ("Cassette O-rings S2/S3", "Water bypasses the disc edge", "Unfiltered water at the spout; user can't tell", "O-ring missing, twisted or pinched on refit; grit on the seat", "Groove design, visual check", 4, 9, 8, "O-rings retained in the frame; blow-test at the spout (wet disc holds 2.9 bar)", 2, 9, 4, "6.1"),
    ("Clean side after backflush", "Clean side left full of tap water", "First sips after a backflush are unfiltered", "Backflush pushes tap water in through the spout", "None", 8, 5, 7, "Squeeze 100 mL to waste after each backflush (mark on bottle), or backflush with filtered water", 3, 5, 3, "6.1"),
    ("Detection (Nile red)", "Wrong particle count", "User trusts a false result", "Nile red also stains organic matter and biofilm; < 2 µm unresolved", "Visibility limit modelled only", 7, 6, 6, "H₂O₂ digestion step; calibrate with PS beads; compare with reference microscope", 4, 6, 4, "6.2"),
    ("Filter end-of-life", "No end-of-life warning", "Keeps using a dead or damaged disc", "No indicator; slow flow is the only cue", "None", 8, 5, 6, "Litre and backflush log in the phone app; rule card: 500 mL > 4 min → backflush, 30 backflushes → replace", 4, 5, 3, "4.2"),
    ("Sintered disc, weld seam", "Crack or seam leak", "Unfiltered water bypasses", "Tap above 3 bar, water hammer, drop", "3 bar rating", 3, 9, 7, "2 bar pressure limiter in the tap adapter; bubble-point test on delivery", 2, 9, 4, "6.1"),
    ("Cassette orientation", "Disc fitted upside down", "Deep fouling, backflush fails, inspection face hidden", "Frame fits both ways", "Arrow mark", 5, 6, 6, "Stepped frame so it fits one way only", 1, 6, 2, "9.1"),
    ("Disc pores", "Irreversible fouling or biofilm", "Flow never recovers; odour", "3 % of each cake stays; wet storage", "Backflush", 6, 6, 5, "Store dry; monthly boil or citric clean (316L takes 100 °C)", 3, 6, 4, "9.1"),
    ("Silicone seals, clean side", "Seal wear sheds particles", "The filter adds particles downstream", "Sliding S4 sleeve seal rubs every use", "FDA silicone, post-cured", 3, 7, 8, "Static seals only on the clean side; blank-water run counts particles", 2, 7, 5, "3.2"),
    ("Disc fouling rate", "Flow halves after 2.2 L", "Squeezing gets hard; user gives up", "Fine solids pass the 20 µm prefilter (only 40 % stop)", "Backflush returns 97 %", 9, 6, 3, "5–10 µm depth prefilter (13 L between flushes) + Ø44 disc", 4, 6, 3, "9.1"),
    ("Cap M48 thread", "Galling, thread seizes", "Can't open to swap or inspect the disc", "316L on 316L, fine pitch, grit, no lubricant", "None", 5, 7, 4, "M48 × 1.5; harder cap alloy or nitriding; food-grade silicone grease", 2, 7, 4, "7.1"),
    ("Spout and sleeve", "Clean side touched by dirty hands", "Bacteria reach the mouth", "Open spout, sleeve handled", "Sleeve washable", 5, 7, 4, "Hinged dust cap on the spout", 2, 7, 3, "5.2"),
    ("316L surfaces", "Fe/Cr/Ni leaching or rust", "Metals above IS 10500", "Poor passivation, weld heat tint", "ASTM A967 passivation", 2, 8, 6, "Electropolish; leach test to IS 10500", 1, 8, 4, "3.4"),
    ("Prefilter cup", "Clogs with silt", "Very slow flow", "Turbid surface water (10 mg/L)", "Backflush clears it in ~1 s", 6, 5, 3, "Settle turbid water first; larger pleated cup", 4, 5, 3, "2.1"),
    ("Housing, disc frame", "Damaged by a 1 m drop", "Dented frame leaks at the seals", "Drop on a hard floor", "Cap SF 38", 3, 6, 5, "Drop test ×10 (test 7); grip ring takes the impact", 2, 6, 4, "3.5"),
    ("Air-return valve", "Leaks while squeezing", "Unfiltered drips near the spout", "Damaged lip, wrong crack pressure", "Visible drip", 4, 6, 3, "Valve away from the spout drip path; test 0.03 bar crack", 2, 6, 3, "6.1"),
    ("Bottle neck seal S1", "Leak at the bottle neck", "Unfiltered water on hands and spout", "Non-1881 necks on some Indian bottles", "Gasket", 6, 6, 2, "Test 10 local bottle brands; thicker gasket", 3, 6, 2, "1.1"),
    ("Hand force", "User can't reach 60 N", "Flow below 15 L/h", "Weak grip: children, elderly", "1 L bottle, tap mode", 6, 4, 2, "Grip ring; promote tap mode", 4, 4, 2, "5.1"),
    ("Air-return valve", "Sticks shut", "Flow stalls after ~140 mL", "Dried silicone, debris", "Stall is obvious", 4, 4, 2, "Shield the valve with a rib; spare valve in kit", 2, 4, 2, "2.1"),
    ("Cold water", "Flow 41 % lower at 5 °C", "500 mL takes 194 s", "Viscosity", "None", 4, 3, 2, "Note in the user guide", 4, 3, 2, "8.2"),
]
for r in FMEA:
    assert len(r) == 13


def rn(r):
    return r[5] * r[6] * r[7]


def rn2(r):
    return r[9] * r[10] * r[11]


FMEA.sort(key=lambda r: -rn(r))


def s13():
    b, y0 = header(13, TOTAL, "Design FMEA: method",
                   "Pahl & Beitz §10.4: list how each part and use step can fail, what the user notices, and why. Then rate, rank and fix.")
    y = 240
    steps = [("1", "Risk analysis", "Failures, consequences, causes; measures that avoid or detect them"),
             ("2", "Risk assessment", "Rate occurrence O, severity S, and detection D (easy to detect = low D)"),
             ("3", "Risk number", "RN = O × S × D, from 1 to 1000. **RN > 125 is critical**"),
             ("4", "Risk minimisation", "Design change for each critical item, then re-rate for a new RN")]
    w = (W - 2 * M - 3 * 22) / 4
    for i, (n, t, d) in enumerate(steps):
        x = M + i * (w + 22)
        b += card(x, y, w, 156)
        b += num_badge(x + 40, y + 44, n, 20, ORANGE, size=18)
        b += T(x + 74, y + 52, t, 22, 600)
        p, h = P(x + 28, y + 100, d, 17, w - 56, 24, 400, MUTED, bfill=INK)
        b += p
    y2 = y + 178
    scales = [("Occurrence O", [("1–2", "Unlikely: a design feature prevents it"), ("3–4", "Occasional"), ("5–6", "Likely over a year of use"), ("7–8", "Frequent: most users, often"), ("9–10", "Certain: the simulation shows it every time")]),
              ("Severity S", [("1–2", "User barely notices"), ("3–4", "Slower or less convenient"), ("5–6", "Function degraded: hard squeezing, wrong count"), ("7–8", "Hygiene risk or contaminant released"), ("9–10", "Unfiltered water delivered as filtered")]),
              ("Detection D", [("1–2", "Obvious at once (stall, drip)"), ("3–4", "User notices within a use"), ("5–6", "Found only by inspection or test"), ("7–8", "Hidden from the user"), ("9–10", "Cannot be detected")])]
    w3 = (W - 2 * M - 2 * 22) / 3
    for i, (t, rows) in enumerate(scales):
        x = M + i * (w3 + 22)
        b += card(x, y2, w3, 282)
        b += T(x + 28, y2 + 42, t, 20, 600)
        for j, (k, v) in enumerate(rows):
            ry = y2 + 82 + j * 42
            shade = ["#EAF4ED", "#F3F2EE", "#F8EBCF", "#FCE7DD", "#FADFDB"][j]
            b += rect(x + 28, ry - 20, 62, 30, shade, 6)
            b += T(x + 59, ry + 1, k, 15, 600, INK, "middle")
            b += T(x + 104, ry + 1, v, 16, 400, INK)
    # worked example
    y3 = y2 + 304
    b += card(M, y3, W - 2 * M, 150)
    b += label(M + 30, y3 + 38, "Worked example: cassette O-rings", 13, INK)
    cells = [("Failure", "Water bypasses the disc edge"), ("Effect", "Unfiltered water at the spout"), ("Cause", "O-ring twisted or missing on refit"),
             ("Rating", "O 4 × S 9 × D 8"), ("RN", "288 · critical"), ("Action", "Retained O-rings + spout blow-test"), ("New RN", "2 × 9 × 4 = 72")]
    cw = (W - 2 * M - 60) / len(cells)
    for i, (k, v) in enumerate(cells):
        x = M + 30 + i * cw
        b += T(x, y3 + 76, k, 14, 600, MUTED)
        col = RED if k == "RN" else (GREEN if k == "New RN" else INK)
        p, _ = P(x, y3 + 104, v, 17, cw - 24, 22, 600 if k in ("RN", "New RN", "Rating") else 400, col)
        b += p
        if i:
            b += line(x - 14, y3 + 62, x - 14, y3 + 128, LINE)
    y4 = y3 + 172
    b += card(M, y4, W - 2 * M, 990 - y4, ORANGE_BG, "#F4C9B5")
    p, h = P(M + 30, y4 + 36, "**Scope:** v2 core unit, the proposed air valve and grip ring, and four use modes (squeeze, tap, backflush, inspect). **20 failure modes, 12 critical.** "
             "Ratings use simulation numbers where they exist and judgement elsewhere: a draft for the team to review together, as P&B recommend.", 17, W - 2 * M - 60, 24, 400, INK)
    b += p
    b += footer("Pahl & Beitz, Engineering Design 3e (2007), §10.4 and Fig. 10.11; CED lecture 2, slide 36")
    add("13_fmea_method", "FMEA method", b)


def fmea_table(n, rows, start, title, sub):
    b, y0 = header(n, TOTAL, title, sub)
    cols = [("#", 38), ("Part / function", 176), ("Failure mode", 190), ("Effect on user", 200), ("Cause", 212), ("Current control", 150),
            ("O", 36), ("S", 36), ("D", 36), ("RN", 62), ("Recommended action", 380), ("New RN", 86), ("Req.", 56)]
    x = M; xs = []
    for k, cw in cols:
        xs.append(x); x += cw
    ty = 246
    b += rect(M - 8, ty, W - 2 * M + 16, 38, INK, 6)
    for (k, cw), xx in zip(cols, xs):
        anc = "middle" if k in ("O", "S", "D", "RN", "New RN") else "start"
        b += T(xx + (cw / 2 if anc == "middle" else 6), ty + 25, k, 14, 600, "#fff", anc)
    ry = ty + 38
    for i, r in enumerate(rows):
        idx = start + i
        texts = [r[0], r[1], r[2], r[3], r[4]]
        parts, hs = "", []
        for j, t in enumerate(texts):
            k, cw = cols[j + 1]
            p, h = P(xs[j + 1] + 6, ry + 27, t, 15.5, cw - 16, 21, 600 if j == 0 else 400, INK if j < 2 else MUTED)
            parts += p; hs.append(h)
        p, h = P(xs[10] + 6, ry + 27, r[8], 15.5, cols[10][1] - 16, 21, 400, INK)
        parts += p; hs.append(h)
        rh = max(hs) + 18
        if i % 2:
            b += rect(M - 8, ry, W - 2 * M + 16, rh, "#FAF9F6")
        b += parts
        b += T(xs[0] + 6, ry + 27, str(idx), 15, 600, MUTED)
        for j, v in zip((6, 7, 8), (r[5], r[6], r[7])):
            b += T(xs[j] + 18, ry + 27, str(v), 16, 500, INK, "middle")
        R = rn(r)
        crit = R > 125
        cs, _ = chip(xs[9] + 4, ry + 21, f"{R}", "#fff" if crit else INK, RED if crit else GREY_BG, 15, 26)
        b += cs
        R2 = rn2(r)
        cs, _ = chip(xs[11] + 12, ry + 21, f"{R2}", GREEN, GREEN_BG, 15, 26)
        b += cs
        b += T(xs[12] + 6, ry + 27, r[12], 14, 600, MUTED)
        ry += rh
        b += line(M - 8, ry, W - M + 8, ry, "#ECEAE4")
    return b, ry


def s14():
    b, ry = fmea_table(14, FMEA[:10], 1, "Design FMEA (1/2): the ten highest risks",
                       "Sorted by risk number. Red RN is critical (> 125). New RN is the re-rating once the action is in the design.")
    b += footer("O occurrence · S severity · D detection, 1–10 each; RN = O × S × D. Draft ratings, for team review")
    add("14_fmea_table_1", "FMEA table 1", b)


def s15():
    b, ry = fmea_table(15, FMEA[10:], 11, "Design FMEA (2/2): the remaining ten",
                       "Two more critical items (threads, spout hygiene); the rest are below 125 but still have cheap fixes.")
    b += card(M, ry + 30, W - 2 * M, 96, GREY_BG, GREY_BG)
    p, _ = P(M + 28, ry + 68, "**Not covered here:** the process FMEA for CNC turning, sintering, laser welding and passivation. Pahl & Beitz treat it separately; "
             "it belongs to detail design, once suppliers and processes are fixed.", 17, W - 2 * M - 56, 24, 400, MUTED, bfill=INK)
    b += p
    b += footer("O occurrence · S severity · D detection, 1–10 each; RN = O × S × D. Draft ratings, for team review")
    add("15_fmea_table_2", "FMEA table 2", b)


def s16():
    b, y0 = header(16, TOTAL, "FMEA result: twelve critical risks, all fixable in v2.1",
                   "The biggest risks are not the filter itself but what happens around it: **backflush, reassembly and detection**.")
    y = 250; w = 1060
    b += card(M, y, w, 740)
    b += T(M + 30, y + 46, "Risk number per failure mode, before → after", 20, 600)
    x0 = M + 360; x1 = M + w - 50
    sc = lambda v: x0 + v / 400 * (x1 - x0)
    top = y + 92; rh = 30
    for v in [0, 100, 200, 300, 400]:
        b += line(sc(v), top - 8, sc(v), top + rh * 20, "#EFEDE7")
        b += T(sc(v), top + rh * 20 + 22, str(v), 14, 400, MUTED, "middle")
    b += line(sc(125), top - 20, sc(125), top + rh * 20, RED, 1.4, "6 5")
    b += T(sc(125) + 6, top - 18, "critical > 125", 14, 600, RED)
    for i, r in enumerate(FMEA):
        yy = top + i * rh
        nm = f"{r[1]}"
        b += T(M + 30, yy + 19, str(i + 1), 14, 600, MUTED)
        b += T(M + 58, yy + 19, nm, 14, 500, INK)
        R, R2 = rn(r), rn2(r)
        b += rect(x0, yy + 6, sc(R) - x0, 18, RED if R > 125 else "#C9C6BE", 3)
        b += f'<circle cx="{sc(R2):.1f}" cy="{yy + 15}" r="7" fill="{GREEN}" stroke="#fff" stroke-width="2"/>'
        b += T(sc(R) + 8, yy + 20, str(R), 13, 600, RED if R > 125 else MUTED)
    b += T(M + 30, top + rh * 20 + 56, "", 14)
    ly = y + 740 - 26
    b += rect(M + 30, ly - 11, 24, 12, RED, 3) + T(M + 62, ly, "RN now", 14, 500, MUTED)
    b += f'<circle cx="{M + 162}" cy="{ly - 5}" r="7" fill="{GREEN}"/>' + T(M + 176, ly, "RN after the action", 14, 500, MUTED)
    x = M + w + 30; w2 = W - M - x
    b += card(x, y, w2, 740)
    b += label(x + 28, y + 42, "Changes for v2.1, in priority order", 13, INK)
    acts = [("Backflush catch cup", "Lidded cup with a paper filter so the cake is kept, dried and binned (10.2)"),
            ("Flush-to-waste step", "100 mL squeezed to waste after every backflush"),
            ("Keyed, sealed cassette", "Stepped frame fits one way; O-rings retained; spout blow-test"),
            ("Depth prefilter + Ø44 disc", "5–10 µm depth stage: 13–18 L between backflushes (9.1)"),
            ("Detection protocol", "H₂O₂ digestion, bead calibration, reference count (6.2)"),
            ("Life log in the app", "Litres and backflush count → end-of-life alert (4.2)"),
            ("Anti-galling thread", "M48 × 1.5, harder cap, food-grade grease"),
            ("Tap pressure limiter, dust cap, static clean-side seals", "")]
    yy = y + 88
    for i, (t, d) in enumerate(acts):
        b += num_badge(x + 42, yy - 6, i + 1, 14, ORANGE if i < 6 else INK, size=13)
        p, h = P(x + 68, yy, t, 18, w2 - 96, 24, 600)
        b += p
        if d:
            p2, h2 = P(x + 68, yy + h + 2, d, 15.5, w2 - 96, 21, 400, MUTED)
            b += p2
            h += h2 + 2
        yy += h + 16
    b += rect(x + 16, y + 740 - 136, w2 - 32, 120, ORANGE_BG, 10)
    p, _ = P(x + 40, y + 740 - 96, "**Two of the top three risks come from backflush.** It cleans the disc, but it is also where the catch can escape (10.2) "
             "and unfiltered tap water reaches the clean side. Fixing backflush first takes those two from 664 risk points to 117.", 16.5, w2 - 80, 23, 400, INK)
    b += p
    b += footer("All 20 failure modes re-rated below 100 after the actions; ratings to be confirmed by bench tests 1–7")
    add("16_fmea_result", "FMEA result", b)


def s17():
    b, y0 = header(17, TOTAL, "Next steps: finish embodiment design, then detail design",
                   "The model told us where to look. Bench tests turn its assumptions into measurements, and the FMEA turns its risks into design changes.")
    y = 252
    phases = [("Week 1", "Review the FMEA as a team", ["Agree O/S/D ratings", "Confirm the 12 critical items", "Assign owners"], ORANGE),
              ("Week 1", "Order parts", ["RFQ for the asymmetric disc with flux and bubble-point data", "B and C discs as fallback", "3 prototype kits (₹44,700)"], ORANGE),
              ("Week 1–2", "v2.1 layout", ["Catch cup + flush step", "Keyed cassette, Ø44 disc", "Depth prefilter, valve, grip ring into drawings and BOM"], ORANGE),
              ("Week 3–6", "Bench tests 1–7", ["Physical simulation (lecture 9) of every assumption on slide 12"], INK),
              ("Week 6", "Close the loop", ["Measured values into the model", "Re-run the requirements table", "Re-rate the FMEA"], INK),
              ("Then", "Detail design", ["Tolerances and fits", "Final drawings", "Process FMEA: CNC, sintering, welding, passivation"], MUTED)]
    n = len(phases); gap = 18; w = (W - 2 * M - gap * (n - 1)) / n
    for i, (wk, t, items, col) in enumerate(phases):
        x = M + i * (w + gap)
        b += card(x, y, w, 300)
        b += rect(x, y, w, 8, col, 0)
        b += label(x + 24, y + 46, wk, 13, col if col != MUTED else FAINT)
        p, h = P(x + 24, y + 82, t, 22, w - 48, 27, 600)
        b += p
        bl, _ = bullets(x + 24, y + 98 + h + 12, items, 16, w - 48, 8, col if col != MUTED else FAINT)
        b += bl
    y2 = y + 324
    b += card(M, y2, W - 2 * M, 990 - y2)
    b += label(M + 30, y2 + 42, "Bench tests: what each one measures, and the requirement it settles", 13, INK)
    tests = [("1", "Flux vs ΔP, cassettes A, B, C", "K·t of each disc", "2.1, 5.1"), ("2", "Bottle pressure vs hand force, 5 users", "palm area, wall stiffness, vacuum", "2.1, 5.1"),
             ("3", "Fouling on tap and borewell water", "cake resistance α, prefilter share", "9.1, 1.1"), ("4", "Backflush recovery, 10 cycles", "irreversible share per flush", "9.1, 10.2"),
             ("5", "Polystyrene bead challenge, 1/2/5 µm", "real capture curve", "6.1"), ("6", "Nile red count vs reference microscope", "false positive / negative rate", "6.2, 4.1"),
             ("7", "Leak, 1 m drop, 200 thread cycles", "seal and thread life", "3.5, 7.1"), ("+", "Blank-water shedding run; leach test", "particles from seals; metals vs IS 10500", "3.2, 3.4")]
    cw = (W - 2 * M - 60) / 4
    for i, (n_, t, m_, r) in enumerate(tests):
        x = M + 30 + (i % 4) * cw; yy = y2 + 100 + (i // 4) * 150
        b += num_badge(x + 16, yy - 6, n_, 16, INK, size=15)
        p, h = P(x + 44, yy, t, 18, cw - 70, 24, 600)
        b += p
        p, h2 = P(x + 44, yy + h + 4, f"Measures {m_}", 16, cw - 70, 22, 400, MUTED)
        b += p
        cs, _ = chip(x + 44, yy + h + h2 + 18, f"settles {r}", ORANGE, ORANGE_BG, 13, 24)
        b += cs
    b += footer("Bench tests 1–7 from the v2 specification; detail design follows the embodiment outcome (lecture 2, slide 37)")
    add("17_next_steps", "Next steps", b)


for f in [s01, s02, s03, s04, s05, s06, s07, s08, s09, s10, s11, s12, s13, s14, s15, s16, s17]:
    f()
css = font_css()
import os
os.makedirs("out", exist_ok=True)
for fn, title, body in SL:
    open(f"out/MPx_Squeeze_v2_{fn}.svg", "w").write(document(body, css, title))
print(len(SL), "slides", len(css) // 1024, "KB fonts")
for r in FMEA:
    print(rn(r), rn2(r), r[0], "|", r[1])
