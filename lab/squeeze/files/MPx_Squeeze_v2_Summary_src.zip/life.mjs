import * as M from "./model.mjs";
const base = { F: 60, Ptap: 1.5, T: 25, cas: "A", bottle: "500", water: "tap", valve: true, palm: 34, alpha: 1e13, pfCut: 0.4, mpPerL: 1000 };
const b5 = M.BOTTLES["500"];
for (const [name, inp] of [["base", base], ["pf90", { ...base, pfCut: 0.9 }], ["bore", { ...base, water: "bore" }]]) {
  const s = M.fresh(b5); const q0 = M.flowLmin(M.handBar(60, b5, inp, 1), inp); let n = 0, l = 0, rec = 1;
  const w = M.WATERS[inp.water];
  while (rec > 0.5 && l < 2000) { l += 0.05; s.mPf += w.c*0.05/1000*inp.pfCut; s.mDisc += w.c*0.05/1000*(1-inp.pfCut)*0.9;
    if (M.flowLmin(M.handBar(60,b5,inp,1),inp,s) < 0.5*q0) { for (let i=0;i<400;i++) M.stepBackflush(s,inp,0.1); n++; rec = M.flowLmin(M.handBar(60,b5,inp,1),inp,s)/q0; } }
  console.log(name, "litres", l.toFixed(1), "backflushes", n);
}
