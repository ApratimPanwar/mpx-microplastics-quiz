"""CadQuery solids of MPx Squeeze v1 from profiles.py: STEP per part + assembly; prints exact volumes and masses."""
import json, os, cadquery as cq
from dims import *
from profiles import P, NAMES
OUT = "/mnt/user-data/outputs/squeeze/step/"; os.makedirs(OUT, exist_ok=True)

def revolve(pts):
    # sketch in the XY plane with y = r, revolve about the X axis
    return cq.Workplane("XY").polyline(pts).close().revolve(360, (0, 0, 0), (1, 0, 0))

solids = {k: revolve(v) for k, v in P.items()}
# features: wrench flats on the head, cross-ports in the stem, knurl is cosmetic
flats = cq.Workplane("XY").box(H["web"][1] - H["web"][0], 40, 40).translate(((H["web"][0] + H["web"][1]) / 2, 0, 0))
keep = cq.Workplane("XY").box(H["web"][1] - H["web"][0], H["flats"], 60).translate(((H["web"][0] + H["web"][1]) / 2, 0, 0))
solids["P03"] = solids["P03"].cut(flats.cut(keep))
port = cq.Workplane("YZ").circle(1.25).extrude(12, both=True).translate((145.0, 0, 0))
solids["P03"] = solids["P03"].cut(port)
# pre-screen disc
solids["P08"] = cq.Workplane("YZ").circle(SCREEN["D"] / 2).extrude(0.1).translate((16.7, 0, 0))

mass = {}
for k, s in solids.items():
    vol = s.val().Volume()
    rho = SS_RHO * (SINT_DENS if k == "P04" else 1.0)
    if k == "P08": rho = SS_RHO * 0.35
    mass[k] = round(vol * rho, 1)
    cq.exporters.export(s, OUT + f"{k}_{NAMES[k].split(' (')[0].replace(' ', '_').replace(',', '').replace('+', 'and').replace('→', 'to')}.step")
asm = cq.Assembly(name="MPx_Squeeze_v1")
for k in ("P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09"):
    asm.add(solids[k], name=k, color=cq.Color(0.55, 0.58, 0.62) if k == "P04" else cq.Color(0.8, 0.82, 0.85))
asm.save(OUT + "MPx_Squeeze_v1_ASSEMBLY.step")
core = sum(mass[k] for k in ("P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09")) + 2.0
json.dump({"mass_g": mass, "unit_mass_g": round(core, 1)}, open("masses.json", "w"), indent=1)
print(json.dumps(mass, indent=0), "\nunit (with ~2 g seals):", round(core, 1), "g")
