"""MPx Squeeze v1 — single source of truth (mm). Axis along x, x = 0 at the bottle-side face of the inlet coupler,
flow in +x (bottle -> pre-screen -> annulus -> sintered element (outside-in) -> element bore -> spout).
All metal parts 316L; seals food-grade silicone (FDA 21 CFR 177.2600), chosen by the team for every joint."""
import math
SS_RHO = 8.0e-3          # g/mm3 (316L)
SINT_DENS = 0.62         # sintered media relative density (~38 % porosity)

# bottle interface: 28 mm PCO 1881 (bottlepreform.com table). Thread pitch/starts conflict between sources (2.7 mm;
# 1 vs 3 starts) -> confirm on 5 measured Indian 500 mL / 1 L bottles before cutting the thread.
PCO = dict(T=27.40, T_tol=0.13, E=25.0, I=21.7, F=17.0, ring_h=11.2, pitch=2.7)
PCO_F = dict(major=28.4, minor=26.0)          # female thread in the coupler, +0.5 mm radial clearance

C = dict(x0=0.0, D=35.0, pco_depth=15.5, web=(15.5, 17.5), through=12.0, x1=26.5,
         body_thread="M32x1.0", knurl=(2.0, 14.0), gasket=(25.5, 19.0, 1.5))           # P01 inlet coupler
SCREEN = dict(D=20.0, cb_D=20.1, cb_depth=0.8, mesh="316L twilled Dutch weave, 40 µm", ring=(14.0, 20.05, 1.2))
B = dict(x0=17.5, x1=117.5, end_D=32.0, thread_L=9.0, mid_D=30.0, bore=28.0, relief=1.0)   # P02 body
H = dict(x_thread0=108.5, web=(117.5, 125.5), D=35.0, flats=32.0, el_thread="M14x1.5",
         stem_thread="M14x1.0", st_x=(125.5, 133.5), stem_D=9.0, stem_x=(133.5, 147.5), bore=5.0,
         port=2.5, port_x=145.0, groove=137.0, pin_D=4.0, pin_x=(147.5, 153.0), pin_groove=150.5, clip_x=134.5)                                   # P03 outlet head
E = dict(OD=20.0, wall=2.0, cap=(28.0, 30.0), x_open=113.5, grade="Mott-type media grade 0.2", rating="≈1.4 µm absolute in liquid",
         alt="media grade 0.5 (≈2–3 µm abs.)", KL=26.0, KL_alt=8.0)                       # P04 element
BASE = dict(land=(113.5, 115.5), land_D=16.0, shoulder=(115.5, 117.5), shoulder_D=22.0,
            thread=(117.5, 125.0), thread_D=14.0, bore=8.0)                               # P05 element base
SL = dict(L=20.0, OD=12.0, bore=9.0, cb=11.0, cb_L=6.0, outlet=4.0, travel=6.0)          # P06 push-pull sleeve
DC = dict(L=14.0, OD=15.0, ID=12.1, oring=(10, 1.5))                                      # P07 dust cap
TAP = dict(L=34.0, D=27.0, tap_thread="M22x1.0 female", neck="28 PCO 1881 male")          # P10 tap adapter
TAP24 = dict(L=14.0, D=27.0, a="M24x1.0 male (into M24 female taps)", b="M22x1.0 male")  # P11 M24 adapter
TAPSL = dict(range=(14, 22), L=38.0, ferrule="M22x1.0 male", clamp="316L worm clamp 16–27 mm")  # P12 universal sleeve
BF = dict(L=54.0, D=35.0, tail_D=16.0, flange_D=21.0, pco_side="28 PCO 1881 female", stem_side="M14x1.0 female", cavity=(16.0, 22.0))  # P13 backflush coupler
SEALS = [  # (id, type, where, size ID x CS mm, qty, side)
    ("S1", "flat gasket", "bottle lip in P01; P13", "Ø25.5/Ø19 × 1.5", 2, "dirty"),
    ("S2", "O-ring", "body ends to P01 web and P03 web", "26 × 1.5", 2, "dirty"),
    ("S3", "O-ring", "element base shoulder to P03 web", "14 × 2.0", 1, "clean"),
    ("S4", "O-ring", "spout stem, sleeve seal", "7 × 1.5", 1, "clean"),
    ("S8", "O-ring", "plug pin in sleeve outlet", "2.5 × 1.0", 1, "clean"),
    ("S5", "O-ring", "dust cap retention", "10 × 1.5", 1, "outside"),
    ("S6", "flat washer", "tap face in P10; P12 ferrule", "Ø22/Ø16 × 2", 2, "dirty"),
    ("S7", "flat gasket", "P13 on head face", "Ø14/Ø8 × 1.5", 1, "clean (backflush only)"),
]
X_STEM = H["pin_x"][1]
X_TIP = 153.5            # sleeve tip, closed

def element_area_m2():
    L = E["x_open"] - E["cap"][1]
    return (math.pi * E["OD"] * L + math.pi / 4 * E["OD"] ** 2) / 1e6

def permeance_LMH_bar(KL, wall_mm, visc_cp=0.89):
    """Mott liquid formula dP[psid] = KL * flux[gpm/ft2] * visc[cP] * t[in]  ->  L/(m2 h bar)"""
    return 1.0 / (KL * visc_cp * wall_mm / 25.4) * 2444.9 * 14.504

def flow_Lmin(bar, KL=None, fouling=1.0):
    return permeance_LMH_bar(KL or E["KL"], E["wall"]) * element_area_m2() * bar / 60 / fouling

if __name__ == "__main__":
    print("element area m2", round(element_area_m2(), 5))
    for g, KL in (("grade 0.2", E["KL"]), ("grade 0.5", E["KL_alt"])):
        print(g, f"{permeance_LMH_bar(KL, E['wall']):,.0f} LMH/bar", {b: round(flow_Lmin(b, KL), 2) for b in (0.2, 0.3, 0.4, 1.5)})
    print("length to stem tip", X_STEM, "with sleeve", X_TIP)
