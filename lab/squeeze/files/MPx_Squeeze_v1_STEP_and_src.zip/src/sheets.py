"""MPx Squeeze v1 engineering drawing set: 7 A3 sheets, standalone SVG. Geometry from profiles.py / dims.py."""
import json, os
from lib import *
from dims import *
from profiles import P, NAMES
OUT = "/mnt/user-data/outputs/squeeze/drawings/"; os.makedirs(OUT, exist_ok=True)
NS = 7
MS = json.load(open("masses.json"))["mass_g"]
UNIT = json.load(open("masses.json"))["unit_mass_g"]
g = lambda k: f"{MS[k]:.0f}"

def sec(v, key, dx=0.0, hatch="h45", mirror=True, lw=1.4, fill=None):
    up = [(x + dx, y) for x, y in P[key]]
    v.poly(up, INK, lw, fill or f"url(#{hatch})", close=True)
    if mirror: v.poly([(x, -y) for x, y in up], INK, lw, fill or f"url(#{hatch})", close=True)

def thread_ext(v, x0, x1, R, pitch=1.0):          # external thread: thin line at the minor diameter
    rm = R - 0.6134 * pitch
    for s in (1, -1): v.line(x0, s * rm, x1, s * rm, THIN, 0.7)
def thread_int(v, x0, x1, R, pitch=1.0):          # internal thread (sectioned): thin line at the major diameter
    for s in (1, -1): v.line(x0, s * R, x1, s * R, THIN, 0.7)

FLOW = 0.30
FL2, FL5 = flow_Lmin(FLOW), flow_Lmin(FLOW, E["KL_alt"])

# ====================================================== S01 · ASSEMBLY ======================================================
s = Sheet(1, NS, "General assembly", "MPx-SQ-000", "316L (see parts list)", "Electropolished, passivated (ASTM A967)", "1.5:1",
          mass=f"~{UNIT:.0f} g core unit", notes=["Section A-A on axis, shown closed with dust cap fitted. Flow left to right.",
          "Polymers only as silicone seals (FDA 21 CFR 177.2600); no other plastic in the unit.",
          "Leak test 1.5 bar air under water, 60 s, no bubbles. Bubble-point every element (ISO 4003).",
          "Clean flow (grade 0.2): ~%.2f L/min at %.1f bar squeeze; ~%.1f L/min at 1.5 bar tap." % (FL2, FLOW, flow_Lmin(1.5))])
s.frame()
v = View(s, 44, 66, 1.5)
# bottle neck ghost
v.poly([(-18, 13.7), (0, 13.7), (0, 10.85), (-18, 10.85)], HID, 1.0, "none", dash="5 3"); v.poly([(-18, -13.7), (0, -13.7), (0, -10.85), (-18, -10.85)], HID, 1.0, "none", dash="5 3")
v.t(-18, -20, "PET bottle neck", 9.5, 400, "start", HID)
order = [("P02", "h45"), ("P01", "h135"), ("P03", "h135"), ("P05", "h45"), ("P06", "h45"), ("P07", "h135"), ("P09", "h45")]
for k, h in order: sec(v, k, hatch=h)
sec(v, "P04", fill="url(#hins)")
v.rect(16.7, -10, 16.8, 10, INK, 1.6, "#111")                     # screen
for s_ in (1, -1):                                                 # seals (black)
    v.rect(15.5 - 1.5, s_ * 9.5, 15.5, s_ * 12.75, INK, 0.6, "#111")
    v.circle(B["x0"] + 0.9, s_ * 14.75, 0.75, INK, 0.6, "#111"); v.circle(B["x1"] + 0.9, s_ * 14.75, 0.75, INK, 0.6, "#111")
    v.circle(BASE["shoulder"][1] + 0.9, s_ * 8.0, 1.0, INK, 0.6, "#111"); v.circle(H["groove"], s_ * 4.5, 0.75, INK, 0.6, "#111")
v.cl(-20, 0, 166, 0)
thread_int(v, 0, 13, 13.0, 2.7); thread_ext(v, B["x0"], B["x0"] + 9, 16.0); thread_ext(v, B["x1"] - 9, B["x1"], 16.0)
# flow arrows
for (x1, y1, x2, y2) in ((-14, 0, -3, 0), (20, 0, 26, 0), (36, 12, 66, 12), (76, 13, 76, 6), (86, 0, 104, 0), (156, 0, 164, 0)):
    s.a(f'<line x1="{v.X(x1):.1f}" y1="{v.Y(y1):.1f}" x2="{v.X(x2):.1f}" y2="{v.Y(y2):.1f}" stroke="#2f80c0" stroke-width="2.2" marker-end="url(#ah)"/>')
v.dh(0, X_TIP + 2, 17.5, 33, f"{X_TIP + 2:g} overall (cap fitted)")
v.dh(B["x0"], B["x1"], 16, 27, f"{B['x1'] - B['x0']:g} body")
v.dv(-17.5, 17.5, 0, -10, "Ø35")
B_ = [(8, 17.5, 4, 30, "1"), (60, 15, 60, 30, "2"), (121, 17.5, 121, 30, "3"), (70, -10, 70, -28, "4"), (115, -10, 112, -28, "5"),
      (142, -6, 140, -28, "6"), (152, 7.5, 156, 30, "7"), (16.75, -9, 24, -28, "8"), (17.2, -8, 34, -28, "9")]
for x, y, tx, ty, n in B_: v.balloon(x, y, tx, ty, n)
v.label_view("SECTION A-A  (1.5:1)", 76, -38)
# parts list
rows = [
 ["1", "MPx-SQ-001", NAMES["P01"], "316L bar Ø38; 28 PCO 1881 int. + M32×1 int.", "Make", "1", g("P01")],
 ["2", "MPx-SQ-002", NAMES["P02"], "316L bar Ø35 (proto) / 316L tube + ferrules (prod.)", "Make", "1", g("P02")],
 ["3", "MPx-SQ-003", NAMES["P03"], "316L bar Ø38; M32×1 int., M14×1.5 int., M14×1 ext.", "Make", "1", g("P03")],
 ["4", "MPx-SQ-004", NAMES["P04"], "Sintered 316L tube Ø20×2, grade 0.2 (≈1.4 µm abs. liquid)", "Buy*", "1", g("P04")],
 ["5", "MPx-SQ-005", NAMES["P05"], "316L bar Ø25; welded to item 4", "Make", "1", g("P05")],
 ["6", "MPx-SQ-006", NAMES["P06"], "316L bar Ø14", "Make", "1", g("P06")],
 ["7", "MPx-SQ-007", NAMES["P07"], "316L bar Ø16", "Make", "1", g("P07")],
 ["8", "MPx-SQ-008", NAMES["P08"], "316L twilled Dutch weave, 40 µm, Ø20 disc", "Buy", "1", "<1"],
 ["9", "MPx-SQ-009", NAMES["P09"], "316L, press-fit Ø20.05/Ø14 × 0.7", "Make", "1", "1"],
 ["10", "MPx-SQ-010", NAMES["P10"], "316L; 28 PCO 1881 male neck + M22×1 int.", "Make", "1", g("P10")],
 ["11", "MPx-SQ-011", NAMES["P11"], "316L; M24×1 male / M22×1 male, hex 27", "Make", "1", g("P11")],
 ["12", "MPx-SQ-012", NAMES["P12"], "316L ferrule M22×1 + silicone cone sleeve + clamp", "Make/Buy", "1", g("P12")],
 ["13", "MPx-SQ-013", NAMES["P13"], "316L; 28 PCO 1881 int. + M14×1 int.", "Make", "1", g("P13")],
 ["S1–S8", "MPx-SQ-020", "Seal kit (see sheet 7)", "Silicone 60 ShA, FDA 21 CFR 177.2600", "Buy", "1 kit", "2"],
]
s.text(12 * PX, 116 * PX, "PARTS LIST", 13, 700)
yend = table(s, 12, 119, ["#", "Part no.", "Name", "Material / spec", "M/B", "Qty", "g"], rows, [11, 24, 52, 92, 15, 13, 10], size=9.4, rowh=5.6)
s.text(12 * PX, (yend + 5) * PX, f"Core unit (items 1–9 + seals) ≈ {UNIT:.0f} g from CAD volumes. Items 10–13 are accessories, carried separately.", 10, 400)
s.text(12 * PX, (yend + 10) * PX, "* Buy as a custom sintered tube from a porous-metal supplier, then weld item 5 to it (see sheet 5).", 10, 400)
# use modes
mx, my = 232, 118
s.text(mx * PX, my * PX, "USE MODES", 13, 700)
modes = [("A · Squeeze", ["PET bottle", "1 coupler", "4 element", "6 spout", "cup / mouth"], "bottle inverted, squeeze ~0.2–0.4 bar"),
         ("B · Tap", ["tap", "12 or 11", "10 neck", "1 → 4", "6 spout"], "tap pressure, ~1–2 bar; open tap gently"),
         ("C · Backflush", ["tap or bottle", "10 / bottle", "13 on stem", "4 (reverse)", "out at 1"], "clean water, reverse flow, 10–20 s")]
for i, (title, boxes, sub) in enumerate(modes):
    y0 = my + 6 + i * 23
    s.text(mx * PX, y0 * PX, title, 11.5, 700)
    for j, b in enumerate(boxes):
        bx = mx + j * 35
        s.a(f'<rect x="{bx * PX}" y="{(y0 + 3) * PX}" width="{29 * PX}" height="{8 * PX}" rx="6" fill="#f3f6fa" stroke="{INK}" stroke-width="1"/>')
        s.text((bx + 14.5) * PX, (y0 + 8.2) * PX, b, 9.5, 500, "middle")
        if j < len(boxes) - 1: s.a(f'<line x1="{(bx + 29.5) * PX}" y1="{(y0 + 7) * PX}" x2="{(bx + 34.5) * PX}" y2="{(y0 + 7) * PX}" stroke="#2f80c0" stroke-width="1.8" marker-end="url(#ah)"/>')
    s.text(mx * PX, (y0 + 15.5) * PX, sub, 9.5, 400, fill=THIN)
s.text(mx * PX, 190 * PX, "Plastic only upstream: the PET bottle and the inlet gasket sit before the", 9.8, 400, fill=THIN)
s.text(mx * PX, 194.6 * PX, "element; downstream of it there is only 316L and silicone seals.", 9.8, 400, fill=THIN)
s.save(OUT + "MPx-SQ-S01_Assembly.svg")

# ====================================================== S02 · BODY ======================================================
s = Sheet(2, NS, "Body; pre-screen; retaining ring", "MPx-SQ-002/008/009", "316L bar Ø35 · 316L mesh", "Electropolished, passivated", "2:1 · 2.5:1",
          mass=f"{g('P02')} g", notes=["Prototype: turn from Ø35 bar; bore Ø28 H9 reamed full length; thin wall 1.0 ±0.05 between threads.",
          "Production option: 316L tube 30 × 1.0 with TIG-welded threaded ferrules; same envelope.",
          "Threads M32×1.0-6g both ends, 9 long, 45° chamfer 0.5; ends faced square for O-ring S2 (Ra ≤ 0.8).",
          "Item 8: 40 µm twilled Dutch weave 316L, punched Ø20 -0.05; item 9 presses it into the coupler counterbore."])
s.frame()
v = View(s, 30, 90, 2.0)
sec(v, "P02", dx=-B["x0"])
v.cl(-6, 0, 106, 0)
thread_ext(v, 0, 9, 16.0); thread_ext(v, 91, 100, 16.0)
v.dh(0, 100, 16, 28); v.dh(0, 9, 16, 22.5, "9"); v.dh(91, 100, 16, 22.5, "9")
v.dv(-16, 16, 0, -6, "M32×1.0-6g"); v.dv(-15, 15, 50, 50, "Ø30"); v.dv(-14, 14, 74, 74, "Ø28 H9")
v.note(40, 15, 52, 34, "wall 1.0 ±0.05")
v.label_view("P02 BODY · SECTION (2:1)", 50, -30)
v2 = View(s, 300, 55, 2.5)
v2.circle(0, 0, 10, INK, 1.4, "url(#h45)"); v2.cross(0, 0, 12)
v2.dh(-10, 10, -10, -13, "Ø20 -0.05")
v2.label_view("P08 SCREEN DISC (2.5:1)", 0, -17)
s.text(300 * PX, 102 * PX, "40 µm twilled Dutch weave, 316L, t ≈ 0.1", 10.5, 400, "middle", THIN)
v3 = View(s, 300, 135, 2.5)
v3.circle(0, 0, 10.025, INK, 1.4, "url(#h135)"); v3.circle(0, 0, 7, INK, 1.4, "#fff"); v3.cross(0, 0, 12)
v3.dh(-10.025, 10.025, -10.025, -13, "Ø20.05 (press fit in Ø20.1)"); v3.dh(-7, 7, 0, 2, "Ø14")
v3.label_view("P09 RETAINING RING (2.5:1) · t 0.7", 0, -18)
s.save(OUT + "MPx-SQ-S02_Body.svg")

# ====================================================== S03 · INLET COUPLER ======================================================
s = Sheet(3, NS, "Inlet coupler (bottle side)", "MPx-SQ-001", "316L bar Ø38", "Electropolished, passivated; diamond knurl", "4:1 · 3:1",
          mass=f"{g('P01')} g", notes=["Bottle thread: 28 PCO 1881 internal, cut to major Ø28.4 / minor Ø26.0 (0.5 mm radial clearance on the neck).",
          "Pitch 2.7; number of starts (1 vs 3) differs between sources: measure 5 local 500 mL and 1 L bottles and a cap first.",
          "Gasket S1 (Ø25.5/Ø19 × 1.5 silicone) sits on the seat at 15.5 deep; the bottle lip compresses it ~0.4 mm.",
          "Body thread M32×1.0-6H, 9 deep; O-ring S2 groove on the web face (see sheet 7).",
          "Diamond knurl 0.8 pitch from 2 to 14; break all sharp edges 0.2."])
s.frame()
v = View(s, 48, 112, 4.0)
sec(v, "P01")
v.cl(-6, 0, 32, 0)
thread_int(v, 0, 13, 13.0, 2.7); thread_int(v, B["x0"], C["x1"], 16.0)
for s_ in (1, -1): v.rect(C["web"][0] - 1.5, s_ * 9.5, C["web"][0], s_ * 12.75, INK, 0.6, "#111")
v.dh(0, C["x1"], 17.5, 24.5); v.dh(0, 15.5, 17.5, 21, "15.5"); v.dh(15.5, 17.5, -17.5, -21.5, "2 web")
v.dv(-17.5, 17.5, 0, -8, "Ø35"); v.dv(-14.2, 14.2, 7, 7, "28 PCO 1881")
v.note(C["x1"], 16, 34, 22, "M32×1.0-6H, 9 deep")
v.note(16.9, 10.05, 34, 4, "Ø20.1 × 0.8 c'bore, items 8 + 9")
v.note(16.5, -6, 34, -8, "Ø12 through")
v.note(14.5, -11, 34, -14, "gasket S1 on seat")
v.label_view("SECTION (4:1)", 13, -24)
v2 = View(s, 300, 112, 3.0)
v2.circle(0, 0, 17.5, INK, 1.4, "#fff"); v2.circle(0, 0, 14.2, INK, 1.4); v2.circle(0, 0, 13.0, THIN, 0.7, dash="4 3")
v2.circle(0, 0, 12.75, INK, 0.9, "#e5e7eb"); v2.circle(0, 0, 9.5, INK, 0.9, "#fff"); v2.circle(0, 0, 6, INK, 1.2)
v2.cross(0, 0, 20)
v2.label_view("VIEW FROM BOTTLE SIDE (3:1)", 0, -24)
s.save(OUT + "MPx-SQ-S03_Coupler.svg")

# ====================================================== S04 · OUTLET HEAD, SLEEVE, CAP ======================================================
s = Sheet(4, NS, "Outlet head, push-pull sleeve, dust cap", "MPx-SQ-003/006/007", "316L bar Ø38 / Ø14 / Ø16", "Electropolished, passivated", "3:1 · 4:1",
          mass=f"{g('P03')} · {g('P06')} · {g('P07')} g", notes=["M32×1.0-6H 9 deep (to body); M14×1.5-6H through web (element base); M14×1.0-6g on stem (UV cap / backflush interface).",
          "Push-pull: S4 (7×1.5) seals the sleeve on the stem; S8 (2.5×1.0) on the Ø4 pin closes the sleeve outlet. Pull 6 mm to open.",
          "Sleeve retained by a 316L wire circlip in a stem groove at x 134.5 (bottom of the sleeve's travel).",
          "Wrench flats 32 A/F on the web, 8 long. Two cross-ports Ø2.5 at 90° in the stem at 11.5 from the M14 shoulder."])
s.frame()
v = View(s, 34, 105, 3.0)
dx = -H["x_thread0"]
sec(v, "P03", dx=dx); sec(v, "P06", dx=dx, hatch="h45"); sec(v, "P07", dx=dx, hatch="h135")
v.cl(-4, 0, 52, 0)
thread_int(v, 0, 9, 16.0); thread_int(v, 9, 17, 7.0, 1.5); thread_ext(v, 17, 25, 7.0)
for s_ in (1, -1):
    v.circle(H["groove"] + dx, s_ * 4.5, 0.75, INK, 0.6, "#111"); v.circle(H["pin_groove"] + dx, s_ * 2.0, 0.5, INK, 0.6, "#111")
    v.rect(H["port_x"] + dx - 1.25, s_ * 2.5, H["port_x"] + dx + 1.25, s_ * 4.5, INK, 0.6, "#fff")
v.dh(0, 17, 17.5, 25, "17"); v.dh(17, 25, 7, 25, "8"); v.dh(0, 9, -16, -24, "9"); v.dh(9, 17, -16, -24, "8 web")
v.dv(-17.5, 17.5, 0, -8, "Ø35"); v.note(21, 7, 30, 26, "M14×1.0-6g (UV / backflush interface)")
v.note(13, -7, 30, -20, "M14×1.5-6H thru")
v.note(41, 2, 50, 14, "Ø4 pin + S8")
v.label_view("HEAD + SLEEVE + CAP, ASSEMBLED, CLOSED (3:1)", 24, -32)
# sleeve detail open
v3 = View(s, 250, 70, 4.0)
sp = [(x - H["st_x"][1] + SL["travel"], y) for x, y in P["P06"]]
v3.poly(sp, INK, 1.4, "url(#h45)", close=True); v3.poly([(x, -y) for x, y in sp], INK, 1.4, "url(#h45)", close=True)
v3.poly([(0, 4.5), (14, 4.5), (14, 2), (19.5, 2), (19.5, -2), (14, -2), (14, -4.5), (0, -4.5)], INK, 1.2, "#f3f4f6", close=True)
v3.cl(-3, 0, 30, 0)
v3.dh(SL["travel"], SL["travel"] + SL["L"], 6, 10, "20"); v3.dv(-6, 6, SL["travel"] + SL["L"], 30, "Ø12")
v3.note(SL["travel"] + 18, -2, 22, -14, "Ø4.05 outlet", anchor="end")
s.a(f'<line x1="{v3.X(14):.1f}" y1="{v3.Y(0):.1f}" x2="{v3.X(28):.1f}" y2="{v3.Y(0):.1f}" stroke="#2f80c0" stroke-width="2" marker-end="url(#ah)"/>')
v3.label_view("SLEEVE OPEN (+6 mm) · 4:1", 14, -22)
s.save(OUT + "MPx-SQ-S04_Head_Spout.svg")

# ====================================================== S05 · ELEMENT ======================================================
s = Sheet(5, NS, "Filter element, sintered 316L + base", "MPx-SQ-004/005", "Sintered 316L (grade 0.2) · 316L bar", "As sintered; base passivated", "2:1",
          mass=f"{g('P04')} + {g('P05')} g", notes=["Element: seamless sintered 316L tube Ø20 × 2.0 wall, one end closed (integral or welded 2 mm disc), 85.5 long overall.",
          "Join to base: fusion weld (TIG/laser, no filler or 316L filler) full circumference at the collar; weld must not close pores beyond 1 mm.",
          "Every element: bubble point per ISO 4003 in IPA, record value; and clean-water flux at 0.3 bar (reject below 80 % of nominal).",
          "Ultrasonic clean + passivate after welding; dry; bag in PE-free paper."])
s.frame()
v = View(s, 22, 95, 2.0)
dx = -E["cap"][0]
sec(v, "P04", dx=dx, fill="url(#hins)"); sec(v, "P05", dx=dx, hatch="h45")
v.cl(-5, 0, 102, 0)
thread_ext(v, BASE["thread"][0] + dx, BASE["thread"][1] + dx, 7.0, 1.5)
v.dh(0, E["x_open"] - E["cap"][0], 10, 20, f"{E['x_open'] - E['cap'][0]:g} sintered")
v.dh(0, BASE["thread"][1] + dx, -11, -24, f"{BASE['thread'][1] - E['cap'][0]:g} overall")
v.dv(-10, 10, 0, -8, "Ø20"); v.note(50, 8, 50, 26, "wall 2.0, bore Ø16")
v.note(BASE["land"][0] + dx, 10, 70, 30, "weld, full circ.")
v.note(BASE["thread"][0] + dx + 3, -7, 60, -22, "M14×1.5-6g, 7.5 long; S3 on shoulder Ø22")
v.label_view("ELEMENT + BASE · SECTION (2:1)", 50, -32)
# media table
rows = [["Media grade (Mott scale)", "0.2  (primary)", "0.5  (alternate)"],
        ["Liquid rating, absolute", "≈1.4 µm", "≈2–3 µm (supplier to confirm)"],
        ["KL (liquid permeability coeff.)", "26", "8.0"],
        ["Permeance at 2.0 mm wall, 25 °C", f"{permeance_LMH_bar(E['KL'], 2.0):,.0f} L/m²·h·bar", f"{permeance_LMH_bar(E['KL_alt'], 2.0):,.0f} L/m²·h·bar"],
        ["Filter area", f"{element_area_m2() * 1e4:.1f} cm²", f"{element_area_m2() * 1e4:.1f} cm²"],
        ["Clean flow, squeeze 0.3 bar", f"{flow_Lmin(0.3):.2f} L/min", f"{flow_Lmin(0.3, E['KL_alt']):.2f} L/min"],
        ["Clean flow, tap 1.5 bar", f"{flow_Lmin(1.5):.1f} L/min", f"{flow_Lmin(1.5, E['KL_alt']):.1f} L/min (spout-limited)"],
        ["Max differential pressure", "3.4 bar outside-in (Mott std.)", "3.4 bar"]]
s.text(230 * PX, 40 * PX, "MEDIA SPECIFICATION (first pass, from Mott published KL)", 12, 700)
table(s, 230, 44, ["Property", "Grade 0.2", "Grade 0.5"], rows, [62, 46, 66], size=9.4, rowh=6.2)
s.text(230 * PX, 104 * PX, "Sintered media grade is not a liquid pore size: Mott rates grades 0.2–20 at", 9.8, 400, fill=THIN)
s.text(230 * PX, 108.5 * PX, "1.4–35 µm absolute in liquid. Grade 0.2 does not remove all bacteria;", 9.8, 400, fill=THIN)
s.text(230 * PX, 113 * PX, "the UV cap (v2) on the M14×1 stem covers disinfection.", 9.8, 400, fill=THIN)
s.save(OUT + "MPx-SQ-S05_Element.svg")

# ====================================================== S06 · ACCESSORIES ======================================================
s = Sheet(6, NS, "Tap and backflush adapters", "MPx-SQ-010…013", "316L bar · silicone sleeve", "Electropolished, passivated", "2.5:1",
          mass=f"{g('P10')} · {g('P11')} · {g('P12')} · {g('P13')} g", notes=["Item 10: male 28 PCO 1881 neck (T 27.40 ±0.13, lip flat and Ra ≤ 0.8) so it screws into item 1 like a bottle.",
          "Item 11 converts M24×1 female-spout taps to M22×1; item 12 fits plain round spouts Ø14–22 (silicone cone + 316L worm clamp).",
          "Item 13: backflush coupler; its PCO side takes a bottle of clean water or item 10, its M14×1 side screws onto the stem with the sleeve open.",
          "All tap-side faces sealed with S6 (Ø22/Ø16 × 2 silicone)."])
s.frame()
for (k, ox, oy, lab, dims_) in (("P10", 34, 80, "10 · TAP ADAPTER", [(0, 34, 15, 20, "34")]),
                                ("P11", 150, 80, "11 · M24 → M22 ADAPTER", [(0, 16, 13.5, 18, "16")]),
                                ("P12", 34, 190, "12 · UNIVERSAL TAP FERRULE", [(0, 22, 12.5, 17, "22")]),
                                ("P13", 235, 80, "13 · BACKFLUSH COUPLER", [(0, 54, 17.5, 22, "54")])):
    v = View(s, ox, oy, 2.5)
    sec(v, k); v.cl(-4, 0, max(x for x, _ in P[k]) + 4, 0)
    for (a, b, y, at, t) in dims_: v.dh(a, b, y, at, t)
    rmax = max(y for _, y in P[k]); v.dv(-rmax, rmax, 0, -8, f"Ø{2 * rmax:g}")
    v.label_view(lab, max(x for x, _ in P[k]) / 2, -rmax - 9)
v = View(s, 34, 80, 2.5); v.note(8, 13.7, 12, 24, "28 PCO 1881 male neck"); v.note(28, -11, 30, -26, "M22×1.0-6H")
v = View(s, 150, 80, 2.5); v.note(3, 12, 4, 22, "M24×1.0-6g"); v.note(13, -11, 18, -22, "M22×1.0-6g")
v = View(s, 34, 190, 2.5)
v.poly([(22, 9), (46, 11), (46, -11), (22, -9)], HID, 1.2, "none", dash="5 3"); v.t(30, 13, "silicone cone, Ø14–22 spouts", 9.5, 400, "start", HID)
v.note(4, 11, 10, 26, "M22×1.0-6g")
v = View(s, 235, 80, 2.5); v.note(8, 17.5, 10, 24, "28 PCO 1881 int."); v.note(50, -7, 56, -26, "M14×1.0-6H")
s.save(OUT + "MPx-SQ-S06_Adapters.svg")

# ====================================================== S07 · SEALS, MATERIALS, INTERFACES ======================================================
s = Sheet(7, NS, "Seals, materials, interfaces, performance", "MPx-SQ-020", "see tables", "—", "—", mass="—")
s.frame()
s.text(14 * PX, 22 * PX, "SEAL KIT · food-grade silicone, 60 ShA, FDA 21 CFR 177.2600 (team decision: silicone at every joint)", 12, 700)
yend = table(s, 14, 26, ["ID", "Type", "Location", "Size", "Qty", "Side"], [list(map(str, r_)) for r_ in SEALS], [10, 22, 72, 34, 10, 34], size=9.4, rowh=5.6)
s.text(14 * PX, (yend + 9) * PX, "MATERIALS", 12, 700)
mats = [["316L stainless (EN 1.4404)", "items 1–3, 5–7, 9–13", "Food contact, Cr-Ni-Mo; machine, then electropolish + passivate (ASTM A967)"],
        ["Sintered 316L powder", "item 4", "Porous media grade 0.2; ISO 4003 bubble point; no binders after sintering"],
        ["316L wire cloth", "item 8", "40 µm twilled Dutch weave pre-screen"],
        ["Silicone rubber, 60 ShA", "S1–S8, item 12 cone", "FDA 21 CFR 177.2600; post-cured; white/translucent, no pigment"]]
yend = table(s, 14, yend + 12, ["Material", "Used in", "Requirement"], mats, [48, 40, 94], size=9.4, rowh=5.6)
s.text(14 * PX, (yend + 9) * PX, "INTERFACES", 12, 700)
itf = [["Bottle", "28 mm PCO 1881 (T 27.40 ±0.13, E ~25.0, bore ~21.7, finish 17.0); 500 mL and 1 L PET"],
       ["Tap, threaded", "M22×1.0 male spouts → item 10; M24×1.0 female spouts → items 11 + 10"],
       ["Tap, plain", "round spouts Ø14–22 → item 12 + item 10"],
       ["UV cap (v2)", "M14×1.0-6g on the stem, 30 mm long × Ø36 free envelope ahead of the head face"]]
table(s, 14, yend + 12, ["Interface", "Definition"], itf, [30, 152], size=9.4, rowh=5.6)
s.text(230 * PX, 22 * PX, "FIRST-PASS PERFORMANCE (to be verified by simulation + tests)", 12, 700)
perf = [["Core unit mass (CAD)", f"{UNIT:.0f} g"], ["Size", f"Ø35 × {X_TIP + 2:g} mm with cap"],
        ["Capture (grade 0.2)", "≈1.4 µm absolute"], ["Clean flow, 0.2 / 0.3 / 0.4 bar", " / ".join(f"{flow_Lmin(b):.2f}" for b in (0.2, 0.3, 0.4)) + " L/min"],
        ["Clean flow, tap 1.5 bar", f"{flow_Lmin(1.5):.1f} L/min"], ["Element area", f"{element_area_m2() * 1e4:.1f} cm²"],
        ["Hold-up volume", f"≈{(3.1416 / 4 * (28 ** 2 - 20 ** 2) * 85 + 3.1416 / 4 * 16 ** 2 * 85) / 1000:.0f} mL"], ["Max ΔP on element", "3.4 bar outside-in"]]
table(s, 230, 26, ["Quantity", "Value"], perf, [70, 105], size=9.4, rowh=5.6)
s.text(230 * PX, 86 * PX, "VALIDATION PLAN", 12, 700)
plan = ["1  CFD (OpenFOAM, porous zone): flow vs squeeze pressure, annulus distribution",
        "2  Squeeze model: PET bottle pressure vs hand force (FEA or measured)",
        "3  Fouling: cake-filtration model, flux decline vs litres for tap water",
        "4  FEA: thin wall + threads at 3.4 bar and 1 m drop",
        "5  Bench: bubble point, flow vs ΔP rig, leak test 1.5 bar",
        "6  Challenge: 1, 2, 5, 10 µm PS beads, count before/after (Foldscope/50×)",
        "7  Backflush recovery after 20 L of loaded water"]
for i, l in enumerate(plan): s.text(230 * PX, (92 + i * 5.2) * PX, l, 10.2, 400)
s.save(OUT + "MPx-SQ-S07_Seals_Materials.svg")
print("sheets ok")
