import json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter
from dims import *
MS = json.load(open("masses.json"))["mass_g"]

wb = Workbook()
F = "Arial"
H = Font(name=F, bold=True, color="FFFFFF"); HF = PatternFill("solid", fgColor="1F3A5F")
BLUE = Font(name=F, color="0000FF"); BLK = Font(name=F); BOLD = Font(name=F, bold=True)
YEL = PatternFill("solid", fgColor="FFF2CC")
thin = Side(style="thin", color="BFBFBF"); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)

def sheet(ws, headers, widths):
    for i, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(1, i, h); c.font = H; c.fill = HF; c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"; ws.row_dimensions[1].height = 30

# ---------------- BOM ----------------
ws = wb.active; ws.title = "BOM"
sheet(ws, ["Item", "Part no.", "Name", "Material / spec", "Stock / source form", "Process", "Make/Buy", "Qty per kit", "Mass g (CAD)",
           "Est. unit cost ₹ (proto)", "Line cost ₹", "Supplier candidates", "Notes"],
      [6, 12, 30, 40, 28, 30, 9, 9, 10, 13, 12, 40, 44])
rows = [
 (1, "MPx-SQ-001", "Inlet coupler (bottle side)", "316L; 28 PCO 1881 int. + M32×1.0-6H int.", "Ø38 316L bar", "CNC turn, single-point PCO thread, knurl", "Make", 1, MS["P01"], 900, "Peenya CNC job shops (Bangalore)", "Measure bottle thread starts before cutting (sheet 3)"),
 (2, "MPx-SQ-002", "Body", "316L; M32×1.0-6g both ends; wall 1.0", "Ø35 316L bar (proto) / 30×1.0 tube + ferrules (prod.)", "CNC turn + bore, ream Ø28 H9", "Make", 1, MS["P02"], 1200, "Peenya CNC job shops", "Thin wall: steady rest, light cuts"),
 (3, "MPx-SQ-003", "Outlet head + spout stem", "316L; M32×1 int., M14×1.5 int., M14×1 ext.", "Ø38 316L bar", "CNC turn, mill flats, drill cross-ports", "Make", 1, MS["P03"], 1100, "Peenya CNC job shops", ""),
 (4, "MPx-SQ-004", "Filter element, sintered", "Sintered 316L tube Ø20×2.0, closed end, grade 0.2", "Custom sintered tube", "Sinter (supplier)", "Buy", 1, MS["P04"], 1500, "Britomatics (Navi Mumbai); Aris Filtration (Ahmedabad); Porvair India (Ambarnath); Hengko (CN, MOQ 100); Mott (US)", "Ask for liquid absolute rating + bubble point per piece"),
 (5, "MPx-SQ-005", "Element base", "316L; M14×1.5-6g; welded to item 4", "Ø25 316L bar", "CNC turn; TIG/laser weld to item 4", "Make", 1, MS["P05"], 500, "CNC shop + weld shop (or the sintering supplier)", "Weld may be done by the element supplier"),
 (6, "MPx-SQ-006", "Push-pull sleeve", "316L", "Ø14 316L bar", "CNC turn", "Make", 1, MS["P06"], 300, "Peenya CNC job shops", ""),
 (7, "MPx-SQ-007", "Dust cap", "316L", "Ø16 316L bar", "CNC turn", "Make", 1, MS["P07"], 250, "Peenya CNC job shops", ""),
 (8, "MPx-SQ-008", "Pre-screen disc", "316L twilled Dutch weave 40 µm, Ø20", "Wire cloth sheet", "Punch / laser cut", "Buy", 1, 0.1, 80, "SS wire-mesh traders (Bangalore/Mumbai)", ""),
 (9, "MPx-SQ-009", "Screen retaining ring", "316L Ø20.05/Ø14 × 0.7", "316L sheet 0.7", "Laser cut / punch", "Make", 1, MS["P09"], 60, "Laser-cutting shop", ""),
 (10, "MPx-SQ-010", "Tap adapter (M22 female)", "316L; 28 PCO 1881 male neck + M22×1 int.", "Ø35 316L bar", "CNC turn", "Make", 1, MS["P10"], 800, "Peenya CNC job shops", "Neck lip Ra ≤ 0.8 to seal on S1"),
 (11, "MPx-SQ-011", "M24 → M22 tap adapter", "316L; M24×1 male / M22×1 male", "Hex 27 316L bar", "CNC turn", "Make", 1, MS["P11"], 400, "CNC shop, or buy a brass aerator adapter for trials", ""),
 (12, "MPx-SQ-012", "Universal tap ferrule + silicone sleeve", "316L ferrule M22×1 + silicone cone + 316L worm clamp", "Ø25 bar + bought sleeve/clamp", "CNC turn; buy sleeve + clamp", "Make/Buy", 1, MS["P12"], 450, "CNC shop; silicone sleeve from a food-grade silicone moulder", ""),
 (13, "MPx-SQ-013", "Backflush coupler", "316L; 28 PCO 1881 int. + M14×1 int.", "Ø38 316L bar", "CNC turn", "Make", 1, MS["P13"], 900, "Peenya CNC job shops", ""),
 ("S", "MPx-SQ-020", "Seal kit S1–S8", "Silicone 60 ShA, FDA 21 CFR 177.2600", "O-rings + cut gaskets", "Buy / cut from sheet", "Buy", 1, 2, 350, "AMI Polymer (India) or food-grade O-ring stockists", "See Seals tab"),
 ("F", "—", "Electropolish + passivation (lot)", "ASTM A967", "—", "Subcontract", "Buy", 1, 0, 1500, "SS finishing shops (Peenya)", "Per batch of parts"),
]
for i, r_ in enumerate(rows, 2):
    for j, v in enumerate(r_[:9], 1):
        c = ws.cell(i, j, v); c.font = BLK; c.border = BOX; c.alignment = Alignment(wrap_text=True, vertical="top")
    c = ws.cell(i, 10, r_[9]); c.font = BLUE; c.fill = YEL; c.border = BOX; c.number_format = "₹#,##0"
    c = ws.cell(i, 11, f"=H{i}*J{i}"); c.font = BLK; c.border = BOX; c.number_format = "₹#,##0"
    for j, v in ((12, r_[10]), (13, r_[11])):
        c = ws.cell(i, j, v); c.font = BLK; c.border = BOX; c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(i, 9).number_format = "0"
n = len(rows) + 1
ws.cell(2, 10).comment = Comment("Rough prototype estimates (one-off CNC in Bangalore, 316L at roughly ₹450–600/kg). Replace every yellow cell with RFQ quotes.", "MPx")
ws.cell(5, 10).comment = Comment("IndiaMART listings for sintered SS filters/tubes range about ₹375–3,000 per piece; custom size quote needed.", "MPx")
t = n + 2
ws.cell(t, 3, "Core unit mass, items 1–9 + seals (g)").font = BOLD
ws.cell(t, 9, f"=SUM(I2:I10)+I15").font = BOLD; ws.cell(t, 9).number_format = "0"
ws.cell(t + 1, 3, "Accessories mass, items 10–13 (g)").font = BOLD
ws.cell(t + 1, 9, "=SUM(I11:I14)").font = BOLD; ws.cell(t + 1, 9).number_format = "0"
ws.cell(t + 2, 3, "Prototype kit cost, all lines (₹)").font = BOLD
ws.cell(t + 2, 11, f"=SUM(K2:K{n})").font = BOLD; ws.cell(t + 2, 11).number_format = "₹#,##0"
ws.cell(t + 3, 3, "Number of prototype kits").font = BOLD
c = ws.cell(t + 3, 11, 3); c.font = BLUE; c.fill = YEL
ws.cell(t + 4, 3, "Prototype budget needed (₹)").font = BOLD
ws.cell(t + 4, 11, f"=K{t + 2}*K{t + 3}").font = BOLD; ws.cell(t + 4, 11).number_format = "₹#,##0"
ws.cell(t + 5, 3, "PD-298 department prototyping cap (₹)").font = BOLD
c = ws.cell(t + 5, 11, 50000); c.font = BLUE; c.number_format = "₹#,##0"
ws.cell(t + 6, 3, "Within cap?").font = BOLD
ws.cell(t + 6, 11, f'=IF(K{t + 4}<=K{t + 5},"yes","no")').font = BOLD
ws.cell(t + 8, 3, "Legend: yellow cells with blue text are estimates or choices to edit; everything else is calculated or from the drawings / CAD.").font = Font(name=F, italic=True)

# ---------------- Suppliers ----------------
ws2 = wb.create_sheet("Suppliers")
sheet(ws2, ["Item", "Supplier", "Location", "What they list", "Ask in the RFQ", "Source"], [8, 30, 22, 46, 60, 50])
sup = [
 ("4", "Britomatics Engineers Pvt Ltd", "Navi Mumbai", "SS304/SS316 sintered metal filters, 0.5–25 µm, from ~₹375", "Custom tube Ø20×2.0×85.5 closed end, 316L, finest grade; liquid absolute rating; bubble point; welded base", "https://m.indiamart.com/city/thane/sintered-metal-filters.html"),
 ("4", "Aris Filtration", "Ahmedabad", "316L cylindrical sintered filter tubes, ~₹3,000", "Same as above; qty 5–10 for prototypes", "https://m.indiamart.com/impcat/filter-tubes.html"),
 ("4", "Porvair Filtration India", "Ambarnath", "Porous metal media and elements", "Sinter-bonded closed-end tubes; liquid rating ≤ 1.5 µm", "https://m.indiamart.com/city/thane/sintered-metal-filters.html"),
 ("4", "Hengko", "China", "Sintered 316L tubes 2–90 µm; MOQ 100; 20–35 days", "Finest grade available; liquid absolute rating test data; sample pieces", "https://hengko.com/sintered-metal-powder-porous-316l-ss-stainless-steel-filter-tube-2-um-5-7-10-15-20-30-40-50-60-70-90-micron-products"),
 ("4", "Mott Corporation", "USA (via distributor)", "Media grades 0.2–100 in 316L; liquid ratings 1.4–35 µm absolute for grades 0.2–20", "Grade 0.2 and 0.5 tube samples with KL data", "https://www.mottcorp.com/blog/filtration-advancements-using-sintered-porous-metal-filters/"),
 ("1–3, 5–7, 10–13", "CNC turning job shops", "Peenya, Bangalore", "316L turning, threading, knurling", "Drawing set sheets 2–6; 3 kits; electropolish + passivation", "local"),
 ("S1–S8", "AMI Polymer Pvt Ltd (Imaseal) or similar", "India", "O-rings incl. silicone, food grade", "FDA 21 CFR 177.2600 silicone, sizes on Seals tab, certificate of compliance", "https://www.directindustry.com/prod/ami-polymer-pvt-ltd/product-238681-2835732.html"),
]
for i, r_ in enumerate(sup, 2):
    for j, v in enumerate(r_, 1):
        c = ws2.cell(i, j, v); c.font = BLK; c.border = BOX; c.alignment = Alignment(wrap_text=True, vertical="top")

# ---------------- Seals ----------------
ws3 = wb.create_sheet("Seals")
sheet(ws3, ["ID", "Type", "Location", "Size (ID × CS or OD/ID × t), mm", "Qty", "Side of filter"], [6, 14, 44, 30, 6, 22])
for i, r_ in enumerate(SEALS, 2):
    for j, v in enumerate(r_, 1):
        c = ws3.cell(i, j, v); c.font = BLK; c.border = BOX
ws3.cell(len(SEALS) + 3, 1, "All silicone 60 ShA, FDA 21 CFR 177.2600, post-cured, unpigmented (team decision: silicone at every joint).").font = Font(name=F, italic=True)

# ---------------- Flow ----------------
ws4 = wb.create_sheet("Flow")
sheet(ws4, ["Input / result", "Value", "Unit", "Note"], [40, 14, 16, 70])
inp = [
 ("Mott liquid permeability coefficient KL", E["KL"], "—", "Grade 0.2 = 26; grade 0.5 = 8.0 (Mott 316L pressed-disc data sheet)"),
 ("Wall thickness", E["wall"], "mm", "Element wall"),
 ("Water viscosity", 0.89, "cP", "25 °C"),
 ("Element OD", E["OD"], "mm", ""),
 ("Sintered length", E["x_open"] - E["cap"][1], "mm", "Plus the closed end disc"),
 ("Driving pressure", 0.3, "bar", "Squeeze ≈ 0.2–0.4 bar; tap ≈ 1–2 bar (to be measured)"),
 ("Fouling factor", 1.0, "×", "1 = clean media; raise as the cake builds"),
]
for i, (a, b, c_, d) in enumerate(inp, 2):
    ws4.cell(i, 1, a).font = BLK; x = ws4.cell(i, 2, b); x.font = BLUE; x.fill = YEL; ws4.cell(i, 3, c_).font = BLK; ws4.cell(i, 4, d).font = BLK
res = [
 ("Permeance", "=1/(B2*B4*B3/25.4)*2444.9*14.504", "L/(m²·h·bar)", "Mott: ΔP[psi] = KL·flux[gpm/ft²]·µ[cP]·t[in]"),
 ("Filter area", "=(PI()*B5*B6+PI()/4*B5^2)/1e6", "m²", "Side + closed end"),
 ("Clean-media flow", "=B9*B10*B7/60/B8", "L/min", "First pass; CFD and bench tests replace this"),
 ("Time to filter 500 mL", "=0.5/B11*60", "s", ""),
 ("Time to filter 1 L", "=1/B11*60", "s", ""),
]
for i, (a, f, u, d) in enumerate(res, 9):
    ws4.cell(i, 1, a).font = BOLD; c = ws4.cell(i, 2, f); c.font = BLK; c.number_format = "#,##0.00"; ws4.cell(i, 3, u).font = BLK; ws4.cell(i, 4, d).font = BLK
for wsx in wb.worksheets:
    for row in wsx.iter_rows():
        for c in row:
            if c.font and c.font.name != F: c.font = Font(name=F, bold=c.font.bold, color=c.font.color, italic=c.font.italic)
out = "/mnt/user-data/outputs/squeeze/MPx_Squeeze_v1_BOM.xlsx"
wb.save(out); print(out)
