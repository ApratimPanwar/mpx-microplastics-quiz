"""Half-section profiles (x, r) of every turned part, in assembly coordinates (closed polygons, r >= 0).
The CAD revolves these; the drawings mirror them. Threads, knurls, flats and cross-holes are added as features/notes."""
from dims import *

r = lambda d: d / 2
P = {}
# P01 inlet coupler
P["P01"] = [(0, r(PCO_F["major"])), (0, r(C["D"])), (C["x1"], r(C["D"])), (C["x1"], 16.0), (B["x0"], 16.0),
            (B["x0"], r(SCREEN["cb_D"])), (B["x0"] - SCREEN["cb_depth"], r(SCREEN["cb_D"])), (B["x0"] - SCREEN["cb_depth"], r(C["through"])),
            (C["web"][0], r(C["through"])), (C["web"][0], r(PCO_F["major"]))]
# P02 body
P["P02"] = [(B["x0"], r(B["bore"])), (B["x0"], r(B["end_D"])), (B["x0"] + B["thread_L"], r(B["end_D"])), (B["x0"] + B["thread_L"], r(B["mid_D"])),
            (B["x1"] - B["thread_L"], r(B["mid_D"])), (B["x1"] - B["thread_L"], r(B["end_D"])), (B["x1"], r(B["end_D"])), (B["x1"], r(B["bore"]))]
# P03 outlet head (with stem and plug pin)
P["P03"] = [(H["x_thread0"], 16.0), (H["x_thread0"], r(H["D"])), (H["web"][1], r(H["D"])), (H["web"][1], 7.0), (H["st_x"][1], 7.0),
            (H["st_x"][1], r(H["stem_D"])), (147.5, r(H["stem_D"])), (147.5, 2.0), (153.0, 2.0), (153.0, 0), (146.0, 0), (146.0, r(H["bore"])),
            (H["web"][1], r(H["bore"])), (H["web"][1], 7.0), (H["web"][0], 7.0), (H["web"][0], 16.0)]
# P04 sintered element (closed end upstream)
P["P04"] = [(E["cap"][0], 0), (E["cap"][0], r(E["OD"])), (E["x_open"], r(E["OD"])), (E["x_open"], r(E["OD"]) - E["wall"]),
            (E["cap"][1], r(E["OD"]) - E["wall"]), (E["cap"][1], 0)]
# P05 element base (spigot into the element bore, collar welded to the element, shoulder, M14x1.5 thread)
P["P05"] = [(111.5, r(BASE["bore"])), (111.5, 7.95), (BASE["land"][0], 7.95), (BASE["land"][0], 10.0), (BASE["land"][1], 10.0),
            (BASE["shoulder"][0], r(BASE["shoulder_D"])), (BASE["shoulder"][1], r(BASE["shoulder_D"])), (BASE["shoulder"][1], 7.0),
            (BASE["thread"][1], 7.0), (BASE["thread"][1], r(BASE["bore"]))]
# P06 push-pull sleeve (closed position)
P["P06"] = [(H["st_x"][1], r(SL["bore"])), (H["st_x"][1], r(SL["OD"])), (X_TIP, r(SL["OD"])), (X_TIP, 2.03), (149.5, 2.03), (149.5, r(SL["bore"]))]
# P07 dust cap (fitted)
P["P07"] = [(141.5, r(DC["ID"])), (141.5, r(DC["OD"])), (155.5, r(DC["OD"])), (155.5, 0), (154.5, 0), (154.5, r(DC["ID"]))]
# P09 screen retaining ring
P["P09"] = [(16.8, 7.0), (16.8, r(SCREEN["cb_D"])), (B["x0"], r(SCREEN["cb_D"])), (B["x0"], 7.0)]
# accessories (own coordinates, x = 0 at the face that meets the coupler gasket / head face)
P["P10"] = [(0, 10.0), (0, r(PCO["T"])), (PCO["F"], r(PCO["T"])), (PCO["F"], 16.5), (PCO["F"] + 2, 16.5), (PCO["F"] + 2, 13.5),
            (TAP["L"], 13.5), (TAP["L"], 11.0), (22.0, 11.0), (22.0, 10.0)]
P["P11"] = [(0, 7.0), (0, 12.0), (7, 12.0), (7, 13.5), (9, 13.5), (9, 11.0), (16, 11.0), (16, 7.0)]
P["P12"] = [(0, 6.0), (0, 11.0), (8, 11.0), (8, 12.5), (12, 12.5), (12, 9.0), (22, 9.0), (22, 6.0)]
P["P13"] = [(0, r(PCO_F["major"])), (0, r(BF["D"])), (17.5, r(BF["D"])), (17.5, 8.0), (51.0, 8.0), (51.0, 10.5), (54, 10.5), (54, 7.0),
            (46.0, 7.0), (46.0, 6.6), (20, 6.6), (20, 4.0), (15.5, 4.0), (15.5, r(PCO_F["major"]))]
NAMES = {
    "P01": "Inlet coupler (bottle side)", "P02": "Body", "P03": "Outlet head + spout stem", "P04": "Filter element, sintered",
    "P05": "Element base", "P06": "Push-pull sleeve", "P07": "Dust cap", "P08": "Pre-screen, 40 µm mesh", "P09": "Screen retaining ring",
    "P10": "Tap adapter (M22 female)", "P11": "M24 → M22 tap adapter", "P12": "Universal tap ferrule + silicone sleeve", "P13": "Backflush coupler",
}
