// MPx Squeeze v2 (Mini): exploded and cutaway illustrations from the v2 drawing-set profiles (mm, CAD x along the axis,
// x = 0 at the cap's bottle-side face). World z is up; the unit hangs under an inverted bottle, so CAD +x points down.
self.DrawingModels ??= {};
(() => {
  const TAU = Math.PI * 2;
  // half-section profiles [x, r] from MPx-SQ2 drawings (profiles.py); the cap carries the grip-ring groove
  const PROF = {
    bottle: [[-14, 10.85], [-14, 13.7], [-2.6, 13.7], [-2.6, 16.5], [-1.1, 16.5], [-1.1, 13.7], [14.4, 13.7], [14.4, 10.85]],
    cap: [[0, 14.2], [0, 16.2], [15.5, 16.2], [15.5, 26], [22.3, 26], [22.3, 24.9], [24.7, 24.9], [24.7, 26], [28.7, 26], [28.7, 24],
      [21, 24], [21, 24.2], [19.5, 24.2], [19.5, 21.75], [18.35, 21.75], [18.35, 20.25], [19.5, 20.25], [19.5, 20], [18, 20],
      [18, 7.5], [15.5, 7.5], [15.5, 14.2]],
    prefilter: [[-12.5, 0], [-12.5, 8.5], [15.5, 8.5], [15.5, 7.5], [18, 7.5], [18, 6], [14.8, 6], [14.8, 7.8], [-11.8, 7.8], [-11.8, 0]],
    gasket: [[14, 9.5], [14, 12.75], [15.5, 12.75], [15.5, 9.5]],
    frame: [[19.5, 19.25], [19.5, 22.5], [21.9, 22.5], [21.9, 20.025], [20.3, 20.025], [20.3, 19.25]],
    disc: [[20.3, 0], [20.3, 20], [21.9, 20], [21.9, 0]],
    base: [[22.7, 1.5], [22.7, 19], [21.9, 19], [21.9, 20.25], [23.05, 20.25], [23.05, 21.75], [21.9, 21.75], [21.9, 22.6], [19.9, 22.6],
      [19.9, 23.5], [21, 23.5], [21, 24], [29, 24], [29, 26], [32, 26], [32, 22], [24.7, 22], [24.7, 6], [37, 6], [37, 4.5], [46, 4.5],
      [46, 1.75], [49.5, 1.75], [49.5, 0], [45.5, 0], [45.5, 1.5]],
    sleeve: [[41, 4.5], [41, 6], [54, 6], [54, 1.775], [50.5, 1.775], [50.5, 4.5]],      // pulled open 4 mm, as in use
  };
  const ORING = (xc, rc, cs) => Array.from({ length: 36 }, (_, i) => { const a = TAU * i / 36; return [xc + cs / 2 * Math.sin(a), rc + cs / 2 * Math.cos(a)]; });
  PROF.s2 = ORING(18.92, 21, 1.5);
  PROF.s3 = ORING(22.48, 21, 1.5);
  PROF.grip = ORING(23.5, 25.55, 2.3);
  const Z0 = 60;                                     // world z of the cap's top face
  const FRAME = { origin: [0, 0, Z0], xAxis: [0, 0, -1], yAxis: [0, 1, 0], zAxis: [1, 0, 0] };
  const VALVE = { r: 21, a: 0 };                     // set per drawing so the valve faces the viewer

  // ---- a lathe over an arc whose end caps may be concave: side surface like the helper's, caps ear-clipped ----
  function area(pts) { let s = 0; for (let i = 0; i < pts.length; i++) { const [a, b] = pts[i], [c, d] = pts[(i + 1) % pts.length]; s += a * d - c * b; } return s / 2; }
  function earClip(pts) {
    const idx = pts.map((_, i) => i); if (area(pts) < 0) idx.reverse();
    const tri = [], cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const inside = (p, a, b, c) => cross(a, b, p) >= -1e-9 && cross(b, c, p) >= -1e-9 && cross(c, a, p) >= -1e-9;
    let guard = 0;
    while (idx.length > 3 && guard++ < 5000) {
      let cut = false;
      for (let i = 0; i < idx.length; i++) {
        const ia = idx[(i + idx.length - 1) % idx.length], ib = idx[i], ic = idx[(i + 1) % idx.length];
        const [a, b, c] = [pts[ia], pts[ib], pts[ic]];
        if (cross(a, b, c) <= 1e-9) continue;
        if (idx.some((j) => j !== ia && j !== ib && j !== ic && inside(pts[j], a, b, c) && !(pts[j][0] === a[0] && pts[j][1] === a[1]) && !(pts[j][0] === c[0] && pts[j][1] === c[1]))) continue;
        tri.push([ia, ib, ic]); idx.splice(i, 1); cut = true; break;
      }
      if (!cut) throw Error("cap triangulation failed");
    }
    tri.push([idx[0], idx[1], idx[2]]);
    return tri;
  }
  function cutLathe(G, p, profile, start, end, { segments = 144, role = "edge", rings = true } = {}) {
    const n = Math.ceil(segments * (end - start) / TAU), cols = n + 1, off = p.vertices.length;
    const id = (i, j) => off + i * cols + j;
    for (const [x, r] of profile) for (let j = 0; j < cols; j++) { const t = start + (end - start) * j / n; p.vertices.push([x, r * Math.cos(t), r * Math.sin(t)]); }
    for (let i = 0; i < profile.length; i++) {
      const k = (i + 1) % profile.length;
      for (let j = 0; j < n; j++) {
        const a = id(i, j), b = id(k, j), c = id(k, j + 1), d = id(i, j + 1);
        p.triangles.push([a, b, c], [a, c, d]);
        if (rings) G.line(p, p.vertices[a], p.vertices[d], role);
      }
    }
    const tris = earClip(profile);
    for (const side of [0, cols - 1]) {
      for (const [a, b, c] of tris) p.triangles.push(side === 0 ? [id(a, side), id(c, side), id(b, side)] : [id(a, side), id(b, side), id(c, side)]);
      for (let i = 0; i < profile.length; i++) G.line(p, p.vertices[id(i, side)], p.vertices[id((i + 1) % profile.length, side)], role);
    }
    return p;
  }
  // build one turned body in CAD coordinates and hang it on the world axis
  function body(G, p, profile, cut, opts = {}) {
    const pc = G.piece();
    if (cut) cutLathe(G, pc, profile, cut[0], cut[1], opts);
    else G.lathe(pc, profile, opts);
    G.transform(pc, FRAME);
    G.merge(p, pc);
  }
  function radialBoxes(G, p, n, w, r0, r1, x0, x1, phase, keep) {   // ribs, as thin plates around the axis (CAD frame)
    for (let i = 0; i < n; i++) {
      const t = phase + TAU * i / n;
      if (keep && !keep(t)) continue;
      const pc = G.piece();
      G.box(pc, [x0, r0, -w / 2], [x1, r1, w / 2]);
      G.transform(pc, { origin: [0, 0, 0], xAxis: [1, 0, 0], yAxis: [0, Math.cos(t), Math.sin(t)], zAxis: [0, -Math.sin(t), Math.cos(t)] });
      G.transform(pc, FRAME);
      G.merge(p, pc);
    }
  }
  function axialLines(G, p, r, x0, x1, n, keep, role = "texture") {    // straight knurl / weave lines on a cylinder (CAD frame)
    for (let i = 0; i < n; i++) {
      const t = TAU * i / n; if (keep && !keep(t)) continue;
      const pc = G.piece(); G.line(pc, [x0, r * Math.cos(t), r * Math.sin(t)], [x1, r * Math.cos(t), r * Math.sin(t)], role); G.transform(pc, FRAME); G.merge(p, pc);
    }
  }
  function ringLine(G, p, x, r, role = "texture") { const pc = G.piece(); G.ring(pc, x, r, { role }); G.transform(pc, FRAME); G.merge(p, pc); }

  function build(G, { cut = null, valveT }) {
    const keep = cut ? (t) => { const u = ((t - cut[0]) % TAU + TAU) % TAU; return u > 0.02 && u < cut[1] - cut[0] - 0.02; } : null;
    const parts = [];
    const mk = (id, name, ex) => { const p = G.part(id, name); parts.push(p); p.explosion = [0, 0, ex]; return p; };
    // context: the neck of the PET bottle (clear)
    const bottle = mk("bottle", "PET bottle neck, 28 mm PCO", 82);
    body(G, bottle, PROF.bottle, cut, { creaseAngle: 30 });
    bottle.transparent = true;
    // air-return valve: a silicone umbrella on the cap shoulder over a Ø1.2 passage
    const valve = mk("valve", "Air-return valve, silicone", 46);
    {
      const pc = G.piece();
      G.lathe(pc, [[0, 0], [0, 3.1], [0.6, 2.9], [1.15, 2.1], [1.45, 1.0], [1.55, 0]], { creaseAngle: 25 });      // dome, built along +x
      G.lathe(pc, [[1.55, 0], [1.55, 0.6], [3.2, 0.6], [3.2, 0]], {});                                            // stem through the web
      G.transform(pc, { origin: [15.5 - 0.0, VALVE.r * Math.cos(valveT), VALVE.r * Math.sin(valveT)], xAxis: [-1, 0, 0], yAxis: [0, -1, 0], zAxis: [0, 0, 1] });
      G.transform(pc, FRAME); G.merge(valve, pc);
      const wx = VALVE.r * Math.sin(valveT), wy = VALVE.r * Math.cos(valveT), m = Math.hypot(wx, wy);    // world position of the valve
      const right = [-Math.sin(CAMERA.azimuth * Math.PI / 180), Math.cos(CAMERA.azimuth * Math.PI / 180)]; valve.explosion = [right[0] * 34 + wx / m * 4, right[1] * 34 + wy / m * 4, 20];     // up off its seat and out to the right of the stack                                                       // up off its seat and out beside the stack
    }
    const gasket = mk("gasket", "Bottle gasket, silicone", 62);
    body(G, gasket, PROF.gasket, cut, { segments: 144 });
    const pre = mk("prefilter", "Built-in prefilter, 20 micron", 34);
    body(G, pre, PROF.prefilter, cut, { segments: 144 });
    for (let x = -10; x <= 13; x += 2.3) ringLine(G, pre, x, 8.52);
    axialLines(G, pre, 8.52, -12.4, 14.7, 48, keep);
    const cap = mk("cap", "Inlet cap, M48 × 1", 0);
    body(G, cap, PROF.cap, cut, { segments: 144 });
    radialBoxes(G, cap, 8, 1.2, 7.6, 19, 18, 20.3, Math.PI / 8, keep);
    axialLines(G, cap, 26.02, 18.7, 22.2, 120, keep);
    axialLines(G, cap, 26.02, 24.8, 28.6, 120, keep);
    const grip = mk("grip", "Grip ring, silicone", 22);
    body(G, grip, PROF.grip, cut, { segments: 144, creaseAngle: 40 });
    const s2 = mk("s2", "Upper O-ring", -17);
    body(G, s2, PROF.s2, cut, { segments: 144, creaseAngle: 40 });
    const cas = mk("cassette", "Disc cassette A, 1 micron", -32);
    body(G, cas, PROF.frame, cut, { segments: 144 });
    body(G, cas, PROF.disc, cut, { segments: 144 });
    for (const r of [5, 10, 15]) ringLine(G, cas, 20.29, r);
    const s3 = mk("s3", "Lower O-ring", -47);
    body(G, s3, PROF.s3, cut, { segments: 144, creaseAngle: 40 });
    const base = mk("base", "Base and spout stem", -64);
    body(G, base, PROF.base, cut, { segments: 144 });
    radialBoxes(G, base, 8, 1.2, 1.6, 19, 21.9, 22.7, 0, keep);
    axialLines(G, base, 26.02, 29.2, 31.8, 120, keep);
    const sleeve = mk("sleeve", "Push-pull sleeve", -86);
    body(G, sleeve, PROF.sleeve, cut, { segments: 144 });
    return parts;
  }
  const CAMERA = { azimuth: -58, elevation: 18, roll: 0 };
  const viewT = (90 - CAMERA.azimuth) * Math.PI / 180;                // lathe angle that faces the viewer
  self.DrawingModels["squeeze-exploded"] = (parameters, options) => {
    const G = TechnicalGeometry;
    const parts = build(G, { cut: null, valveT: viewT - 0.35 });
    const trails = [{ a: [0, 0, Z0 + 26], b: [0, 0, Z0 - 56], from: "bottle", to: "sleeve" }];
    return TechnicalProjection.render(parts, { ...options, camera: CAMERA, trails });
  };
  self.DrawingModels["squeeze-cutaway"] = (parameters, options) => {
    const G = TechnicalGeometry;
    const w = parameters.cut;
    if (!Number.isFinite(w) || w < 60 || w > 180) throw Error("Cut must be 60–180°");
    const half = w * Math.PI / 360;
    const cut = [viewT + half, viewT - half + TAU];
    const parts = build(G, { cut, valveT: viewT + half + 0.45 });
    for (const p of parts) p.explosion = [0, 0, 0];         // a cutaway is read assembled
    return TechnicalProjection.render(parts, { ...options, camera: { azimuth: -58, elevation: 24, roll: 0 } });
  };
})();
