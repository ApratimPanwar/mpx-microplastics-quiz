# MPx Squeeze v2 — teardown evidence

Use: explain how the v2 squeeze filter goes together and how water passes through it, for the PD-298 report and reviews.
Output: standalone preview page (A3 landscape sheets, SVG / PNG 4961 × 3508 / PDF A3 downloads). Illustrative, not for manufacture (`concept: true`).

| Feature group | Evidence | How it is used |
| --- | --- | --- |
| Inlet cap, base, sleeve, prefilter cup + collar, cassette frame + disc, bottle gasket, O-rings | Supplied geometry: MPx-SQ2 drawing set (`sq2/profiles.py`, `sq2/dims.py`), mm | Half-section profiles copied exactly and revolved; sleeve shown pulled open 4 mm (in-use pose) |
| Roof ribs (8), drain ribs (8), straight knurl (120) | Supplied: drawing notes on sheets 2 and 4 | Counts and sizes as drawn |
| M48 × 1, M12 × 1 and 28 PCO threads | Supplied, but drawn as features only | Omitted from the geometry; named in part labels |
| Grip ring (silicone, Ø51 × 2.3 cross-section, groove 22.3–24.7) | Design addition from the product renders, not yet in the v2 drawings | Modelled as shown in the renders; flagged in the delivery note |
| Air-return umbrella valve on the cap shoulder | Proposed in the design discussion (Ø6.2 dome, Ø1.2 stem), not yet in the v2 drawings | Illustrative; placed at r 21 on the shoulder face |
| PET bottle neck | Supplied interface: 28 mm PCO 1881 (bore Ø21.7, thread Ø27.4, support ring Ø33) | Context part only, drawn transparent |
| Tweezer slots in the base rim, Ø2 stem cross-port | Supplied | Omitted (below the reproduction size at the sheet scale) |

## Rebuild and proof

```sh
npm install                                    # jspdf, svg2pdf.js, @fontsource-variable/inter
node tools/teardown/scripts/proof.cjs drawing.json proof/
node tools/teardown/scripts/build-viewer.cjs drawing.json dist/index.html
node tools/teardown/scripts/check-viewer.cjs dist/index.html check/
```

Proof notes: the most hidden exploded part (upper O-ring) shows 55 % of its own linework; every other part shows more.
