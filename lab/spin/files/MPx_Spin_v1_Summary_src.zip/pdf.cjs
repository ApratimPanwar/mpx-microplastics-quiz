const { chromium } = require("playwright"); const fs = require("fs");
(async () => { const b = await chromium.launch(); const p = await b.newPage();
const fs_ = fs.readdirSync("out").filter(f => f.endsWith(".svg")).sort();
const html = `<html><head><style>@page{size:1920px 1080px;margin:0}body{margin:0}img{display:block;width:1920px;height:1080px;page-break-after:always}</style></head><body>${fs_.map(f => `<img src="file://${process.cwd()}/out/${f}">`).join("")}</body></html>`;
fs.writeFileSync("deck.html", html); await p.goto("file://" + process.cwd() + "/deck.html"); await p.waitForTimeout(1500);
await p.pdf({ path: "MPx_Spin_v1_Summary_Slides.pdf", width: "1920px", height: "1080px", printBackground: true });
await b.close(); })();
