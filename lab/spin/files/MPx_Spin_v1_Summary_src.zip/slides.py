import json, math, os
from lib import *

D = json.load(open("data.json"))
TOTAL = 19
KICK = "MPx Spin v1 (Concept 04 developed) · design review"
SL = []
BLUEW = "#3B7BB8"
V1 = D["v1"]; RIG = D["rig"]; EXP = D["exp"]
PAP = {p["k"]: p for p in D["papers"]}
WAT = {w["k"]: w for w in D["waters"]}
KX = RIG["Kmodel"] / RIG["Kdata"]


def add(fn, title, body):
    SL.append((fn, title, body))


def hdr(n, title, sub=None):
    return header(n, TOTAL, title, sub, kicker=KICK)


def bullets(x, y, items, size=20, maxw=600, gap=14, dot=ORANGE, lh=None):
    s, yy = "", y
    for it in items:
        s += f'<circle cx="{x + 5}" cy="{yy - size * 0.33:.1f}" r="4" fill="{dot}"/>'
        p, h = P(x + 22, yy, it, size, maxw - 22, lh)
        s += p
        yy += h + gap
    return s, yy - y


def table(x, y, w, cols, rows, size=15.5, lh=21, head=GREY_BG, hfg=MUTED, bold0=True, zebra=True, pad=18):
    """cols: [(name, width)], rows: list of lists of str. Returns svg, height."""
    s = rect(x, y, w, 34, head, 6)
    cx = x + pad; xs = []
    for k, cw in cols:
        xs.append(cx); s += T(cx, y + 23, k, 14, 600, hfg); cx += cw
    ry = y + 34
    for i, r in enumerate(rows):
        parts, hs = "", []
        for j, (val, (k, cw)) in enumerate(zip(r, cols)):
            p, hh = P(xs[j], ry + 25, val, size, cw - 16, lh, 600 if (j == 0 and bold0) else 400, INK if j == 0 else MUTED, bfill=INK)
            parts += p; hs.append(hh)
        rh = max(hs) + 18
        if zebra and i % 2:
            s += rect(x, ry, w, rh, "#FAF9F6")
        s += parts
        ry += rh
    return s, ry - y


def f0(v): return f"{v:,.0f}"


# 01 ---------------------------------------------------------------------------------------
def s01():
    b = rect(940, 0, 980, 1080, "#FAFAF8") + img(960, 40, 940, 866, "img/spin.jpg", fit="meet")
    b += T(1430, 960, "The simulated test bench: basket at 1,500 rpm, water held against the sleeve", 15, 400, FAINT, "middle")
    b += label(M, 120, "MPx · PD-298 · design review", 16, ORANGE)
    b += T(M, 250, "MPx Spin v1", 84, 600, INK, ls=-2.2)
    b += T(M, 316, "Spin the water through a filter sleeve, then read the sleeve", 31, 500, INK, ls=-0.3)
    p, h = P(M, 384, "Concept 04 developed from our centrifuge experiment. What it does, what the calibrated simulation shows, "
             "which of our 22 requirements it meets, and the **contradictions, trade-offs and failure modes** to take into TRIZ and FMEA.", 23, 760, 34, 400, MUTED, bfill=INK)
    b += p
    stats = [(f"{V1['lh']:.0f} L/h", "per 400 mL batch cycle, target 15*"), (f"{V1['cc'] * 100:.0f} %", "caught by count, 1–100 µm*"),
             (f"{V1['l15']:.0f} L", "per sleeve on tap water*"), (f"{RIG['slip'] * 100:.1f} %", "how fast the rig's water really turned")]
    for i, (v, k) in enumerate(stats):
        x, y = M + (i % 2) * 400, 620 + (i // 2) * 150
        b += line(x, y, x + 350, y, INK, 1.5)
        b += T(x, y + 62, v, 50, 600, RED if i == 3 else INK, ls=-1)
        b += T(x, y + 96, k, 19, 400, MUTED)
    b += T(M, 960, "* simulated: model calibrated on the team's 3-speed rig; vanes assumed to turn the water at 85 % of basket speed", 15, 400, FAINT)
    b += label(M, 1010, "Concept development · Oct 2026", 15, INK)
    add("01_title", "MPx Spin v1 — design review", b)


# 02 ---------------------------------------------------------------------------------------
def s02():
    b, _ = hdr(2, "Where this concept sits in the CED process",
               "Concept 04 was one of the three concepts we carried out of evaluation. The rig gave us real data, so this deck turns it into an embodiment we can **attack with TRIZ and FMEA**.")
    stages = [("Task clarification", "Lec 3–5", "Requirements list (22), SNPS, objective tree", "done"),
              ("Conceptual design", "Lec 6–8", "Concept 04: paper + mesh + centrifuge + carbon", "done"),
              ("Physical test", "Rig", "200 mL, motor off / 3,500 / ≈5,000 rpm, 3 trials each", "done"),
              ("Simulation", "Lec 9", "Model calibrated on the rig (this deck)", "done"),
              ("Embodiment", "Now", "Spin v1 layout, teardown, requirement check", "now"),
              ("TRIZ + FMEA", "Next", "Contradictions and failure modes set up on slides 17–18", "next"),
              ("Detail design", "Later", "After bench tests 1–8", "next")]
    n = len(stages); gap = 14; bw = (W - 2 * M - gap * (n - 1)) / n; y = 268; bh = 168
    for i, (t, l, d, st) in enumerate(stages):
        x = M + i * (bw + gap)
        fill, stroke, fg = (CARD, LINE, INK) if st in ("done", "half") else ((ORANGE, ORANGE, "#fff") if st == "now" else (BG, "#D3D1CA", MUTED))
        b += card(x, y, bw, bh, fill, stroke, 12)
        b += label(x + 18, y + 32, l, 13, "#fff" if st == "now" else (GREEN if st == "done" else (AMBER if st == "half" else FAINT)))
        if st in ("done", "half"):
            b += status_icon(x + bw - 26, y + 27, st, 8)
        p, h = P(x + 18, y + 66, t, 21, bw - 30, 26, 600, fg)
        b += p
        p2, _ = P(x + 18, y + 72 + h, d, 15, bw - 30, 20, 400, "#FFE9DF" if st == "now" else MUTED)
        b += p2
        if i < n - 1:
            b += T(x + bw + gap / 2, y + bh / 2 + 6, "›", 22, 600, FAINT, "middle")
    y = 470
    b += card(M, y, 1140, 520)
    b += label(M + 32, y + 44, "Embodiment design steps (lecture 2, slide 36) and where Spin v1 stands", 14, INK)
    rows = [("done", "Overall layout: arrangement, spatial compatibility", "Single dimension set (dims.mjs) drives the bench simulation and the teardown"),
            ("done", "Preliminary form design: shapes, materials, processes", "316L basket and mesh, 304 bowl and lid, cellulose sleeve, PC/ABS dry base"),
            ("half", "Apply all major criteria", "Flow, capture, sleeve life, stress by simulation; cost, noise, drop open"),
            ("half", "Develop with scale drawings and critical reviews", "Exploded + cutaway drawings; this deck is the critical review"),
            ("now", "Identify errors and disturbing factors", "TRIZ contradictions and 18 FMEA candidates, unrated (slides 17–18)"),
            ("next", "Optimise", "Speed, paper grade, vane design, after bench tests"),
            ("next", "Outcome: embodiment ready for detail design", "Not yet")]
    ty = y + 74
    for k, (st, step, ev) in enumerate(rows):
        if k:
            b += line(M + 32, ty - 8, M + 1108, ty - 8, "#EFEDE7")
        b += status_icon(M + 46, ty + 15, st)
        p, h1 = P(M + 70, ty + 22, step, 18, 470, 23, 600 if st == "now" else 500, INK)
        p2, h2 = P(M + 570, ty + 22, ev, 17, 540, 23, 400, MUTED)
        b += p + p2
        ty += max(h1, h2) + 16
    x = M + 1170; w = W - M - x
    b += card(x, y, w, 520, ORANGE_BG, "#F4C9B5")
    b += label(x + 32, y + 44, "Three things the rig taught us", 14, ORANGE)
    bl, _ = bullets(x + 32, y + 96, [
        f"**The water hardly spun.** Fitting the model to the three speeds says the water turned at **{RIG['slip'] * 100:.1f} %** of the motor: about 3 g, not 700 g.",
        f"**The paper was too coarse to count.** A 25 µm paper catches about **{RIG['cc'] * 100:.0f} %** of 1–100 µm particles by number.",
        f"**The 106 L/h is a drain rate,** not a flow. With pouring and stopping, the rig's cycle is about {RIG['cyc5000']:.0f} L/h.",
        "So Spin v1 adds **vanes**, a **< 2 µm cellulose sleeve** and a slower, controlled **1,500 rpm**."], 17, w - 64, 12)
    b += bl
    b += footer("Sources: CED lec02 sl. 36–37; MPx_01 (Concept 04 + experiment, pp. 75–79); model.mjs")
    add("02_ced_position", "Where Spin v1 sits in CED", b)


# 03 ---------------------------------------------------------------------------------------
def s03():
    b, _ = hdr(3, "What it does: from Concept 04 to Spin v1",
               "Pour a batch in, spin it, and the water is driven out through a filter sleeve. The microplastics stay on the sleeve, which then becomes the sample under the microscope.")
    y = 252; bot = 990
    iw = 560; ih = iw * 750 / 1334
    b += card(M, y, iw + 20, ih + 72)
    b += img(M + 10, y + 10, iw, ih, "img/concept04.jpg", fit="meet")
    b += T(M + 24, y + ih + 50, "Concept 04 as selected (MPx_01, p. 75)", 15, 500, MUTED)
    yy = y + ih + 96
    b += card(M, yy, iw + 20, bot - yy)
    b += label(M + 24, yy + 38, "What changed, and why", 13, INK)
    ch = [("≈5,000 rpm 775 motor", "1,500 rpm 24 V BLDC + 4 vanes", "water must turn with the basket"),
          ("25 µm paper", "< 2 µm cellulose sleeve", "25 µm catches 12 % by count"),
          ("plastic frame, base", "316L / 304 wet path", "no plastic shed into the water"),
          ("activated carbon tank", "optional carbon cup at the spout", "keep the filter step clean to sample"),
          ("open top", "lid + interlock switch", "no spin with the lid off")]
    ty = yy + 70
    for a, c, why in ch:
        b += T(M + 24, ty, a, 15, 400, MUTED) + T(M + 210, ty, "→", 15, 600, ORANGE) + T(M + 236, ty, c, 15, 600, INK)
        b += T(M + 236, ty + 21, why, 13.5, 400, FAINT)
        ty += 50
    x = M + iw + 50; w = 620
    steps = [("Pour", "Fill **400 mL** through the lid chute while the basket starts. The four vanes catch the water and bring it up to **85 %** of basket speed (assumed)."),
             ("Spin", "At **1,500 rpm** the water stands as a wall against the sleeve at about **55 g**. The wall pressure reaches **7 kPa**, four times the head of a full basket at rest."),
             ("Filter", "Water passes the **cellulose sleeve**, the **50 µm** 316L mesh and the **perforated cage**, is flung onto the bowl and leaves by the spout. 90 % is through in **28 s**."),
             ("Read the sleeve", "Lift the lid, the clamp ring and the vane insert; pull the sleeve. Stain with Nile red and view at **100–250×** (MP-250) with a phone.")]
    hs = [56 + plines(d, 18, w - 50, 400, 600) * 26 for _, d in steps]
    gap_ = (bot - y - 6 - sum(hs)) / (len(steps) - 0.6)
    yy = y + 6
    for i, (t, d) in enumerate(steps):
        b += num_badge(x + 18, yy + 16, i + 1, 18, INK, size=16)
        b += T(x + 50, yy + 23, t, 23, 600)
        p, h = P(x + 50, yy + 56, d, 18, w - 50, 26, 400, MUTED, bfill=INK)
        b += p
        if i < len(steps) - 1:
            b += line(x + 50, yy + hs[i] + gap_ / 2 - 10, x + w, yy + hs[i] + gap_ / 2 - 10, LINE)
        yy += hs[i] + gap_
    x2 = x + w + 30; w2 = W - M - x2
    spec = [("Size", "Ø170 × 346 mm; basket Ø60 × 180"),
            ("Batch", "400 mL; 8 batches for 3 L"),
            ("Flow", f"{V1['lh']:.0f} L/h per cycle (pour, spin, stop)"),
            ("Capture", f"{V1['cc'] * 100:.0f} % by count; {V1['b'][0] * 100:.0f} % at 1–2 µm"),
            ("Sleeve", f"{V1['l15']:.0f} L tap, {WAT['bore']['l15']:.0f} L borewell before < 15 L/h"),
            ("Drive", "24 V BLDC, 1,000–1,750 rpm band"),
            ("Wet path", "316L, 304, cellulose, silicone, FKM"),
            ("Cost", "Not costed yet")]
    rows, yy = "", y + 86
    for k, v in spec:
        rows += T(x2 + 28, yy, k, 16, 600, MUTED)
        p, h = P(x2 + 130, yy, v, 17, w2 - 156, 23)
        rows += p
        yy += h + 15
        rows += line(x2 + 28, yy - 8, x2 + w2 - 28, yy - 8, "#EFEDE7")
    ch_ = yy - y + 6
    b += card(x2, y, w2, ch_) + label(x2 + 28, y + 42, "Key numbers (simulated)", 13, INK) + rows
    sy = y + ch_ + 20
    b += card(x2, sy, w2, bot - sy, GREY_BG, GREY_BG)
    b += label(x2 + 28, sy + 40, "Against our SNPS", 13, INK)
    cols = [("Remove", "yes, < 2 µm sleeve", GREEN), ("Detect", "the sleeve is the sample", AMBER), ("Contain", "sleeve bagged whole", GREEN)]
    cw = (w2 - 56) / 3
    for i, (a_, c_, col) in enumerate(cols):
        b += T(x2 + 28 + i * cw, sy + 82, a_, 22, 600, col)
        p, _ = P(x2 + 28 + i * cw, sy + 110, c_, 15, cw - 12, 20, 400, MUTED)
        b += p
    b += footer("Concept 04 from MPx_01 p. 75; Spin v1 dimensions dims.mjs; numbers from model.mjs at 1,500 rpm, 25 °C, tap water")
    add("03_what_it_does", "What it does", b)


# 04 ---------------------------------------------------------------------------------------
def s04():
    b, _ = hdr(4, "How it works: cut open",
               "Everything wet is steel or cellulose; the motor and the board sit in a dry base under the bowl. A lip seal and the bowl floor keep them apart.")
    y = 250; h = 740
    iw = 700
    b += card(M, y, iw + 40, h)
    b += img(M + 20, y + 14, iw, h - 28, "img/spin-cutaway_c.jpg", fit="meet")
    x = M + iw + 70; w = W - M - x
    path = [("Lid chute", "batch in, Ø16 bore, funnel"), ("Vane insert", "4 radial vanes drag the water round"), ("Cellulose sleeve", "the filter and the sample, < 2 µm class"),
            ("50 µm 316L mesh", "supports the wet paper over the holes"), ("Perforated cage", "Ø2 holes at 40 % open, 0.6 mm 316L"), ("Bowl and spout", "304, splash skirt, out to a jug")]
    b += card(x, y, w, 400) + label(x + 28, y + 42, "Where the water goes", 13, INK)
    cw = (w - 56) / 3
    for i, (t, d) in enumerate(path):
        xx = x + 28 + (i % 3) * cw; yy = y + 90 + (i // 3) * 150
        b += num_badge(xx + 16, yy, i + 1, 16, BLUEW, size=15)
        if i % 3 < 2:
            b += T(xx + cw - 18, yy + 6, "→", 20, 600, FAINT, "middle")
        p, ph = P(xx, yy + 46, t, 19, cw - 30, 24, 600)
        b += p
        p, _ = P(xx, yy + 50 + ph, d, 15.5, cw - 30, 21, 400, MUTED)
        b += p
    yy = y + 420
    b += card(x, yy, w, h - 420)
    b += label(x + 28, yy + 42, "Why it filters faster when it spins", 13, INK)
    b += rect(x + 28, yy + 64, w - 56, 52, GREY_BG, 8)
    b += F(x + 46, yy + 98, "z(r) = z_{0} + ω^{2}r^{2} / 2g      p_{wall}(z) = ρ g (z_{R} − z)", 20, 500)
    p, _ = P(x + 28, yy + 156, "The spinning water takes a paraboloid shape. Where it meets the sleeve it stands much higher than the basket is tall, so the pressure across the paper "
             f"rises from **1.8 kPa** (still, full) to **{V1['pWall'] / 1000:.1f} kPa** at 1,500 rpm with vanes. Flow through the wet wall follows Darcy's law with the paper's permeance. "
             "Only the water's own speed counts: if it lags the basket, the head collapses.", 17, w - 56, 25, 400, MUTED, bfill=INK)
    b += p
    b += footer("Teardown drawing from dims.mjs (cutaway at 110°); illustrative concept, not for manufacture")
    add("04_how_it_works", "How it works", b)


# 05 ---------------------------------------------------------------------------------------
def s05():
    b, _ = hdr(5, "The experiment: centrifuge-assisted filtration",
               "Does spinning a cylindrical filter make water pass faster than gravity? 200 mL per trial, three trials at three conditions (MPx_01, pp. 76–79).")
    y = 250
    pw = 330; ph = pw * 934 / 700
    b += card(M, y, pw + 20, ph + 70) + img(M + 10, y + 10, pw, ph, "img/rigphoto.jpg", r=8)
    b += T(M + 22, y + ph + 48, "The rig: Ø50 × 150 mm cage, PWM board", 15, 500, MUTED)
    x = M + pw + 50; w = 900
    b += card(x, y, w, 330) + label(x + 28, y + 40, "Results, time for 200 mL to pass (s)", 13, INK)
    cols = [("Condition", 200), ("Trial 1", 100), ("Trial 2", 100), ("Trial 3", 100), ("Mean", 100), ("SD", 80), ("Apparent L/h", 160)]
    names = ["A · motor off", "B · 3,500 rpm", "C · ≈5,000 rpm"]
    rows = [[names[i], *[f"{t:.2f}" for t in e["t"]], f"**{e['mean']:.2f}**", f"{e['sd']:.2f}", f"{e['apparent']:.1f}"] for i, e in enumerate(EXP)]
    s, th = table(x + 16, y + 60, w - 32, cols, rows, 17, 22)
    b += s
    p, _ = P(x + 28, y + 60 + th + 40, "Spinning cut the time from 22.4 s to 6.8 s: **3.3×** the baseline. The team's notes: RPM was not verified, "
             "removal and water quality were not measured, loading and clogging not tested.", 16.5, w - 56, 23, 400, MUTED, bfill=INK)
    b += p
    y2 = y + 350
    b += card(x, y2, w, 990 - y2, ORANGE_BG, "#F4C9B5")
    b += label(x + 28, y2 + 40, "Reading the numbers again", 13, ORANGE)
    bl, _ = bullets(x + 28, y2 + 86, [
        "**106 L/h is how fast one batch drains,** not what a user gets. Add the pour and the stop and the rig's cycle is about **33 L/h**.",
        "**3.3× faster at 5,000 rpm is far too little.** If the water turned with the basket, the pressure at the wall would be about 60× the static head.",
        "**A 25 µm paper is a pre-filter** for microplastics. By count most particles are under 20 µm; it catches about 12 %.",
        "**SD at motor-off is 2.4 s** (11 %): the start and stop of the timing matters as much as the speed."], 16.5, w - 56, 10)
    b += bl
    x3 = x + w + 30; w3 = W - M - x3
    b += card(x3, y, w3, 990 - y) + label(x3 + 28, y + 40, "Method", 13, INK)
    meth = ["Add 200 mL to the filter cylinder", "Time until the water has passed and collected below", "Motor off, 3,500 rpm, ≈5,000 rpm (PWM)", "Three readings per condition", "Mean time and flow rate"]
    yy = y + 84
    for i, m_ in enumerate(meth):
        b += num_badge(x3 + 42, yy - 6, i + 1, 13, INK, size=13)
        p, h_ = P(x3 + 66, yy, m_, 16, w3 - 94, 22, 400, INK)
        b += p
        yy += h_ + 16
    b += line(x3 + 28, yy, x3 + w3 - 28, yy, LINE)
    p, _ = P(x3 + 28, yy + 34, "**Kit:** 12 V 775 motor (3,500–9,000 rpm rated), 50 µm steel mesh cylinder in a plastic frame, 25 µm paper lining, printed housing, PWM controller.", 15.5, w3 - 56, 22, 400, MUTED, bfill=INK)
    b += p
    b += footer("Data and photo: MPx_01, pp. 76–79. Apparent L/h = 200 mL ÷ mean time")
    add("05_experiment", "The experiment", b)


# 06 ---------------------------------------------------------------------------------------
def s06():
    b, _ = hdr(6, "Calibrating the model on the rig: the water hardly turned",
               "The model has two unknowns. The motor-off run fixes the paper's lumped permeance, the ≈5,000 rpm run fixes how fast the water turns. The 3,500 rpm run is then a check.")
    y = 250; w = 900; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Time for 90 % to pass vs basket speed, rig (200 mL, Ø50 × 150, 25 µm paper)", 19, 600)
    c = Chart(M + 10, y + 70, w - 30, 540, (0, 6000), (0, 26), pad=(80, 20, 30, 64))
    c.axes([0, 1000, 2000, 3000, 4000, 5000, 6000], [0, 5, 10, 15, 20, 25], "basket speed, rpm", "seconds", lambda v: f"{v:,}", lambda v: f"{v}")
    cu = D["curve"]
    c.path([(r, t) for r, t in zip(cu["rpm"], cu["rig"])], "#9C6B3A", 3)
    for e in EXP:
        xx = e["rpm"]
        c.parts.append(line(c.X(xx), c.Y(min(e["t"])), c.X(xx), c.Y(max(e["t"])), INK, 1.6))
        for t in e["t"]:
            c.parts.append(f'<circle cx="{c.X(xx):.1f}" cy="{c.Y(t):.1f}" r="3.5" fill="none" stroke="{INK}" stroke-width="1.4"/>')
        c.dot(xx, e["mean"], INK, 7)
        c.text(xx, e["mean"], f"{e['mean']:.2f} s", 15, 600, INK, "start", 14, -10)
    c.text(5000, 18, "fitted: slip", 15, 600, MUTED, "middle")
    c.text(3500, 18, "check", 15, 600, GREEN, "middle")
    c.text(0, 3, "fitted: permeance", 15, 600, MUTED, "start", 10)
    b += c.svg()
    p, _ = P(M + 30, y + 660, "Dots: the three trials and their mean. Line: the model with κ = 8.93 × 10⁻⁹ m and the water at 6.52 % of motor speed. "
             f"Model {EXP[0]['model']:.2f} / {EXP[1]['model']:.2f} / {EXP[2]['model']:.2f} s: it predicts **{EXP[1]['model']:.1f} s** at 3,500 rpm against **{EXP[1]['mean']:.2f} s** measured (+5 %).", 16, w - 60, 23, 400, MUTED, bfill=INK)
    b += p
    x = M + w + 30; ww = W - M - x
    cards_ = [("Water speed", f"{RIG['slip'] * 100:.1f} %", RED, f"of motor speed. At 5,000 rpm the water turned at about **326 rpm**: **{RIG['gw5000']:.0f} g** at the wall instead of about {round(RIG['g5000'], -2):.0f} g. A smooth basket and a 7 s run never let it catch up."),
              ("Lumped permeance", f"{KX:.1f}×", AMBER, "the Whatman Grade 4 datasheet value. Either the paper was not the only path (seam, ends, frame gaps) or it was not seated. **Bypass would let particles through.**"),
              ("What this changes", "vanes", ORANGE, "The design has to make the water turn. Spin v1 assumes four vanes reach 85 %; the model needs at least **55 %** to make 15 L/h at 1,500 rpm.")]
    yy = y
    for t, v, col, d in cards_:
        hh = 236
        b += card(x, yy, ww, hh) + label(x + 28, yy + 38, t, 13, INK) + T(x + 28, yy + 96, v, 44, 600, col, ls=-1)
        p, _ = P(x + 28, yy + 136, d, 16, ww - 56, 23, 400, MUTED, bfill=INK)
        b += p
        yy += hh + 16
    b += footer("Fit: fit.py / fit2.py (least squares on means). 90 % pass time used as the measured end point")
    add("06_calibration", "Calibration", b)


# 07 ---------------------------------------------------------------------------------------
def s07():
    b, _ = hdr(7, "The calculations behind the numbers",
               "Eight hand-checkable relations from model.mjs. Spin v1 values at 1,500 rpm, 400 mL, 25 °C, Grade 602 h class sleeve, tap water.")
    cards = [
        ("1  Wall pressure", "p_{wall} = ρ g z_{R} ,  z_{R} = z_{0} + ω^{2}R^{2}/2g",
         "solid-body rotation, water at 0.85 × 157 rad/s, R = 30 mm; 400 mL wall", f"{V1['pWall'] / 1000:.1f} kPa", "vs 1.8 kPa at rest: 4× the head."),
        ("2  Flow through the wall", "Q = K · 2πR · ρg (z_{R}h − h^{2}/2)",
         "Darcy through the wetted height h, base closed", f"{V1['Q0'] * 3.6e6:.0f} L/h", "at the start of the batch; falls as it drains."),
        ("3  Paper permeance", "K = V / (t_{H} A Δp) · μ_{20}/μ_{T}",
         "Herzberg: 100 mL, 10 cm², 10 cm head; 602 h: 750 s", f"{V1['K']:.2e}".replace("e-07", "×10⁻⁷") + " m/(s·Pa)", f"rig lumped: 1.0×10⁻⁵ (Grade 4 datasheet ×{KX:.1f})."),
        ("4  Batch cycle", "Q_{cycle} = 0.9V / (t_{pour} + t_{90} + t_{stop} + 5 s)",
         f"10 s + {V1['t90']:.1f} s + 3 s + 5 s for 360 mL", f"{V1['lh']:.0f} L/h", "the number to hold against 15 L/h."),
        ("5  Capture by count", "η(d) = 1 / (1 + (d_{50}/d)^{4}) ,  n ∝ d^{−2}",
         "98 % at the paper's rating; 1–100 µm particles", f"{V1['cc'] * 100:.0f} %", f"{V1['b'][0] * 100:.0f} % at 1–2 µm; Grade 4: {RIG['cc'] * 100:.0f} %."),
        ("6  Face velocity", "v_{face} / v_{test} = (Q / A_{wet}) / (100 mL / 10 cm² t_{H})",
         "how much faster than the rating test the paper works", f"{V1['fv']:.1f}×", "we allow ≤ 10× (assumption)."),
        ("7  Cake on the sleeve", "1/K = 1/K_{0} + μ α m / A ,  α = 10^{13} m/kg",
         "solids 0.5 mg/L tap, 2 borewell, 10 turbid", f"{V1['l15']:.0f} L", "tap, until the cycle drops below 15 L/h."),
        ("8  Basket stress", "σ = ρ_{s}(ωR)^{2} + pR / t(1−φ)",
         "316L, 0.6 mm wall, 40 % open; yield 170 MPa", f"{V1['hoop']:.2f} MPa", f"safety factor {V1['sf']:.0f}×; 5 g off-centre: {V1['unb5']:.1f} N."),
    ]
    cols, gap = 4, 22
    w = (W - 2 * M - gap * (cols - 1)) / cols; h = 360; y = 252
    for i, (t, f, sub, res, note) in enumerate(cards):
        x = M + (i % cols) * (w + gap); yy = y + (i // cols) * (h + gap)
        b += card(x, yy, w, h)
        b += T(x + 24, yy + 40, t, 18, 600)
        b += rect(x + 24, yy + 60, w - 48, 54, GREY_BG, 8)
        fs = 19
        while fw(f, fs, 500) > w - 72 and fs > 11:
            fs -= 0.5
        b += F(x + 36, yy + 94, f, fs, 500, INK)
        p, ph = P(x + 24, yy + 148, sub, 15.5, w - 48, 22, 400, MUTED)
        b += p
        rs = 36
        while tw(res, rs, 600) > w - 48:
            rs -= 1
        b += T(x + 24, yy + 148 + ph + 44, res, rs, 600, ORANGE, ls=-0.5)
        p, _ = P(x + 24, yy + 148 + ph + 76, note, 15.5, w - 48, 21, 400, MUTED)
        b += p
    b += footer("Inputs: dims.mjs, Whatman qualitative datasheet (ratings, Herzberg times), rig calibration; α and the 85 % vane slip are assumptions")
    add("07_calculations", "Calculations", b)


# 08 ---------------------------------------------------------------------------------------
def s08():
    b, _ = hdr(8, "The simulated test bench: four states",
               "An interactive bench driven by the same model: separatory funnel doses the batch, the spout pours through a carbon cup into a jug on a scale, a stopwatch times it, the sleeve goes under the microscope.")
    shots = [("rig", "A · The experiment, ≈5,000 rpm", "The rig as calibrated. The motor is at 5,000 rpm but the water turns at 326 rpm: it slumps in the basket and drains slowly."),
             ("spin", "B · Spin v1, 1,500 rpm", f"Vanes on. The water stands against the sleeve at {V1['g']:.0f} g and is through in about 28 s per 400 mL."),
             ("novane", "B · Spin v1 without vanes", "Same basket and sleeve, vanes removed: the water lags like the rig's and the fine paper passes only 1.2 L/h."),
             ("inspect", "C · Lift the sleeve", "Lid aside, basket out, sleeve flattened on the tray under the pocket microscope.")]
    gap = 24; w = (W - 2 * M - gap * 3) / 4; y = 250; ih = w * 1014 / 1100
    for i, (f, t, d) in enumerate(shots):
        x = M + i * (w + gap)
        b += img(x, y, w, ih, f"img/{f}.jpg", r=12, stroke=LINE)
        b += T(x, y + ih + 38, t, 19, 600, ORANGE if f == "spin" else INK)
        p, h = P(x, y + ih + 68, d, 16, w - 4, 23, 400, MUTED, bfill=INK)
        b += p
    yb = 915
    b += card(M, yb, W - 2 * M, 76, GREY_BG, GREY_BG)
    p, _ = P(M + 28, yb + 45, "**Open it:** Desktop › MPx › Centrifuge_v1 › figure › MPx_Spin_v1_TestBench.html. Sliders for speed, batch, temperature; paper grade, vanes, water and the experiment's three conditions.", 16, W - 2 * M - 56, 23, 400, MUTED, bfill=INK)
    b += p
    b += footer("Screenshots from the bench figure at 2× sim speed")
    add("08_sim_bench", "Simulated test bench", b)


# 09 ---------------------------------------------------------------------------------------
def s09():
    b, _ = hdr(9, "What the bench reads out",
               "Two live charts, the requirement checks for the current settings, and the microscope's view of the sleeve.")
    y = 250
    cw = 470; ch = cw * 714 / 890
    b += img(M, y, cw, ch, "img/spin_card0.jpg", r=10, stroke=LINE) + img(M + cw + 20, y, cw, ch, "img/spin_card1.jpg", r=10, stroke=LINE)
    sw = 2 * cw + 20; sh = sw * 499 / 1400
    b += img(M, y + ch + 20, sw, sh, "img/spin_card4.jpg", r=10, stroke=LINE)
    x = M + sw + 30; w = W - M - x; rh = w * 509 / 1400
    b += label(x, y + 4, "Spin v1, 1,500 rpm, vanes, Grade 602 h", 13, ORANGE)
    b += img(x, y + 18, w, rh, "img/spin_card3.jpg", r=8, stroke=LINE)
    b += label(x, y + 44 + rh, "The experiment's rig at ≈5,000 rpm", 13, INK)
    b += img(x, y + 58 + rh, w, rh, "img/rig_card3.jpg", r=8, stroke=LINE)
    yy = y + 76 + 2 * rh
    p, _ = P(x, yy + 20, "The rig passes flow, face velocity and stress, but fails capture, sleeve life, water speed, the wet-path rule and the interlock. "
             "Spin v1 passes all but the 1–2 µm band (89 %).", 16, w, 23, 400, MUTED, bfill=INK)
    b += p
    b += footer("Screenshots from MPx_Spin_v1_TestBench.html")
    add("09_sim_readouts", "Bench readouts", b)


# 10 ---------------------------------------------------------------------------------------
def s10():
    b, _ = hdr(10, "Result 1 · Vanes decide whether the concept works at all",
               f"With a fine sleeve, the head from a lagging water ring is far too low. Without vanes Spin v1 passes {D['v1nv']['lh']:.1f} L/h; with them, {V1['lh']:.0f} L/h.")
    y = 250; w = 1060; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Time for 90 % of the batch to pass vs basket speed (log)", 19, 600)
    c = Chart(M + 10, y + 70, w - 30, 560, (0, 6000), (math.log10(1), math.log10(3000)), pad=(80, 20, 30, 64))
    Yl = lambda v: c.Y(math.log10(v))
    for v in [1, 3, 10, 30, 100, 300, 1000, 3000]:
        c.parts.append(line(c.px0, Yl(v), c.px1, Yl(v), "#ECEAE4"))
        c.parts.append(T(c.px0 - 10, Yl(v) + 5, f"{v:,}", 14, 400, MUTED, "end"))
    for v in range(0, 6001, 1000):
        c.parts.append(line(c.X(v), c.py0, c.X(v), c.py0 + 5, FAINT)); c.parts.append(T(c.X(v), c.py0 + 24, f"{v:,}", 14, 400, MUTED, "middle"))
    c.parts.append(line(c.px0, c.py0, c.px1, c.py0, FAINT, 1.2))
    c.parts.append(T((c.px0 + c.px1) / 2, c.py0 + 50, "basket speed, rpm", 15, 500, MUTED, "middle"))
    cu = D["curve"]
    pl = lambda key: "M" + " L".join(f"{c.X(r):.1f} {Yl(max(1, min(3000, t))):.1f}" for r, t in zip(cu["rpm"], cu[key]) if t > 0)
    c.parts.append(f'<path d="{pl("v1nv")}" fill="none" stroke="{MUTED}" stroke-width="2.6" stroke-dasharray="8 6"/>')
    c.parts.append(f'<path d="{pl("rig")}" fill="none" stroke="#9C6B3A" stroke-width="2.6"/>')
    c.parts.append(f'<path d="{pl("v1")}" fill="none" stroke="{ORANGE}" stroke-width="3.4"/>')
    for e in EXP:
        c.parts.append(f'<circle cx="{c.X(e["rpm"]):.1f}" cy="{Yl(e["mean"]):.1f}" r="6.5" fill="{INK}" stroke="#fff" stroke-width="2"/>')
    c.parts.append(line(c.X(1500), c.py0, c.X(1500), c.py1, ORANGE, 1.3, "5 5"))
    c.parts.append(T(c.X(1500) + 8, Yl(V1["t90"]) - 12, f"{V1['t90']:.0f} s at 1,500 rpm", 15, 600, ORANGE))
    c.parts.append(T(c.X(2600), Yl(900), "Spin v1 without vanes (602 h)", 15, 600, MUTED))
    c.parts.append(T(c.X(3600), Yl(17), "rig model, 200 mL, Grade 4", 15, 600, "#9C6B3A"))
    c.parts.append(T(c.X(3300), Yl(2.2), "Spin v1 with vanes (602 h, 400 mL)", 15, 600, ORANGE))
    c.parts.append(T(c.X(5000) + 12, Yl(EXP[2]["mean"]) + 26, "measured", 14, 600, INK))
    b += c.svg()
    p, _ = P(M + 30, y + 680, "Spin v1 uses a paper 20× tighter than the rig's (Herzberg 750 s vs 37 s). Without vanes that paper would need minutes per batch at any speed.", 16, w - 60, 23, 400, MUTED)
    b += p
    x = M + w + 30; ww = W - M - x
    b += card(x, y, ww, 400) + label(x + 28, y + 40, "How much water speed is enough? (1,500 rpm)", 13, INK)
    cols = [("Water / basket", 150), ("Cycle L/h", 110), ("Face ×", 90), ("Sleeve L", 100)]
    rows = [[f"{s['sl'] * 100:.0f} %", f"{s['lh']:.1f}", f"{s['fv']:.1f}", f"{s['l15']:.0f}" if s['l15'] > 0 else "—"] for s in D["slipSens"]]
    s, th = table(x + 16, y + 60, ww - 32, cols, rows, 16, 21)
    b += s
    p, _ = P(x + 28, y + 60 + th + 30, "Below about **55 %** the cycle falls under 15 L/h. 6.5 % (the rig) gives about 1 L/h.", 15.5, ww - 56, 22, 400, MUTED, bfill=INK)
    b += p
    b += card(x, y + 420, ww, h - 420, ORANGE_BG, "#F4C9B5")
    b += label(x + 28, y + 460, "Why the water lags, and what vanes do", 13, ORANGE)
    bl, _ = bullets(x + 28, y + 504, ["A smooth wall only drags the water by viscosity; spin-up takes far longer than a 7–30 s batch.",
                                      "Radial vanes push the water round like paddles, so it reaches basket speed in about a revolution.",
                                      "The 85 % figure is an assumption: **bench test 1** measures it."], 16, ww - 56, 10)
    b += bl
    b += footer("model.mjs; vane slip varied by scaling the water speed at a fixed 1,500 rpm basket")
    add("10_result_vanes", "Result: vanes and water speed", b)


# 11 ---------------------------------------------------------------------------------------
def s11():
    b, _ = hdr(11, "Result 2 · Paper grade: catching small particles costs flow",
               "Four plain cellulose papers in the same Spin v1 at 1,500 rpm with vanes. Finer papers catch far more by count, but pass less water and clog sooner.")
    y = 250; w = 900; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Capture by count (1–100 µm) vs batch-cycle flow", 19, 600)
    c = Chart(M + 10, y + 70, w - 30, 560, (0, 75), (0, 100), pad=(80, 30, 30, 64))
    c.axes([0, 15, 30, 45, 60, 75], [0, 20, 40, 60, 80, 100], "flow per batch cycle, L/h", "% caught by count", str, lambda v: f"{v}")
    c.zone(15, 75, 90, 100, "#E5F1E9")
    c.parts.append(T(c.X(74), c.Y(92) + 4, "target zone: ≥ 15 L/h and ≥ 90 %", 14, 600, GREEN, "end"))
    c.vline(15, GREEN, "5 5"); c.hline(90, GREEN, "5 5")
    cols_ = {"G4": "#9C6B3A", "G1": MUTED, "P602": ORANGE, "G5": BLUE}
    for p_ in D["papers"]:
        c.dot(p_["lh"], p_["cc"] * 100, cols_[p_["k"]], 10)
        c.dot(p_["lhnv"], p_["cc"] * 100, cols_[p_["k"]], 6, False)
        c.parts.append(line(c.X(p_["lhnv"]), c.Y(p_["cc"] * 100), c.X(p_["lh"]), c.Y(p_["cc"] * 100), cols_[p_["k"]], 1.2, "3 4"))
        dy = -18 if p_["k"] != "G5" else 30
        c.text(p_["lh"], p_["cc"] * 100, f"{p_['name']} ({p_['short']})", 16, 600, cols_[p_["k"]], "middle", 0, dy)
    c.text(2, 4, "small dots: same paper without vanes", 14, 500, MUTED)
    b += c.svg()
    p, _ = P(M + 30, y + 680, "Grade 4 is the rig's paper. The < 2 µm Grade 602 h class is the only one inside the target zone; Grade 5 (2.5 µm) is tighter in Herzberg time but rated coarser, so it catches less and flows less.", 16, w - 60, 23, 400, MUTED)
    b += p
    x = M + w + 30; ww = W - M - x
    b += card(x, y, ww, 470) + label(x + 28, y + 40, "The four papers at 1,500 rpm with vanes", 13, INK)
    cols = [("Paper", 200), ("1–2 µm", 90), ("all", 80), ("L/h", 80), ("Face ×", 90), ("Sleeve L", 100)]
    rows = [[f"{p_['name']}", f"{p_['b'][0] * 100:.0f} %", f"{p_['cc'] * 100:.0f} %", f"{p_['lh']:.0f}", f"{p_['fv']:.1f}", f"{p_['l15']:.0f}"] for p_ in D["papers"]]
    s, th = table(x + 16, y + 60, ww - 32, cols, rows, 16.5, 22)
    b += s
    p, _ = P(x + 28, y + 60 + th + 32, "Face × is the same for all four: it is just the wall pressure divided by the rating test's 10 cm head, whatever the paper. "
             "Sleeve L is tap water until the cycle falls below 15 L/h.", 15.5, ww - 56, 22, 400, MUTED)
    b += p
    b += card(x, y + 490, ww, h - 490, ORANGE_BG, "#F4C9B5")
    b += label(x + 28, y + 530, "The contradiction to carry into TRIZ", 13, ORANGE)
    p, _ = P(x + 28, y + 574, f"Catching **1–2 µm** particles needs a tighter paper, which cuts flow and sleeve life. Spin v1 sits at **{V1['b'][0] * 100:.0f} %** in that band: "
             "just short of 90 %. Going tighter means going faster, a bigger sleeve or a two-stage sleeve.", 17, ww - 56, 25, 400, INK)
    b += p
    b += footer("Whatman qualitative papers: rating at 98 % retention, Herzberg time. Capture curve and count distribution (n ∝ d⁻²) are model assumptions")
    add("11_result_paper", "Result: paper grade", b)


# 12 ---------------------------------------------------------------------------------------
def s12():
    b, _ = hdr(12, f"Result 3 · The speed band: {D['bandLo']:,}–{D['bandHi']:,} rpm",
               "Faster means more flow and a longer-lasting sleeve, but the paper then works far above the velocity it was rated at, so its capture is no longer known.")
    y = 250; w = 1060; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Batch-cycle flow (left) and face velocity ÷ rating test (right) vs speed", 19, 600)
    c = Chart(M + 10, y + 70, w - 30, 560, (0, 4000), (0, 60), pad=(80, 80, 30, 64))
    c.zone(D["bandLo"], D["bandHi"], 0, 60, "#E5F1E9")
    c.axes([0, 1000, 2000, 3000, 4000], [0, 15, 30, 45, 60], "basket speed, rpm (Grade 602 h, vanes, 400 mL)", "L/h per batch cycle", lambda v: f"{v:,}", str)
    bd = D["band"]
    c.path([(r, v) for r, v in zip(bd["rpm"], bd["lh"])], INK, 3.2)
    fvmax = 40
    c.parts.append('<path d="M' + " L".join(f"{c.X(r):.1f} {c.Y(min(fvmax, f) * 60 / fvmax):.1f}" for r, f in zip(bd["rpm"], bd["fv"])) + f'" fill="none" stroke="{RED}" stroke-width="2.6" stroke-dasharray="7 5"/>')
    for v in [0, 10, 20, 30, 40]:
        c.parts.append(T(c.px1 + 10, c.Y(v * 60 / fvmax) + 5, f"{v}×", 14, 400, RED))
    c.hline(15, MUTED, "5 5", "15 L/h target", "left", 14, -8)
    c.parts.append(line(c.px0, c.Y(10 * 60 / fvmax), c.px1, c.Y(10 * 60 / fvmax), RED, 1, "2 4"))
    c.parts.append(T(c.px1 - 6, c.Y(10 * 60 / fvmax) - 8, "10× rating test", 14, 600, RED, "end"))
    c.dot(1500, V1["lh"], ORANGE, 8)
    c.text(1500, V1["lh"], f"Spin v1: {V1['lh']:.0f} L/h, {V1['fv']:.1f}×", 15, 600, ORANGE, "end", -14, -12)
    c.parts.append(T((c.X(D["bandLo"]) + c.X(D["bandHi"])) / 2, c.py1 + 20, "both hold", 15, 600, GREEN, "middle"))
    b += c.svg()
    p, _ = P(M + 30, y + 680, "Below 1,000 rpm the cycle drops under 15 L/h; above 1,750 rpm the paper works more than 10× faster than in its rating test. Black: flow. Red dashed: face velocity, right axis.", 16, w - 60, 23, 400, MUTED)
    b += p
    x = M + w + 30; ww = W - M - x
    b += card(x, y, ww, 420) + label(x + 28, y + 40, "Speed vs flow, sleeve life and stress", 13, INK)
    cols = [("rpm", 90), ("L/h", 80), ("Face ×", 90), ("Sleeve L", 100), ("In band", 110)]
    rows = [[f"{r['rpm']:,}", f"{r['lh']:.0f}", f"{r['fv']:.1f}", f"{r['l15']:.0f}" if r['l15'] > 0 else "—", "yes" if D['bandLo'] <= r['rpm'] <= D['bandHi'] else "no"] for r in D["l15rpm"]]
    s, th = table(x + 16, y + 60, ww - 32, cols, rows, 16, 21)
    b += s
    b += card(x, y + 440, ww, h - 440)
    b += label(x + 28, y + 480, "At 1,500 rpm the spinning parts are easy", 13, INK)
    bl, _ = bullets(x + 28, y + 524, [f"Basket hoop stress **{V1['hoop']:.2f} MPa**: safety factor **{V1['sf']:.0f}×** on 316L.",
                                      f"Water at **{V1['g']:.0f} g**, basket rim at {V1['gb']:.0f} g.",
                                      f"Unbalance: 1 g off-centre → **{V1['unb1']:.2f} N**, 5 g → **{V1['unb5']:.1f} N**. An uneven wet sleeve is the real vibration source."], 16, ww - 56, 10)
    b += bl
    b += footer("model.mjs; the 10× face-velocity limit is our assumption until bench test 5 measures capture at speed")
    add("12_result_speed", "Result: speed band", b)


# 13 ---------------------------------------------------------------------------------------
def s13():
    b, _ = hdr(13, "Result 4 · Dirty water, light plastics and a sparse sample",
               "Three effects that the flow numbers alone hide. Each one is a trade-off or a failure mode to carry forward.")
    y = 250; h = 740; w = (W - 2 * M - 60) / 3
    # sleeve life by water
    x = M
    b += card(x, y, w, h) + label(x + 28, y + 40, "Litres per sleeve before the cycle < 15 L/h", 13, INK)
    c = Chart(x + 10, y + 60, w - 20, 380, (0, 3), (0, 120), pad=(70, 20, 20, 50))
    c.axes([], [0, 20, 40, 60, 80, 100, 120], "", "litres", str, str)
    c.hline(20, AMBER, "5 5", "20 L: enough to count", "right", 13, -8)
    c.hline(100, RED, "5 5", "100 L target (9.1)", "right", 13, -8)
    for i, k in enumerate(["tap", "bore", "turbid"]):
        v = WAT[k]["l15"]; bx = c.X(i + 0.5)
        c.parts.append(rect(bx - 45, c.Y(v), 90, c.Y(0) - c.Y(v), [GREEN, AMBER, RED][i], 4))
        c.parts.append(T(bx, c.Y(v) - 10, f"{v:.0f} L" if v >= 10 else f"{v:.1f} L", 18, 600, INK, "middle"))
        c.parts.append(T(bx, c.py0 + 24, WAT[k]["label"], 15, 500, MUTED, "middle"))
        c.parts.append(T(bx, c.py0 + 44, f"{WAT[k]['c'] * 1000:.1f} mg/L", 13, 400, FAINT, "middle"))
    b += c.svg()
    p, _ = P(x + 28, y + 500, "The cake of silt on the sleeve, not the microplastics, ends its life. Tap water lasts 71 L; borewell water 18 L; turbid surface water about 4 L. "
             "**Silt resistance α = 10¹³ m/kg is assumed** (bench test 4).", 16, w - 56, 23, 400, MUTED, bfill=INK)
    b += p
    # drift
    x = M + w + 30
    b += card(x, y, w, h) + label(x + 28, y + 40, "Radial drift in the spinning water, 1,500 rpm", 13, INK)
    cols = [("Polymer", 100), ("ρ kg/m³", 100), ("10 µm", 100), ("50 µm", 100)]
    rows = [[d["n"], f"{d['rho']:,}", f"{d['v10'] * 1000:+.2f}", f"{d['v50'] * 1000:+.1f}"] for d in D["drift"]]
    s, th = table(x + 16, y + 60, w - 32, cols, rows, 16, 21)
    b += s
    p, _ = P(x + 28, y + 60 + th + 30, f"mm/s, + outward. The water itself moves outward through the sleeve at about **{D['throughV'] * 1000:.2f} mm/s**. "
             "PP above about **19 µm** and PE above about **24 µm** drift inward faster than that: they ride the inner surface and only reach the sleeve as the last water drains, "
             "near its top or on the floor. Dense PET and PVC are thrown onto the paper.", 16, w - 56, 23, 400, MUTED, bfill=INK)
    b += p
    # sample
    x = M + 2 * (w + 30)
    b += card(x, y, w, h) + label(x + 28, y + 40, "Reading the sleeve", 13, INK)
    d_ = 300
    b += img(x + (w - d_) / 2, y + 64, d_, d_, "img/scope.jpg")
    b += T(x + w / 2, y + 64 + d_ + 26, "MP-250 at 250×, 0.8 mm field, Nile red (simulated)", 14, 500, FAINT, "middle")
    yy = y + 64 + d_ + 40
    bl, _ = bullets(x + 28, yy + 30, ["The sleeve is 188 × 180 mm: about 67,000 microscope fields. One 400 mL batch at an assumed 1,000 particles per litre leaves about **0.005 per field**.",
                                      "About **20 L** on one sleeve gives ≈ 0.3 per field; or cut and count a small disc, or use a smaller sample sleeve.",
                                      "Cellulose takes up Nile red: a **blank sleeve** is needed as background, and cellulose fibres must not be counted as plastic."], 16, w - 56, 10)
    b += bl
    b += footer("Drift: Stokes in a centrifugal field, v = Δρ d² ω² r / 18μ at r = 25 mm. Microscope: Carson MP-250, 250×, 0.8 mm field")
    add("13_result_sleeve", "Result: sleeve life, drift, sample", b)


# 14 ---------------------------------------------------------------------------------------
def s14():
    b, _ = hdr(14, "How it goes together",
               "Fifteen parts. The motor and board leave the base from below; the rotor parts lift out of the bowl. The filter stack is mesh outside the cage, sleeve inside, vanes inside the sleeve.")
    y = 246; iw = 1180; ih = iw * 1190 / 1667
    b += card(M, y, iw + 20, 744) + img(M + 10, y + 10, iw, 724, "img/spin-exploded_c.jpg", fit="meet")
    x = M + iw + 50; w = W - M - x
    parts = [("Lid with fill chute", "304, glass window, interlock tab"), ("Collection bowl with spout", "304 deep-drawn, splash skirt, boss"),
             ("Sleeve clamp ring + O-ring", "316 + silicone, seals the sleeve top"), ("Vane insert", "4 vanes on two hub rings, 316"),
             ("Filter sleeve", "cellulose, < 2 µm class, 190 × 180 mm"), ("Mesh wrap", "50 µm woven 316L, on the cage"),
             ("Basket cage", "0.6 mm 316L, Ø2 holes at 40 % open"), ("Drive coupler + lip seal", "316 + FKM"),
             ("Lid interlock switch", "on the base deck"), ("Base housing + feet", "PC/ABS, dry side; knob, LED, switch"),
             ("Motor with mount plate", "24 V BLDC"), ("Controller PCB", "BLDC driver, speed set point")]
    b += card(x, y, w, 744) + label(x + 28, y + 40, "Parts and materials", 13, INK)
    yy = y + 82
    for t, d in parts:
        b += T(x + 28, yy, t, 16.5, 600) + T(x + 28, yy + 22, d, 14.5, 400, MUTED)
        yy += 53
    b += footer("Teardown drawing from dims.mjs; illustrative concept, not for manufacture. Full drawing: figure › MPx_Spin_v1_Teardown.html")
    add("14_teardown", "Teardown", b)


# 15 ---------------------------------------------------------------------------------------
REQ = [
    (1, "6.1", "Removal ≥ 90 % by count, 1 µm–5 mm (stretch 99 %)", f"{V1['cc'] * 100:.0f} % (1–100 µm); {V1['b'][0] * 100:.0f} % at 1–2 µm; capture at {V1['fv']:.0f}× face velocity unverified", "Sim", "partial"),
    (2, "3.2", "Filter medium sheds no secondary micro/nanoplastic", "Steel wet path, no plastic; the cellulose sleeve may shed fibres", "Design", "design"),
    (3, "6.2", "Detection false +/− ≤ 10 % vs reference microscopy", "Sleeve is the sample; Nile red stains cellulose; very sparse fields", "—", "risk"),
    (4, "10.2", "Captured microplastics stay contained", "Caught on the sleeve, which lifts out whole and is bagged", "Design", "design"),
    (5, "4.1", "Result through ≥ 1 user feedback channel", "Microscope view of the sleeve with a phone; nothing on the device", "Design", "partial"),
    (6, "11.1", "Retail price ₹1,500–6,000", "Not costed; 316L basket, 304 bowl and a BLDC drive lead the cost", "—", "risk"),
    (7, "3.1", "Water-contact parts food-contact safe", "316L, 304, cellulose, silicone, FKM", "Spec", "design"),
    (7, "3.4", "No leachables above IS 10500", "Stainless and cellulose; not tested", "Spec", "design"),
    (9, "2.1", "Flow rate ≥ 15 L/h", f"{V1['lh']:.0f} L/h per cycle at 1,500 rpm with vanes; {D['v1nv']['lh']:.1f} L/h without", "Sim", "pass"),
    (9, "1.1", "Per-use capacity for 1–3 L/day", "3 L = 8 batches of 400 mL, about 6 min", "Sim", "pass"),
    (9, "10.1", "Disposal pathway for spent filters (W)", "Sleeve and catch bagged; no defined route yet", "—", "open"),
    (9, "1.2", "Non-destructive sampling (W)", "The sleeve itself is the sample", "Design", "met"),
    (9, "5.3", "Display legible outdoors (W)", "Status LED only", "Design", "partial"),
    (14, "9.1", "Filter rated ≥ 100 L or 3 months", f"{V1['l15']:.0f} L tap, {WAT['bore']['l15']:.0f} L borewell, {WAT['turbid']['l15']:.0f} L turbid", "Sim", "partial"),
    (14, "7.1", "Filter swap tool-free in ≤ 30 s", "Lid, clamp ring, vane insert, sleeve: four steps; not timed", "Design", "risk"),
    (14, "4.2", "Alert near filter end-of-life", "Possible from the batch drain time; not designed", "—", "open"),
    (14, "5.2", "Spout parts detachable and washable", "Fixed spout on a lift-out bowl", "Design", "partial"),
    (14, "8.2", "Usable at 5–45 °C", f"{D['temp'][0]['lh']:.0f}–{D['temp'][-1]['lh']:.0f} L/h from 5 to 45 °C (viscosity)", "Sim", "pass"),
    (19, "3.3", "Housing UV and impact resistant (W)", "Steel bowl and lid; PC/ABS base", "Design", "design"),
    (19, "3.5", "Survives 1 m drop (W)", f"Basket stress SF {V1['sf']:.0f}× at speed; drop not tested", "—", "open"),
    (21, "5.1", "Actuation force ≤ 50 N (W)", "Knob and button", "Design", "met"),
    (21, "8.1", "Noise ≤ 60 dB(A) (W)", "1,500 rpm BLDC plus sleeve unbalance; not measured", "—", "open"),
]


def s15():
    b, _ = hdr(15, "Our 22 technical requirements: what Spin v1 meets and what it doesn't",
               "Ranked by our weighted objective tree. **Pass · sim**: shown by the calibrated simulation. **By design**: should meet it, not yet tested.")
    y = 238; cnt = {}
    for r in REQ:
        cnt[r[5]] = cnt.get(r[5], 0) + 1
    xx = M
    for k in ["pass", "met", "design", "partial", "fail", "risk", "open", "na"]:
        if not cnt.get(k):
            continue
        t, fg, bg = STATUS[k]
        cs, cw = chip(xx, y, f"{t}  {cnt.get(k, 0)}", fg, bg, 15, 32)
        b += cs
        xx += cw + 10
    cols = [("Rank", 70), ("#", 64), ("Requirement", 560), ("Spin v1 result", 660), ("Checked by", 140), ("Status", 266)]
    ty = 270
    b += rect(M, ty, W - 2 * M, 36, GREY_BG, 6)
    cx = M + 14; xs = []
    for k, cw in cols:
        xs.append(cx); b += T(cx, ty + 24, k, 14, 600, MUTED); cx += cw
    rh = 29.4
    for i, (rank, num, req, res, how, st) in enumerate(REQ):
        ry = ty + 36 + i * rh
        if i % 2:
            b += rect(M, ry, W - 2 * M, rh, "#FAF9F6")
        base = ry + rh / 2 + 6
        b += T(xs[0], base, str(rank), 16, 500, MUTED) + T(xs[1], base, num, 16, 600, INK) + T(xs[2], base, req, 16, 500, INK)
        fz = 16
        while tw(res, fz) > cols[3][1] - 16:
            fz -= 0.5
        b += T(xs[3], base, res, fz, 400, MUTED) + T(xs[4], base, how, 15, 400, MUTED)
        t, fg, bg = STATUS[st]
        cs, _ = chip(xs[5], ry + rh / 2, t, fg, bg, 13, 22)
        b += cs
        if rank in (5, 9, 19) and (i == 0 or REQ[i - 1][0] != rank):
            b += line(M, ry, W - M, ry, "#CFCDC6", 1.2)
    yb = ty + 36 + len(REQ) * rh + 16
    p, _ = P(M, yb + 14, "Flow (2.1), capacity (1.1) and temperature (8.2) pass in simulation, and removal (6.1) is close: the Tier 1 risks are now detection (6.2), price (11.1) and sleeve life on dirty water (9.1).", 17, W - 2 * M, 24, 400, MUTED, bfill=INK)
    b += p
    b += footer("Requirements: MPx_Weighted_Objective_Tree.docx (22 items, D/W). W = wish. No requirement fails outright; four are at risk")
    add("15_requirements", "Requirements met and not met", b)


# 16 ---------------------------------------------------------------------------------------
def s16():
    b, _ = hdr(16, "What the simulation validates, and what it can't",
               "The model reproduces our rig within 5 % and gives the flow and stress side with some confidence. Capture, slip with vanes, cake and detection are assumptions until measured.")
    y = 250; lw = 820
    b += card(M, y, lw, 740)
    b += label(M + 28, y + 40, "Checks, Spin v1 at 1,500 rpm", 13, INK)
    checks = [("pass", "Rig prediction at 3,500 rpm", f"{EXP[1]['model']:.1f} s vs {EXP[1]['mean']:.2f} s measured"),
              ("pass", "Flow per batch cycle", f"{V1['lh']:.0f} L/h ≥ 15"), ("pass", "Capture by count", f"{V1['cc'] * 100:.0f} % ≥ 90"),
              ("fail", "Capture at 1–2 µm", f"{V1['b'][0] * 100:.0f} % < 90"), ("pass", "Face velocity", f"{V1['fv']:.1f}× ≤ 10×"),
              ("pass", "Sleeve life, tap water", f"{V1['l15']:.0f} L ≥ 20"), ("fail", "Sleeve life, borewell / turbid", f"{WAT['bore']['l15']:.0f} L / {WAT['turbid']['l15']:.0f} L"),
              ("pass", "Basket stress", f"SF {V1['sf']:.0f}×"), ("pass", "Usable at 5 °C", f"{D['temp'][0]['lh']:.0f} L/h"),
              ("fail", "Without vanes", f"{D['v1nv']['lh']:.1f} L/h"), ("fail", "Sleeve 100 L (9.1)", f"{V1['l15']:.0f} L tap")]
    ty = y + 66
    b += rect(M + 16, ty, lw - 32, 34, GREY_BG, 6)
    b += T(M + 28, ty + 23, "Check", 14, 600, MUTED) + T(M + 400, ty + 23, "Result", 14, 600, MUTED) + T(M + lw - 130, ty + 23, "Status", 14, 600, MUTED)
    for i, (st, k, v) in enumerate(checks):
        ry = ty + 34 + i * 46
        if i % 2:
            b += rect(M + 16, ry, lw - 32, 46, "#FAF9F6")
        b += T(M + 28, ry + 29, k, 16, 500, INK) + T(M + 400, ry + 29, v, 16, 400, MUTED)
        t, fg, bg = STATUS[st]
        cs, _ = chip(M + lw - 130, ry + 23, "pass" if st == "pass" else "fail", fg, bg, 13, 24)
        b += cs
    x = M + lw + 30; w = W - M - x
    b += card(x, y, w, 740)
    b += label(x + 28, y + 40, "Assumptions to replace with measurements", 13, INK)
    cols = [("Assumption", 260), ("Value used", 180), ("Drives", 140), ("Bench test", 250)]
    rows = [("Water speed with 4 vanes", "85 % of basket", "Flow (2.1)", "1 · strobe or tracer on the water, rig with retrofit vanes"),
            ("Paper is the only path", "lumped K fitted", "Capture (6.1)", "2 · dye through the seam and ends; K vs datasheet"),
            ("Capture holds at 7× face velocity", "rating curve", "Capture (6.1)", "5 · spiked 1, 2, 5, 10 µm beads at 0 and 1,500 rpm"),
            ("Cake resistance of silt", "α = 10¹³ m/kg", "Life (9.1)", "4 · flow vs litres on borewell water"),
            ("Particle sizes by count", "n ∝ d⁻², 1–100 µm", "Capture (6.1)", "count real tap samples by size"),
            ("Nile red on cellulose", "blank subtracts", "Detection (6.2)", "6 · stained blank sleeve under the MP-250"),
            ("Sleeve stays sealed and whole", "no tears", "Capture (6.1)", "7 · 20 batches, inspect, re-test bypass")]
    cx = x + 28; xs = []
    for k, cw in cols:
        xs.append(cx); cx += cw
    ty = y + 66
    b += rect(x + 16, ty, w - 32, 34, GREY_BG, 6)
    for (k, _), xx in zip(cols, xs):
        b += T(xx, ty + 23, k, 14, 600, MUTED)
    ry = ty + 34
    for i, r in enumerate(rows):
        parts, hs = "", []
        for j, (val, (k, cw)) in enumerate(zip(r, cols)):
            p, hh = P(xs[j], ry + 26, val, 15, cw - 16, 20, 600 if j == 0 else 400, INK if j in (0, 3) else MUTED)
            parts += p; hs.append(hh)
        rh = max(hs) + 18
        if i % 2:
            b += rect(x + 16, ry, w - 32, rh, "#FAF9F6")
        b += parts
        ry += rh
    b += rect(x + 16, y + 740 - 132, w - 32, 116, ORANGE_BG, 10)
    b += label(x + 40, y + 740 - 96, "CED lecture 9: three kinds of simulation", 13, ORANGE)
    b += status_icon(x + 52, y + 740 - 52, "done") + T(x + 72, y + 740 - 46, "Analytical (slide 7)", 17, 600)
    b += status_icon(x + 282, y + 740 - 52, "done") + T(x + 302, y + 740 - 46, "Virtual (slides 8–9)", 17, 600)
    b += status_icon(x + 512, y + 740 - 52, "half") + T(x + 532, y + 740 - 46, "Physical: rig done (flow), tests 1–8 next", 17, 600)
    b += footer("model.mjs calibrated with fit.py / fit2.py on the MPx_01 rig data")
    add("16_validated_vs_not", "What the simulation validates", b)


# 17 ---------------------------------------------------------------------------------------
def s17():
    b, _ = hdr(17, "Ready for TRIZ: contradictions and trade-offs",
               "Each one comes from a number in this deck. The 39-parameter pairs are our first suggestion for the contradiction matrix; the principles are left for the session.")
    y = 246
    tcs = [("TC1", "Capture vs flow", "A tighter sleeve catches 1–2 µm particles but cuts flow and sleeve life.", "602 h: 89 % / 28 L/h / 71 L · G5: 78 % / 18 L/h / 27 L", "#23 Loss of substance ↔ #39 Productivity"),
           ("TC2", "Speed vs capture certainty", "Faster spin raises flow and sleeve life but drives the paper far above its rated velocity, and adds noise and unbalance.", "1,500 rpm: 7.2× · 2,000: 12.9× · 2,500: 20×", "#39 Productivity ↔ #27 Reliability (#31 harmful side effects)"),
           ("TC3", "Water speed vs simplicity", "The water must turn with the basket, but vanes add a part to remove at every sleeve change and to clean.", "no vanes 1.2 L/h · vanes 28 L/h", "#9 Speed ↔ #33 Ease of operation (#36 Complexity)"),
           ("TC4", "Sample size vs sleeve life", "Counting needs ≈ 20 L on one sleeve, but silt on the same sleeve shuts the flow first in dirty water.", "borewell 18 L · turbid 4 L", "#26 Quantity of substance ↔ #39 Productivity"),
           ("TC5", "Filter area vs size and mass", "A bigger basket passes more water per batch but makes a bigger, heavier, costlier rotor.", "Ø60 × 180 mm, 400 mL", "#5 Area of moving object ↔ #1 Weight of moving object"),
           ("TC6", "All-steel wet path vs price", "No plastic in the water path means deep-drawn and perforated stainless parts.", "target ₹1,500–6,000", "#31 Harmful side effects ↔ #32 Ease of manufacture")]
    w = 1190
    b += card(M, y, w, 744) + label(M + 28, y + 38, "Technical contradictions (improve A, B gets worse)", 13, INK)
    cols = [("", 60), ("Contradiction", 300), ("Evidence", 340), ("Suggested parameters", 300), ("Principles", 130)]
    cx = M + 28; xs = []
    for k, cw in cols:
        xs.append(cx); cx += cw
    ty = y + 58
    b += rect(M + 16, ty, w - 32, 32, GREY_BG, 6)
    for (k, _), xx in zip(cols, xs):
        b += T(xx, ty + 22, k, 14, 600, MUTED)
    ry = ty + 32
    for i, (id_, t, d, ev, par) in enumerate(tcs):
        p1, h1 = P(xs[1], ry + 50, d, 14.5, cols[1][1] - 16, 19, 400, MUTED)
        p2, h2 = P(xs[2], ry + 26, ev, 15, cols[2][1] - 16, 20, 500, INK)
        p3, h3 = P(xs[3], ry + 26, par, 15, cols[3][1] - 16, 20, 400, BLUE)
        rh = max(h1 + 26, h2, h3) + 26
        if i % 2:
            b += rect(M + 16, ry, w - 32, rh, "#FAF9F6")
        b += T(xs[0], ry + 27, id_, 15, 700, ORANGE) + T(xs[1], ry + 27, t, 16, 600) + p1 + p2 + p3
        b += rect(xs[4], ry + 10, 104, 26, "#fff", 6, f' stroke="{LINE}" stroke-dasharray="4 3"') + T(xs[4] + 52, ry + 28, "to do", 13, 500, FAINT, "middle")
        ry += rh
    x = M + w + 30; ww = W - M - x
    pcs = [("PC1", "The sleeve's pores must be small (catch 1 µm) and large (pass 15 L/h).", "Space: coarse-to-fine layers; time: pre-filter, then sample sleeve"),
           ("PC2", "The basket must spin fast (head, flow) and slowly (paper rating, noise).", "Time: fast start, slow finish; condition: speed set by drain time"),
           ("PC3", "Particles must reach the paper (capture) and float inward (PP, PE > 20 µm).", "Condition: by density; place sampling where light ones land"),
           ("PC4", "The sleeve must be fixed (seal, no bypass) and removable (sample, swap).", "Time: clamp only while spinning; system: sleeve in its own cartridge")]
    b += card(x, y, ww, 470) + label(x + 28, y + 38, "Physical contradictions", 13, INK)
    yy = y + 80
    for id_, t, sep in pcs:
        b += T(x + 28, yy, id_, 15, 700, ORANGE)
        p, h1 = P(x + 80, yy, t, 15.5, ww - 108, 21, 600, INK)
        p2, h2 = P(x + 80, yy + h1 + 4, "Separation idea: " + sep, 14.5, ww - 108, 20, 400, MUTED)
        b += p + p2
        yy += h1 + h2 + 22
    b += card(x, y + 490, ww, 254, ORANGE_BG, "#F4C9B5") + label(x + 28, y + 528, "Trade-offs to fix with numbers", 13, ORANGE)
    bl, _ = bullets(x + 28, y + 570, ["**Speed:** 1,000–1,750 rpm; choose with bench test 5.", "**Paper:** < 2 µm class; or two layers.", "**Batch:** 400 mL vs basket size and fill time.", "**Water:** tap vs borewell sleeve life."], 15.5, ww - 56, 6)
    b += bl
    b += footer("Parameters from Altshuller's 39 (suggested; check in the session). Separation principles: space, time, condition, system")
    add("17_triz", "TRIZ inventory", b)


# 18 ---------------------------------------------------------------------------------------
FMEA = [
    ("Sleeve seam and ends", "Water bypasses the paper", "Unfiltered particles reach the jug", "Seam or ends unsealed at ring and floor", f"Rig permeance {KX:.1f}× the datasheet", "6.1"),
    ("Wet sleeve", "Tears or creases at 55 g", "Bypass; fibres in the water", "Wet strength over Ø2 holes, mesh not tight", "Not tested", "6.1"),
    ("Vanes", "Water lags (< 55 % of basket)", "Flow under 15 L/h", "Too few or short vanes, short spin", "Rig: 6.5 % without vanes", "2.1"),
    ("Sleeve paper", "Capture falls at high face velocity", "1–2 µm particles pass", "Rated at 1/7 of the working velocity", "Model assumption", "6.1"),
    ("Sleeve paper", "Blinds with silt", "Flow < 15 L/h early", "Borewell / turbid water", "18 L / 4 L simulated", "9.1"),
    ("Detection", "Cellulose fibres or stain read as plastic", "False positives", "Nile red uptake by cellulose", "Bench note", "6.2"),
    ("Detection", "Too few particles per field", "Count meaningless", "Sparse sample on a large sleeve", "≈ 0.005 per field per batch", "6.2"),
    ("Light polymers", "PP / PE miss the paper or land unevenly", "Sample under-counts them", "Inward drift > through-flow above ≈ 20 µm", "Stokes drift, slide 13", "1.2"),
    ("Basket", "Unbalance from an uneven wet sleeve", "Vibration, noise, walking", "Cake or water uneven, sleeve off-centre", "5 g → 3.7 N", "8.1"),
    ("Lid interlock", "Lid opened while spinning", "Contact with the basket; spray", "Switch fails or is bypassed", "Design only", "safety"),
    ("Lip seal", "Leaks into the dry base", "Water on the motor and board", "Wear at 1,500 rpm, dry running", "Design only", "3.5"),
    ("Bowl", "Spray over the rim", "Wet bench; lost water", "Water leaves the cage at ≈ 4 m/s", "Skirt sized, untested", "—"),
    ("Motor / driver", "Stalls or overheats with a full basket", "No flow", "Start-up torque, no current limit", "Design only", "2.1"),
    ("Speed control", "Speed drifts out of the band", "Low flow or uncertain capture", "No speed feedback (rig had none)", "Team note, slide 5", "2.1"),
    ("Sleeve change", "Sample touched or dropped", "Contaminated sample; spilled catch", "Four-step removal, wet hands", "Not timed", "10.2"),
    ("Spent sleeve", "Binned or rinsed", "Microplastics back to the environment", "No disposal route", "—", "10.1"),
    ("Cellulose sleeve", "Sheds fibres into the water", "Particles in the output", "Paper abrasion against the mesh", "Not tested", "3.2"),
    ("Cost", "Steel parts push the price over ₹6,000", "Not affordable", "Deep-drawn 304, perforated 316L, BLDC", "Not costed", "11.1"),
]


def s18():
    b, _ = hdr(18, f"Ready for FMEA: {len(FMEA)} failure-mode candidates",
               "Pahl & Beitz §10.4. Failure, effect and cause from this deck's numbers; occurrence, severity and detection are left blank for the team to rate (RN = O × S × D, > 125 critical).")
    cols = [("#", 40), ("Part / function", 200), ("Failure mode", 290), ("Effect on user", 280), ("Cause", 330), ("Evidence", 270), ("O", 46), ("S", 46), ("D", 46), ("Req.", 70)]
    x = M; xs = []
    for k, cw in cols:
        xs.append(x); x += cw
    ty = 240
    b += rect(M - 8, ty, W - 2 * M + 16, 36, INK, 6)
    for (k, cw), xx in zip(cols, xs):
        anc = "middle" if k in ("O", "S", "D") else "start"
        b += T(xx + (cw / 2 if anc == "middle" else 6), ty + 24, k, 14, 600, "#fff", anc)
    ry = ty + 36; rh = 39.5
    for i, r in enumerate(FMEA):
        if i % 2:
            b += rect(M - 8, ry, W - 2 * M + 16, rh, "#FAF9F6")
        base = ry + rh / 2 + 5.5
        b += T(xs[0] + 6, base, str(i + 1), 15, 600, MUTED)
        for j, t in enumerate(r[:5]):
            k, cw = cols[j + 1]
            fz = 15
            while tw(t, fz, 600 if j == 0 else 400) > cw - 14 and fz > 11:
                fz -= 0.5
            b += T(xs[j + 1] + 6, base, t, fz, 600 if j == 0 else 400, INK if j < 2 else MUTED)
        for j in (6, 7, 8):
            b += rect(xs[j] + 8, ry + 7, 30, rh - 14, "#fff", 5, f' stroke="{LINE}"')
        b += T(xs[9] + 6, base, r[5], 14, 600, MUTED)
        ry += rh
    b += footer("Draft candidates for the team's FMEA session; ratings deliberately left blank")
    add("18_fmea_candidates", "FMEA candidates", b)


# 19 ---------------------------------------------------------------------------------------
def s19():
    b, _ = hdr(19, "Next steps: measure the four assumptions, then TRIZ and FMEA",
               "The rig is already built. Most of these tests need only vanes glued into it, a strobe app, beads and the Nile red kit we have for detection.")
    y = 252
    phases = [("Week 1", "Make the water spin", ["Strobe or tracer: water speed now", "Glue 4 vanes into the rig; re-run A/B/C"], ORANGE),
              ("Week 1", "Find the bypass", ["Dye through seam and ends", "Paper alone: K vs datasheet"], ORANGE),
              ("Week 2", "Finer paper on the rig", ["Grade 602 h class sleeve", "Flow at 0 / 1,000 / 1,500 rpm"], INK),
              ("Week 2–3", "Capture at speed", ["Spiked 1, 2, 5, 10 µm beads", "Count on the sleeve and in the water"], INK),
              ("Week 3", "Dirty water", ["Borewell water: flow vs litres", "Fit α; blank-sleeve background"], INK),
              ("Week 4", "TRIZ + FMEA session", ["Rate the 18 candidates", "Matrix for TC1–TC6"], MUTED)]
    n = len(phases); gap = 18; w = (W - 2 * M - gap * (n - 1)) / n
    for i, (wk, t, items, col) in enumerate(phases):
        x = M + i * (w + gap)
        b += card(x, y, w, 300) + rect(x, y, w, 8, col, 0) + label(x + 24, y + 46, wk, 13, col if col != MUTED else FAINT)
        p, h = P(x + 24, y + 82, t, 22, w - 48, 27, 600)
        b += p
        bl, _ = bullets(x + 24, y + 98 + h + 12, items, 16, w - 48, 8, col if col != MUTED else FAINT)
        b += bl
    y2 = y + 324
    b += card(M, y2, W - 2 * M, 990 - y2) + label(M + 30, y2 + 42, "Bench tests: what each one measures, and the requirement it settles", 13, INK)
    tests = [("1", "Strobe / tracer on the water, with and without vanes", "the 85 % slip", "2.1"), ("2", "Dye through the sleeve seam and ends", "bypass, sealing", "6.1"),
             ("3", "Flow vs speed with a 602 h class sleeve", "the speed band", "2.1"), ("4", "Borewell run: flow vs litres", "cake α, sleeve life", "9.1"),
             ("5", "Spiked beads at 0 and 1,500 rpm", "capture at 7× face velocity", "6.1"), ("6", "Blank sleeve under Nile red", "background, fibres", "6.2"),
             ("7", "20 batches on one sleeve", "tears, unbalance, noise", "3.5, 8.1"), ("8", "Time a sleeve change", "swap ≤ 30 s", "7.1")]
    cw = (W - 2 * M - 60) / 4
    for i, (n_, t, m_, r) in enumerate(tests):
        x = M + 30 + (i % 4) * cw; yy = y2 + 100 + (i // 4) * 150
        b += num_badge(x + 16, yy - 6, n_, 16, INK, size=15)
        p, h = P(x + 44, yy, t, 18, cw - 70, 24, 600)
        b += p
        p, h2 = P(x + 44, yy + h + 4, f"Measures {m_}", 16, cw - 70, 22, 400, MUTED)
        b += p
        cs, _ = chip(x + 44, yy + h + h2 + 18, f"settles {r}", ORANGE, ORANGE_BG, 13, 24)
        b += cs
    b += footer("Feed the measured values back into model.mjs and re-run the requirement table before the FMEA ratings")
    add("19_next_steps", "Next steps", b)


for f in [s01, s02, s03, s04, s05, s06, s07, s08, s09, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19]:
    f()
css = font_css()
os.makedirs("out", exist_ok=True)
for fn, title, body in SL:
    open(f"out/MPx_Spin_v1_{fn}.svg", "w").write(document(body, css, title))
print(len(SL), "slides")
