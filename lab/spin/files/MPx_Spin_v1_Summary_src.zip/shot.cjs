const { chromium } = require("playwright"); const fs = require("fs");
(async () => { const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
fs.mkdirSync("png", { recursive: true });
const only = process.argv[2];
for (const f of fs.readdirSync("out").filter(f => f.endsWith(".svg") && (!only || f.includes(only)))) {
  await p.goto("file://" + process.cwd() + "/out/" + f); await p.waitForTimeout(300);
  await p.screenshot({ path: "png/" + f.replace(".svg", ".png") });
}
await b.close(); })();
