"""Tiny SVG slide kit: measured text wrapping (Inter metrics), cards, chips, charts, embedded fonts/images."""
import base64, io, math, re
from PIL import ImageFont

W, H = 1920, 1080
M = 80                      # side margin
FONTDIR = "/usr/share/fonts/opentype/inter/"
WEIGHTS = {400: "Inter-Regular.otf", 500: "Inter-Medium.otf", 600: "Inter-SemiBold.otf", 700: "Inter-Bold.otf"}
_fc = {}
USED = {w: set() for w in WEIGHTS}

# palette (light, warm grey paper; orange from the product's grip ring)
BG = "#F3F2EE"; CARD = "#FFFFFF"; LINE = "#E1DFD8"; INK = "#1B1B19"; MUTED = "#6A6963"; FAINT = "#A3A19A"
ORANGE = "#E2531B"; ORANGE_BG = "#FCE7DD"
GREEN = "#23784A"; GREEN_BG = "#DFF0E5"
RED = "#BE3328"; RED_BG = "#FADFDB"
AMBER = "#9A6510"; AMBER_BG = "#F8EBCF"
BLUE = "#2F5E8C"; BLUE_BG = "#E1EAF3"
GREY_BG = "#ECEBE6"
SERIES = {"A": INK, "B": "#9C6B3A", "C": "#8E8C85", "PF": ORANGE}


def font(w, size):
    k = (w, size)
    if k not in _fc:
        _fc[k] = ImageFont.truetype(FONTDIR + WEIGHTS[w], size)
    return _fc[k]


def tw(s, size, w=400, ls=0.0):
    return font(w, int(round(size * 4))).getlength(s) / 4 + ls * len(s)


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _note(s, w):
    USED[w].update(s)


def T(x, y, s, size=20, w=400, fill=INK, anchor="start", ls=0, extra=""):
    _note(s, w)
    a = f' text-anchor="{anchor}"' if anchor != "start" else ""
    l = f' letter-spacing="{ls}"' if ls else ""
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" font-weight="{w}" fill="{fill}"{a}{l}{extra}>{esc(s)}</text>'


def label(x, y, s, size=14, fill=MUTED, anchor="start", w=600):
    return T(x, y, s.upper(), size, w, fill, anchor, ls=1.6)


def _words(text, w, bw):
    """'**60 N**, then' -> words; each word = list of (piece, weight) glued without spaces"""
    words, cur, bold = [], [], False
    for part in re.split(r"(\*\*)", text):
        if part == "**":
            bold = not bold
            continue
        wt = bw if bold else w
        for i, chunk in enumerate(re.split(r"(\s+)", part)):
            if not chunk:
                continue
            if chunk.isspace():
                if cur:
                    words.append(cur); cur = []
                continue
            cur.append((chunk, wt))
    if cur:
        words.append(cur)
    # keep "1 µm", "60 N", "2.2 L/min" together
    out = []
    for wd in words:
        first = wd[0][0]
        unit = re.match(r"^(µm|mm|cm²|cm|m|L|mL|N|s|bar|%|°C|g|kg|L/min|L/h|MPa|mg/L|mg|dB\(A\)|min|W|×)[.,;:)]*$", first)
        if out and unit and re.search(r"[\d½]$", out[-1][-1][0]):
            prev = out[-1]
            prev[-1] = (prev[-1][0] + "\u00a0", prev[-1][1])
            out[-1] = prev + wd
        else:
            out.append(wd)
    return out


def _ww(word, size):
    return sum(tw(p, size, wt) for p, wt in word)


def wrap_rich(text, size, maxw, w=400, bw=600):
    """returns list of lines; each line is a list of words"""
    lines = []
    for para in text.split("\n"):
        line_, lw = [], 0.0
        sp = tw(" ", size, w)
        for word in _words(para, w, bw):
            ww = _ww(word, size)
            add = ww + (sp if line_ else 0)
            if line_ and lw + add > maxw:
                lines.append(line_)
                line_, lw, add = [], 0.0, ww
            line_.append(word)
            lw += add
        lines.append(line_)
    return lines


def P(x, y, text, size=20, maxw=600, lh=None, w=400, fill=INK, bw=600, anchor="start", bfill=None):
    """paragraph with **bold** runs; y is first baseline. returns (svg, height_used)"""
    lh = lh or round(size * 1.38)
    lines = wrap_rich(text, size, maxw, w, bw)
    out = []
    for i, ln in enumerate(lines):
        if not ln:
            continue
        segs = []
        for j, word in enumerate(ln):
            for k, (piece, wt) in enumerate(word):
                piece = (" " if (j and k == 0) else "") + piece
                if segs and segs[-1][1] == wt:
                    segs[-1][0] += piece
                else:
                    segs.append([piece, wt])
        spans = []
        for s_, wt in segs:
            _note(s_, wt)
            col = f' fill="{bfill}"' if (bfill and wt != w) else ""
            spans.append(f'<tspan font-weight="{wt}"{col}>{esc(s_)}</tspan>')
        a = f' text-anchor="{anchor}"' if anchor != "start" else ""
        out.append(f'<text x="{x:.1f}" y="{y + i * lh:.1f}" font-size="{size}" fill="{fill}" font-weight="{w}"{a} xml:space="preserve">{"".join(spans)}</text>')
    return "".join(out), len(lines) * lh


def plines(text, size, maxw, w=400, bw=600):
    return len(wrap_rich(text, size, maxw, w, bw))


def card(x, y, w, h, fill=CARD, stroke=LINE, r=14, sw=1):
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'


def rect(x, y, w, h, fill, r=0, extra=""):
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{r}" fill="{fill}"{extra}/>'


def line(x1, y1, x2, y2, stroke=LINE, sw=1, dash=None, extra=""):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{stroke}" stroke-width="{sw}"{d}{extra}/>'


STATUS = {
    "pass": ("Pass · sim", GREEN, GREEN_BG),
    "met": ("Met by design", GREEN, GREEN_BG),
    "design": ("By design · untested", BLUE, BLUE_BG),
    "partial": ("Partial", AMBER, AMBER_BG),
    "fail": ("Fail", RED, RED_BG),
    "risk": ("At risk", RED, RED_BG),
    "open": ("Not yet tested", MUTED, GREY_BG),
    "na": ("Not applicable", MUTED, GREY_BG),
}


def chip(x, y, text, fg, bg, size=14, h=26, w=600, anchor="start"):
    """y = vertical centre"""
    tw_ = tw(text, size, w) + 22
    if anchor == "end":
        x -= tw_
    return rect(x, y - h / 2, tw_, h, bg, r=h / 2) + T(x + 11, y + size * 0.36, text, size, w, fg), tw_


def num_badge(cx, cy, n, r=15, fill=ORANGE, fg="#fff", size=15):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}"/>' + T(cx, cy + size * 0.36, str(n), size, 700, fg, "middle")


def img(x, y, w, h, path, r=0, clip_id=None, fit="slice", stroke=None):
    with open(path, "rb") as f:
        b = base64.b64encode(f.read()).decode()
    mime = "image/jpeg" if path.endswith(".jpg") else "image/png"
    par = "xMidYMid slice" if fit == "slice" else "xMidYMid meet"
    out = ""
    cp = ""
    if r:
        cid = clip_id or f"c{abs(hash((x, y, path))) % 10**8}"
        out += f'<clipPath id="{cid}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}"/></clipPath>'
        cp = f' clip-path="url(#{cid})"'
    out += f'<image x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="{par}"{cp} href="data:{mime};base64,{b}"/>'
    if stroke:
        out += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="none" stroke="{stroke}"/>'
    return out


def header(n, total, title, sub=None, kicker="MPx Squeeze v2 · design review"):
    s = label(M, 66, kicker) + label(W - M, 66, f"{n:02d} / {total:02d}", anchor="end")
    s += line(M, 84, W - M, 84, LINE)
    s += T(M, 146, title, 46, 600, INK, ls=-0.6)
    h = 0
    if sub:
        p, h = P(M, 190, sub, 22, W - 2 * M - 200, 31, 400, MUTED, bw=600, bfill=INK)
        s += p
    return s, 190 + h


def footer(note=""):
    s = line(M, H - 58, W - M, H - 58, LINE)
    s += T(M, H - 30, "PD-298 · Team MPx · CPDM, IISc · Oct 2026", 14, 500, FAINT)
    if note:
        s += T(W - M, H - 30, note, 14, 400, FAINT, "end")
    return s


# ---------- charts ----------
class Chart:
    def __init__(self, x, y, w, h, xd, yd, xlog=False, pad=(70, 20, 20, 56)):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.l, self.t, self.r, self.b = pad
        self.xd, self.yd, self.xlog = xd, yd, xlog
        self.px0, self.px1 = x + self.l, x + w - self.r
        self.py0, self.py1 = y + h - self.b, y + self.t
        self.parts = []

    def X(self, v):
        a, b = self.xd
        if self.xlog:
            f = (math.log10(v) - math.log10(a)) / (math.log10(b) - math.log10(a))
        else:
            f = (v - a) / (b - a)
        return self.px0 + f * (self.px1 - self.px0)

    def Y(self, v):
        a, b = self.yd
        return self.py0 + (v - a) / (b - a) * (self.py1 - self.py0)

    def axes(self, xt, yt, xlab="", ylab="", xfmt=str, yfmt=str, grid=True):
        s = []
        for v in yt:
            yy = self.Y(v)
            if grid:
                s.append(line(self.px0, yy, self.px1, yy, "#ECEAE4"))
            s.append(T(self.px0 - 10, yy + 5, yfmt(v), 14, 400, MUTED, "end"))
        for v in xt:
            xx = self.X(v)
            s.append(line(xx, self.py0, xx, self.py0 + 5, FAINT))
            s.append(T(xx, self.py0 + 24, xfmt(v), 14, 400, MUTED, "middle"))
        s.append(line(self.px0, self.py0, self.px1, self.py0, FAINT, 1.2))
        if xlab:
            s.append(T((self.px0 + self.px1) / 2, self.py0 + 50, xlab, 15, 500, MUTED, "middle"))
        if ylab:
            cx, cy = self.x + 16, (self.py0 + self.py1) / 2
            _note(ylab, 500)
            s.append(f'<text transform="translate({cx:.1f},{cy:.1f}) rotate(-90)" font-size="15" font-weight="500" fill="{MUTED}" text-anchor="middle">{esc(ylab)}</text>')
        self.parts += s

    def path(self, pts, color=INK, sw=2.6, dash=None, fill=None, close_to=None):
        d = "M" + " L".join(f"{self.X(a):.1f} {self.Y(b):.1f}" for a, b in pts)
        if fill is not None:
            d2 = d + f" L{self.X(pts[-1][0]):.1f} {self.Y(close_to):.1f} L{self.X(pts[0][0]):.1f} {self.Y(close_to):.1f} Z"
            self.parts.append(f'<path d="{d2}" fill="{fill}" stroke="none"/>')
        da = f' stroke-dasharray="{dash}"' if dash else ""
        self.parts.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round"{da}/>')

    def hline(self, v, color=MUTED, dash="6 5", text=None, side="right", size=14, dy=-7, w=500):
        yy = self.Y(v)
        self.parts.append(line(self.px0, yy, self.px1, yy, color, 1.3, dash))
        if text:
            if side == "right":
                self.parts.append(T(self.px1 - 4, yy + dy, text, size, w, color, "end"))
            else:
                self.parts.append(T(self.px0 + 6, yy + dy, text, size, w, color))

    def vline(self, v, color=MUTED, dash="6 5", text=None, size=14, dx=6, ty=None, w=500):
        xx = self.X(v)
        self.parts.append(line(xx, self.py0, xx, self.py1, color, 1.3, dash))
        if text:
            self.parts.append(T(xx + dx, ty if ty else self.py1 + 16, text, size, w, color, "start" if dx >= 0 else "end"))

    def zone(self, x0, x1, y0, y1, fill):
        X0, X1 = self.X(x0), self.X(x1)
        Y0, Y1 = self.Y(y0), self.Y(y1)
        self.parts.append(rect(min(X0, X1), min(Y0, Y1), abs(X1 - X0), abs(Y1 - Y0), fill))

    def dot(self, a, b, color=INK, r=6, ring=True):
        st = f' stroke="#fff" stroke-width="2.5"' if ring else ""
        self.parts.append(f'<circle cx="{self.X(a):.1f}" cy="{self.Y(b):.1f}" r="{r}" fill="{color}"{st}/>')

    def text(self, a, b, s, size=15, w=600, fill=INK, anchor="start", dx=0, dy=0):
        self.parts.append(T(self.X(a) + dx, self.Y(b) + dy, s, size, w, fill, anchor))

    def svg(self):
        return "".join(self.parts)


# ---------- fonts + document ----------
def font_css():
    from fontTools import subset
    from fontTools.ttLib import TTFont
    css = []
    for w, fn in WEIGHTS.items():
        chars = USED[w] | set("0123456789 .,%-")
        if not chars:
            continue
        f = TTFont(FONTDIR + fn)
        opts = subset.Options()
        opts.flavor = "woff2"
        opts.layout_features = ["kern", "liga", "calt"]
        opts.name_IDs = []
        sub = subset.Subsetter(opts)
        sub.populate(text="".join(chars))
        sub.subset(f)
        buf = io.BytesIO()
        f.flavor = "woff2"
        f.save(buf)
        b = base64.b64encode(buf.getvalue()).decode()
        css.append(f"@font-face{{font-family:'MPxInter';font-weight:{w};src:url(data:font/woff2;base64,{b}) format('woff2');}}")
    return "".join(css)


def document(body, css, title):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 {W} {H}" width="{W}" height="{H}">'
            f'<title>{esc(title)}</title>'
            f'<style>{css} text{{font-family:MPxInter,Inter,"Segoe UI",Helvetica,Arial,sans-serif}}</style>'
            f'<rect width="{W}" height="{H}" fill="{BG}"/>{body}</svg>')


def status_icon(cx, cy, st, r=9):
    if st == "done":
        return f'<circle cx="{cx}" cy="{cy}" r="{r+1}" fill="{GREEN}"/><path d="M{cx-4.5} {cy+0.5} l3 3 l6 -6.5" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>'
    if st == "half":
        return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="#fff" stroke="{AMBER}" stroke-width="2"/><path d="M{cx} {cy-r} A{r} {r} 0 0 1 {cx} {cy+r} Z" fill="{AMBER}"/>'
    if st == "now":
        return f'<circle cx="{cx}" cy="{cy}" r="{r+1}" fill="{ORANGE}"/><path d="M{cx-3} {cy-5} L{cx+5} {cy} L{cx-3} {cy+5} Z" fill="#fff"/>'
    return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{FAINT}" stroke-width="2"/>'


def _fparts(s):
    out = []
    for m in re.split(r"([_^]\{[^}]*\})", s):
        if not m:
            continue
        if m[:2] in ("_{", "^{"):
            out.append((m[2:-1], m[0]))
        else:
            out.append((m, ""))
    return out


def F(x, y, s, size=20, w=500, fill=INK):
    """formula text: X_{sub} subscript, X^{sup} superscript"""
    out, back = [], 0.0
    for p, kind in _fparts(s):
        _note(p, w)
        if kind:
            d = size * (0.22 if kind == "_" else -0.38)
            out.append(f'<tspan font-size="{size * 0.68:.1f}" dy="{d - back:.1f}">{esc(p)}</tspan>')
            back = d
        else:
            dd = f' dy="{-back:.1f}"' if back else ""
            back = 0.0
            out.append(f'<tspan{dd}>{esc(p)}</tspan>')
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" font-weight="{w}" fill="{fill}" xml:space="preserve">{"".join(out)}</text>'


def fw(s, size, w=500):
    return sum(tw(p, size * (0.68 if k else 1), w) for p, k in _fparts(s))
