import * as M from "../fig/model.mjs";
import { writeFileSync } from "node:fs";
const base = { geom: "prod", rpm: 1500, batch: 400, T: 25, paper: "P602", vanes: true, water: "tap", mpPerL: 1000 };
const rig = (rpm) => ({ ...base, geom: "rig", rpm, paper: "G4", vanes: false });
const out = {};
out.exp = M.EXP.map((e) => { const m = e.t.reduce((a, b) => a + b) / 3; const sd = Math.sqrt(e.t.reduce((a, b) => a + (b - m) ** 2, 0) / 2); return { rpm: e.rpm, t: e.t, mean: m, sd, model: M.timeTo90(rig(e.rpm)), apparent: 0.2 / m * 3600 }; });
out.rig = { kappa: M.RIG.kappa, slip: M.RIG.slip, Kmodel: M.RIG.kappa / M.mu(25), Kdata: M.herzK(M.PAPERS.G4, 25), cc: M.countCapture(M.PAPERS.G4), bands: M.bandCapture(M.PAPERS.G4),
  g5000: M.gLevel(5000 * 2 * Math.PI / 60, 0.025), gw5000: M.gLevel(5000 * 2 * Math.PI / 60 * M.RIG.slip, 0.025), face5000: M.faceRatio(rig(5000)), cyc5000: M.cycleLh(rig(5000)) };
out.share = M.bandShare();
const rpms = []; for (let r = 0; r <= 6000; r += 100) rpms.push(r);
out.curve = { rpm: rpms, rig: rpms.map((r) => M.timeTo90(rig(r))), v1: rpms.map((r) => M.timeTo90({ ...base, rpm: r })), v1nv: rpms.map((r) => M.timeTo90({ ...base, rpm: r, vanes: false })) };
const r2 = []; for (let r = 0; r <= 4000; r += 50) r2.push(r);
out.band = { rpm: r2, lh: r2.map((r) => M.cycleLh({ ...base, rpm: r })), fv: r2.map((r) => M.faceRatio({ ...base, rpm: r })) };
const ok = r2.filter((r, i) => out.band.lh[i] >= 15 && out.band.fv[i] <= 10); out.bandLo = ok[0]; out.bandHi = ok[ok.length - 1];
out.papers = Object.entries(M.PAPERS).map(([k, p]) => { const i = { ...base, paper: k }; return { k, name: p.name, short: p.short, rating: p.rating, herz: p.herz, cc: M.countCapture(p), b: M.bandCapture(p), t90: M.timeTo90(i), lh: M.cycleLh(i), fv: M.faceRatio(i), l15: M.litresTo15(i), l15nv: M.litresTo15({ ...i, vanes: false }), lhnv: M.cycleLh({ ...i, vanes: false }) }; });
out.waters = Object.entries(M.WATERS).map(([k, w]) => ({ k, label: w.label, c: w.c, l15: M.litresTo15({ ...base, water: k }) }));
// speed sweep of sleeve life
out.l15rpm = [800, 1000, 1200, 1500, 1700, 2000, 2500].map((r) => ({ rpm: r, l15: M.litresTo15({ ...base, rpm: r }), lh: M.cycleLh({ ...base, rpm: r }), fv: M.faceRatio({ ...base, rpm: r }) }));
const w = 1500 * 2 * Math.PI / 60;
const fw = M.flowOf(400e-6, w * M.SLIP_VANES, M.Kof(base, null), M.PROD.R, M.PROD.H);
out.v1 = { t90: M.timeTo90(base), lh: M.cycleLh(base), fv: M.faceRatio(base), l15: M.litresTo15(base), g: M.gLevel(w * M.SLIP_VANES, M.PROD.R), gb: M.gLevel(w, M.PROD.R), pWall: fw.pWall, hoop: M.hoopMPa(w, M.PROD.R, fw.pWall), sf: 170 / M.hoopMPa(w, M.PROD.R, fw.pWall),
  unb1: M.unbalanceN(1, w, M.PROD.R), unb5: M.unbalanceN(5, w, M.PROD.R), cc: M.countCapture(M.PAPERS.P602), b: M.bandCapture(M.PAPERS.P602), K: M.herzK(M.PAPERS.P602, 25), Q0: fw.Q, wet: fw.wet, zR: fw.sf.zR, z0: fw.sf.z0 };
out.v1nv = { t90: M.timeTo90({ ...base, vanes: false }), lh: M.cycleLh({ ...base, vanes: false }) };
// full batch simulation for power and timeline
{ const s = M.fresh(base); const tl = []; let k = 0; while (s.phase !== "done" && s.t < 400) { M.step(s, base, 0.01); if (k++ % 20 === 0) tl.push([+s.t.toFixed(2), +(s.V * 1e6).toFixed(1), +(s.Q * 3.6e6).toFixed(1), +(s.P || 0).toFixed(1), +(s.out * 1e6).toFixed(1), +(s.ww * 60 / 2 / Math.PI).toFixed(0)]); }
  out.run = { Wh: s.Wh, t: s.t, t90: s.t90, tl, Pmax: Math.max(...tl.map((r) => r[3])) }; }
out.drift = M.POLYMERS.map(([n, rho]) => ({ n, rho, v10: M.drift(rho, 10, w * M.SLIP_VANES, 0.025), v50: M.drift(rho, 50, w * M.SLIP_VANES, 0.025) }));
out.throughV = fw.Q / (2 * Math.PI * M.PROD.R * fw.wet);
out.req = M.requirements(base);
out.reqRig = M.requirements(rig(5000));
out.slipSens = [0.2, 0.3, 0.5, 0.7, 0.85, 1.0].map((sl) => { const i = { ...base, rpm: 1500 * sl / 0.85 }; return { sl, lh: M.cycleLh(i), fv: M.faceRatio(i), l15: M.litresTo15(i) }; });
out.temp = [5, 15, 25, 35, 45].map((T) => ({ T, lh: M.cycleLh({ ...base, T }), l15: M.litresTo15({ ...base, T }) }));
writeFileSync("data.json", JSON.stringify(out, null, 1));
console.log(JSON.stringify({ exp: out.exp, rig: out.rig, v1: out.v1, v1nv: out.v1nv, band: [out.bandLo, out.bandHi], papers: out.papers.map(p => [p.k, p.cc.toFixed(3), p.b[0].toFixed(2), p.lh.toFixed(1), p.fv.toFixed(1), p.l15.toFixed(0), p.lhnv.toFixed(1)]), waters: out.waters, l15rpm: out.l15rpm, run: { Wh: out.run.Wh, t: out.run.t, t90: out.run.t90, Pmax: out.run.Pmax }, drift: out.drift, thr: out.throughV }, null, 0));
