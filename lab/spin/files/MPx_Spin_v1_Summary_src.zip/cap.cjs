const { chromium } = require("playwright");
const F = "file://" + process.cwd() + "/../fig/spin-bench.html";
(async () => { const b = await chromium.launch();
async function page() { const p = await b.newPage({ viewport: { width: 1000, height: 1400 }, deviceScaleFactor: 2 }); const errs = []; p.on("pageerror", e => errs.push(e.message)); await p.goto(F); await p.waitForTimeout(400); p.errs = errs; return p; }
const cards = async (p, pre) => { const c = p.locator(".sq-card"); const n = await c.count(); for (let i = 0; i < n; i++) await c.nth(i).screenshot({ path: `shots/${pre}_card${i}.png` }); };
const set = (p, k, v) => p.$eval(`[data-in="${k}"]`, (e, v) => { e.value = v; e.dispatchEvent(new Event("input")); e.dispatchEvent(new Event("change")); }, v);
let p = await page();
await p.click('.sq-mode[data-mode="rig"]'); await p.waitForTimeout(4200);
await p.locator(".iso-plate").screenshot({ path: "shots/rig.png" }); await cards(p, "rig");
await p.click('.sq-mode[data-mode="spin"]'); await p.waitForTimeout(6500);
await p.locator(".iso-plate").screenshot({ path: "shots/spin.png" }); await cards(p, "spin");
await p.waitForTimeout(16000);
await p.click('.sq-mode[data-mode="inspect"]'); await p.waitForTimeout(4000);
await p.locator(".iso-plate").screenshot({ path: "shots/inspect.png" }); await cards(p, "insp");
console.log(p.errs); await p.close();
p = await page();
await set(p, "vanes", "0"); await p.click('.sq-mode[data-mode="spin"]'); await p.waitForTimeout(9000);
await p.locator(".iso-plate").screenshot({ path: "shots/novane.png" }); await cards(p, "nv");
console.log(p.errs); await b.close(); })();
