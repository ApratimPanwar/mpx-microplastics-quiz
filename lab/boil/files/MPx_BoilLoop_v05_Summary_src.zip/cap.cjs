const { chromium } = require("playwright");
const F = "file:///mnt/user-data/uploads/MPx/BoilLoop_Mini_v0.5/figure/MPx_BoilLoop_Mini_v05_Cutaway.html";
(async () => { const b = await chromium.launch();
async function page() { const p = await b.newPage({ viewport: { width: 1100, height: 1400 }, deviceScaleFactor: 2 }); const errs=[]; p.on("pageerror", e => errs.push(e.message)); await p.goto(F); await p.waitForTimeout(300); p.errs=errs; return p; }
let p = await page();
const t0 = Date.now(); const at = async (s) => { const w = s * 1000 - (Date.now() - t0); if (w > 0) await p.waitForTimeout(w); };
await at(3.3); await p.locator(".iso-plate").screenshot({ path: "shots/warm.png" }); await p.locator("figure.bl").screenshot({ path: "shots/warm_full.png" });
await at(15); await p.locator(".iso-plate").screenshot({ path: "shots/prod.png" }); await p.locator(".bl-stations").screenshot({ path: "shots/prod_st.png" }); await p.locator(".bl-panel").screenshot({ path: "shots/prod_panel.png" });
await at(23.5); await p.locator(".iso-plate").screenshot({ path: "shots/empty.png" });
console.log(p.errs);
await p.close();
p = await page(); const t1 = Date.now();
await p.check('input[data-in="stat"]'); await p.waitForTimeout(5000);
await p.locator(".iso-plate").screenshot({ path: "shots/stat.png" }); await p.locator(".bl-stations").screenshot({ path: "shots/stat_st.png" }); await p.locator(".bl-panel").screenshot({ path: "shots/stat_panel.png" });
// hover the lime trap station
await p.click('.bl-st[data-sel="6"]'); await p.waitForTimeout(400); await p.locator(".bl-panel").screenshot({ path: "shots/trap_panel.png" }); await p.locator(".iso-plate").screenshot({ path: "shots/trap.png" });
await b.close(); })();
