import * as M from "./model.mjs";
const out = {};
const base = { Q: 1.2, H: 285, Ta: 25 };
function trace(inp, opts = {}) {
  let s = M.start({ ...inp, primed: opts.primed ?? true }); const pts = []; let first = null;
  while (s.t < 4 * 3600 && s.phase !== "done") { s = M.step(s, inp, 1); if (s.cup > 0.5 && first === null) first = s.t;
    if (s.t % 30 === 0) pts.push([s.t / 60, s.core, s.Tj, s.cup, s.out, s.Wh, s.phase, s.Mj * 1000, s.heater, s.steamMl]); if (s.phase === "jug empty" && !out._empty) {} }
  return { pts, first: first / 60, end: s, endMin: s.t / 60 };
}
const a = trace(base), b = trace({ ...base, stat: true }), c = trace(base, { primed: false });
out.run = { pts: a.pts, first: a.first, cup: a.end.cup, Wh: a.end.Wh, lime: a.end.lime, steam: a.end.steamMl };
out.runStat = { pts: b.pts, first: b.first, cup: b.end.cup, Wh: b.end.Wh };
out.runDry = { first: c.first, cup: c.end.cup };
// time when jug empty (cup stops growing)
const empt = (pts) => { let last = pts[0]; for (const p of pts) if (p[3] > last[3] + 0.1) last = p; return last[0]; };
out.run.lastWater = empt(a.pts); out.runStat.lastWater = empt(b.pts);
out.run.outMax = Math.max(...a.pts.filter(p => p[3] > 1).map(p => p[4])); out.runStat.outMax = Math.max(...b.pts.filter(p => p[3] > 1).map(p => p[4]));
// steady vs flow
out.flow = [];
for (let Q = 0.4; Q <= 3.01; Q += 0.1) { const s = M.steady({ Q, H: 285, Ta: 25 }); out.flow.push({ Q: +Q.toFixed(2), eps: s.eps, heater: s.heater.total, noX: s.heater.noExchanger, outlet: s.outlet, boil: s.boilMin }); }
let qmax = 0; for (let Q = 0.4; Q < 20; Q += 0.01) { if (M.steady({ Q, H: 285, Ta: 25 }).heater.total <= 60) qmax = Q; }
out.qmax60 = qmax;
const s15 = M.steady({ Q: 15, H: 285, Ta: 25 }); out.at15 = { heater: s15.heater.total, noX: s15.heater.noExchanger, eps: s15.eps, boilMin: s15.boilMin, outlet: s15.outlet, boilVolFor3min: 15 * 1000 / 60 * 3 };
out.steady12 = M.steady(base); out.steady12_35 = M.steady({ ...base, Ta: 35 });
out.removal = []; for (let H = 0; H <= 400; H += 5) out.removal.push([H, M.removalOf(H)]);
out.removalAt = Object.fromEntries([50, 80, 120, 180, 200, 285, 300].map(h => [h, M.removalOf(h)]));
// Q for 3 min dwell
out.qFor3min = 61 / 3 * 60 / 1000;
console.log(JSON.stringify(out));
