import json, math, os
from lib import *

D = json.load(open("data.json"))
TOTAL = 17
KICK = "MPx Boil-Loop Mini v0.5 · design review"
SL = []
BLUEW = "#3B7BB8"


def add(fn, title, body):
    SL.append((fn, title, body))


def hdr(n, title, sub=None):
    return header(n, TOTAL, title, sub, kicker=KICK)


def bullets(x, y, items, size=20, maxw=600, gap=14, dot=ORANGE, lh=None):
    s, yy = "", y
    for it in items:
        s += f'<circle cx="{x + 5}" cy="{yy - size * 0.33:.1f}" r="4" fill="{dot}"/>'
        p, h = P(x + 22, yy, it, size, maxw - 22, lh)
        s += p
        yy += h + gap
    return s, yy - y


R = D["run"]; RS = D["runStat"]; S12 = D["steady12"]; A15 = D["at15"]
WH_L = R["Wh"] / (R["cup"] / 1000); WH_LS = RS["Wh"] / (RS["cup"] / 1000)


# 01 ---------------------------------------------------------------------------------------
def s01():
    b = rect(900, 0, 1020, 1080, "#FAFAF8") + img(1010, 40, 800, 1124 * 800 / 800 * 0.889, "img/stat.jpg", fit="meet")
    b += label(M, 120, "MPx · PD-298 · design review", 16, ORANGE)
    b += T(M, 250, "Boil-Loop Mini v0.5", 84, 600, INK, ls=-2.2)
    b += T(M, 316, "Boil, catch the lime-crusted plastic, cool, pour", 32, 500, INK, ls=-0.3)
    p, h = P(M, 384, "What it does, what the simulation showed, which of our 22 technical requirements it meets and misses, "
             "and a **design FMEA**. It removes microplastics well in hard water, but it makes about **1.2 L/h**: far below our 15 L/h target.", 23, 740, 34, 400, MUTED, bfill=INK)
    b += p
    stats = [("1.2 L/h", "vs a 15 L/h target"), ("90 %", "removal at 285 mg/L hardness*"), ("2.7 kg", "Ø105 × 388 mm, 60 W USB-C"), ("38 min", "to first water as drawn*")]
    for i, (v, k) in enumerate(stats):
        x, y = M + (i % 2) * 380, 620 + (i // 2) * 150
        b += line(x, y, x + 340, y, INK, 1.5)
        b += T(x, y + 62, v, 50, 600, RED if i in (0, 3) else INK, ls=-1)
        b += T(x, y + 96, k, 19, 400, MUTED)
    b += T(M, 960, "* simulated (tube model + lumped warm-up run); no physical tests yet", 15, 400, FAINT)
    b += label(M, 1010, "Exploratory concept · drawings v0.5 · Oct 2026", 15, INK)
    add("01_title", "Boil-Loop Mini v0.5 — design review", b)


# 02 ---------------------------------------------------------------------------------------
def s02():
    b, _ = hdr(2, "Where this concept sits in the CED process",
               "Boil-Loop is the boil-and-filter concept we kept exploring after concept selection. It already has a layout and drawings, so the same embodiment checks apply: **critical review and FMEA**.")
    stages = [("Task clarification", "Lec 3–5", "Requirements list (22), SNPS, objective tree", "done"),
              ("Conceptual design", "Lec 6–8", "Boil-and-filter came out of the morphological chart", "done"),
              ("Simulation", "Lec 9", "Tube model, chemistry, warm-up run (this deck)", "done"),
              ("Evaluation", "Lec 10", "Not in the chosen three (04, 07, 05): explored as an option", "half"),
              ("Embodiment design", "Now", "v0.5 layout + drawings done; FMEA in this deck", "now"),
              ("Detail design", "Only if", "it passes the hardness and flow gates", "next"),
              ("Production", "Later", "Production instructions", "next")]
    n = len(stages); gap = 14; bw = (W - 2 * M - gap * (n - 1)) / n; y = 268; bh = 168
    for i, (t, l, d, st) in enumerate(stages):
        x = M + i * (bw + gap)
        fill, stroke, fg = (CARD, LINE, INK) if st in ("done", "half") else ((ORANGE, ORANGE, "#fff") if st == "now" else (BG, "#D3D1CA", MUTED))
        b += card(x, y, bw, bh, fill, stroke, 12)
        b += label(x + 18, y + 32, l, 13, "#fff" if st == "now" else (GREEN if st == "done" else (AMBER if st == "half" else FAINT)))
        if st in ("done", "half"):
            b += status_icon(x + bw - 26, y + 27, st, 8)
        p, h = P(x + 18, y + 66, t, 21, bw - 30, 26, 600, fg)
        b += p
        p2, _ = P(x + 18, y + 72 + h, d, 15, bw - 30, 20, 400, "#FFE9DF" if st == "now" else MUTED)
        b += p2
        if i < n - 1:
            b += T(x + bw + gap / 2, y + bh / 2 + 6, "›", 22, 600, FAINT, "middle")
    y = 470
    b += card(M, y, 1140, 520)
    b += label(M + 32, y + 44, "Embodiment design steps (lecture 2, slide 36) and where Boil-Loop stands", 14, INK)
    rows = [("done", "Overall layout: general arrangement, spatial compatibility", "v0.5 drawing set S01–S08, STEP assembly, Ø105 × 388 mm"),
            ("done", "Preliminary form design: shapes, materials, processes", "316L tube coils, Al finned shell, borosilicate jug, 7 electrical parts, no PCB"),
            ("half", "Apply all major criteria", "Technical by simulation. Flow, mass (2.7 kg) and cost fail or are open"),
            ("half", "Develop with scale drawings and critical reviews", "Drawings done; this deck is the critical review"),
            ("now", "Use methods for identification of errors (e.g. FMEA)", "Draft design FMEA: 20 failure modes, 11 critical (slides 13–16)"),
            ("next", "Apply methods for optimisation", "Only worth it if the two gates pass: hardness of our water, and a flow the team accepts"),
            ("next", "Outcome: embodiment ready for detail design", "Not yet")]
    ty = y + 74
    for k, (st, step, ev) in enumerate(rows):
        if k:
            b += line(M + 32, ty - 8, M + 1108, ty - 8, "#EFEDE7")
        b += status_icon(M + 46, ty + 15, st)
        p, h1 = P(M + 70, ty + 22, step, 18, 470, 23, 600 if st == "now" else 500, INK)
        p2, h2 = P(M + 570, ty + 22, ev, 17, 540, 23, 400, MUTED)
        b += p + p2
        ty += max(h1, h2) + 16
    x = M + 1170; w = W - M - x
    b += card(x, y, w, 520, ORANGE_BG, "#F4C9B5")
    b += label(x + 32, y + 44, "Two gates before more embodiment work", 14, ORANGE)
    p, h = P(x + 32, y + 88, "The FMEA is useful now, but two findings decide whether the concept is worth detailing at all.", 19, w - 64, 27)
    b += p
    bl, _ = bullets(x + 32, y + 100 + h + 18, [
        "**Gate 1, chemistry:** measure the hardness of the water we target. Removal is 90 % at 285 mg/L but only about 40 % at 80 mg/L.",
        "**Gate 2, flow:** 1.2 L/h is fixed by the 3 min boil and the 60 W heater. 15 L/h would need about **580 W** and a **750 mL** boil coil.",
        "If both pass, carry on with the FMEA actions; if not, keep it as a bench experiment, not a product."], 17, w - 64, 10)
    b += bl
    b += footer("Sources: CED lec02 sl. 36–37; Pahl & Beitz, Engineering Design 3e, §10.4; MPx project notes")
    add("02_ced_position", "Where Boil-Loop sits in CED", b)


# 03 ---------------------------------------------------------------------------------------
def s03():
    b, _ = hdr(3, "What the product does",
               "A bottle-sized purifier on USB-C. It pumps water through thin steel tubes, holds it at a boil so dissolved lime crusts around microplastics, catches the crust while hot, then cools the water with its own heat exchanger.")
    y = 262; bot = 990
    b += card(M, y, 470, bot - y)
    b += img(M + 10, y + 10, 450, bot - y - 20, "img/unitA.jpg", fit="meet")
    x = M + 500; w = 640
    steps = [("Fill and switch on", "Pour 0.5 L into the glass jug and plug in a 65 W USB-C charger or power bank. A peristaltic pump pulls **20 mL/min** from the jug."),
             ("Heat with its own heat", "Cold water climbs the outer tube of a 2.4 m tube-in-tube exchanger and is warmed to about **95 °C** by the water coming back down. A **60 W** heater adds the last few degrees."),
             ("Boil and crust", "About **3 min** at the boil in a vented 61 mL coil. Calcium bicarbonate loses CO₂ and comes out as lime, which crusts around plastic particles."),
             ("Catch and cool", "A **25 µm** steel mesh in a twist-out drawer catches the crust. A wax gate only opens above 92–95 °C. The exchanger and the body coil cool the water to about **27 °C**.")]
    hs = [56 + plines(d, 18, w - 50, 400, 600) * 26 for _, d in steps]
    gap_ = (bot - y - 6 - sum(hs)) / (len(steps) - 0.6)
    yy = y + 6
    for i, (t, d) in enumerate(steps):
        b += num_badge(x + 18, yy + 16, i + 1, 18, INK, size=16)
        b += T(x + 50, yy + 23, t, 23, 600)
        p, h = P(x + 50, yy + 56, d, 18, w - 50, 26, 400, MUTED, bfill=INK)
        b += p
        if i < len(steps) - 1:
            b += line(x + 50, yy + hs[i] + gap_ / 2 - 10, x + w, yy + hs[i] + gap_ / 2 - 10, LINE)
        yy += hs[i] + gap_
    x2 = x + w + 30; w2 = W - M - x2
    spec = [("Size", "Ø105 × 388 mm (over fins and jug)"),
            ("Mass", "2.73 kg dry. The concept sheet said 1.3 kg; the exchanger and shell dominate"),
            ("Power", "USB-C PD 20 V, 60 W heater; about 23 W once running"),
            ("Flow", "1.2 L/h; jug of 0.5 L"),
            ("Removal", "90 % at 285 mg/L hardness; about 40 % at 80 mg/L (Yu et al. 2024 fit)"),
            ("Water path", "316L tube, borosilicate glass, silicone seals; PharMed pump tube on the cold side"),
            ("Electrics", "7 parts, no PCB, battery or sensor; wax gate and standpipe do the control"),
            ("Cost", "Not costed for v0.5. v0.4 BOM: ₹14,890 prototype, ₹6,650 implied retail")]
    rows, yy = "", y + 86
    for k, v in spec:
        rows += T(x2 + 28, yy, k, 16, 600, MUTED)
        p, h = P(x2 + 140, yy, v, 17, w2 - 168, 23)
        rows += p
        yy += h + 15
        rows += line(x2 + 28, yy - 8, x2 + w2 - 28, yy - 8, "#EFEDE7")
    ch = yy - y + 6
    b += card(x2, y, w2, ch) + label(x2 + 28, y + 42, "Key numbers", 13, INK) + rows
    sy = y + ch + 20
    b += card(x2, sy, w2, bot - sy, GREY_BG, GREY_BG)
    b += label(x2 + 28, sy + 40, "Against our SNPS", 13, INK)
    cols = [("Remove", "yes, in hard water", GREEN), ("Detect", "no; pairs with C05", RED), ("Contain", "lime in the drawer", AMBER)]
    cw = (w2 - 56) / 3
    for i, (a_, c_, col) in enumerate(cols):
        b += T(x2 + 28 + i * cw, sy + 82, a_, 22, 600, col)
        p, _ = P(x2 + 28 + i * cw, sy + 110, c_, 16, cw - 16, 21, 400, MUTED)
        b += p
    b += footer("Concept sheet v0.5 (illustration), drawing set S01–S08, model.mjs; bonus: a rolling boil also disinfects (WHO 2015)")
    add("03_what_it_does", "What the product does", b)


# 04 ---------------------------------------------------------------------------------------
def s04():
    b, _ = hdr(4, "How water moves through it",
               "Top row heats the water, bottom row brings it back down. The exchanger in the middle hands the heat from one row to the other, so the heater only covers the last few degrees.")
    y = 250; h = 740
    sw = 500
    b += card(M, y, sw, h)
    b += img(M + 10, y + 10, sw - 20, h - 20, "img/sect.jpg", fit="meet")
    x = M + sw + 30; w = W - M - x
    fh = 500; iw = fh * 1500 / 678
    b += card(x, y, w, fh + 30)
    b += img(x + (w - iw) / 2, y + 15, iw, fh, "img/flowB2.jpg", fit="meet")
    yy = y + fh + 54
    b += card(x, yy, w, y + h - yy)
    notes = [("Warm-up", "Until the core passes 95 °C the wax gate stays shut. Pumped water climbs the vent standpipe and **overflows back into the jug**: no water reaches the spout for the first part of a run."),
             ("Control without a board", "The wax gate (opens 92–95 °C), the overflow standpipe and two thermal cut-offs on the heater block (130 °C, 152 °C) do all the control."),
             ("Section A-A", "Drawing S01 at 1:2: jug 15 on top, core 7 with heater 8–9 and boil coil 10, exchanger 5, body coil 4 in shell 3, lime drawer 12–14, pump 19 in the base.")]
    cw = (w - 80) / 3
    for i, (t, d) in enumerate(notes):
        xx = x + 28 + i * (cw + 12)
        b += T(xx, yy + 38, t, 18, 600)
        p, _ = P(xx, yy + 66, d, 15.5, cw - 10, 21, 400, MUTED, bfill=INK)
        b += p
    b += footer("Flow diagram from the v0.5 concept sheet (boil coil since changed to 1/2″ × 0.65 m, 61 mL); section from drawing MPx-BLM-S01")
    add("04_how_it_works", "How water moves through it", b)


# 05 ---------------------------------------------------------------------------------------
def s05():
    b, _ = hdr(5, "The simulated cutaway: one run from switch-on",
               "An interactive cutaway driven by the same model: tube heat transfer, heater budget, a lumped warm-up run, and the lime chemistry. 1.2 L/h, 285 mg/L, 25 °C room.")
    shots = [("warm", "Warm-up, gate shut", "Core at 65 °C. The pump runs, but the water overflows back into the jug. Nothing comes out yet."),
             ("prod", "Producing, as drawn", f"First water at **{R['first']:.0f} min**. The jug was heated by the overflow, so water leaves at **{R['outMax']:.0f} °C**, not 27 °C."),
             ("empty", "Jug empty", f"**{R['cup']:.0f} mL** out after **{R['lastWater']:.0f} min**, using **{R['Wh']:.0f} Wh**."),
             ("stat", "With a pump thermostat", f"Proposed fix: the pump waits for a 98 °C core. First water at **{RS['first']:.0f} min**, out at **27 °C**, jug done in {RS['lastWater']:.0f} min.")]
    gap = 24; w = (W - 2 * M - gap * 3) / 4; y = 250; ih = w * 1124 / 800
    ih = min(ih, 560)
    for i, (f, t, d) in enumerate(shots):
        x = M + i * (w + gap)
        b += img(x, y, w, ih, f"img/{f}.jpg", r=12, stroke=LINE)
        b += T(x, y + ih + 38, t, 20, 600, ORANGE if f == "stat" else INK)
        p, h = P(x, y + ih + 70, d, 16, w - 4, 23, 400, MUTED, bfill=INK)
        b += p
    yb = 915
    b += card(M, yb, W - 2 * M, 76, GREY_BG, GREY_BG)
    p, _ = P(M + 28, yb + 45, "**Open it:** Desktop › MPx › BoilLoop_Mini_v0.5 › figure › MPx_BoilLoop_Mini_v05_Cutaway.html. Sliders for flow, hardness, room temperature and the pump thermostat.", 16, W - 2 * M - 56, 23, 400, MUTED, bfill=INK)
    b += p
    b += footer("Screenshots from the v0.5 cutaway at 3 sim-min per second")
    add("05_sim_cutaway", "Simulated cutaway screenshots", b)


# 06 ---------------------------------------------------------------------------------------
def s06():
    b, _ = hdr(6, "What the cutaway reads out",
               "Temperatures at the eight stations, the steady-state numbers, and what this particular run has done so far.")
    y = 250; w = 1120
    sh = w * 174 / 1400; ph = w * 194 / 1400; qh = w * 156 / 1400
    b += label(M, y + 4, "As drawn, 44 min into a run", 13, INK)
    b += img(M, y + 18, w, sh, "img/prod_st.jpg", r=8, stroke=LINE)
    b += img(M, y + 30 + sh, w, ph, "img/prod_panel.jpg", r=8, stroke=LINE)
    y2 = y + 30 + sh + ph + 40
    b += label(M, y2, "With the proposed pump thermostat, 17 min into a run", 13, ORANGE)
    b += img(M, y2 + 14, w, w * 174 / 1400, "img/stat_st.jpg", r=8, stroke=LINE)
    b += img(M, y2 + 26 + w * 174 / 1400, w, qh, "img/stat_panel.jpg", r=8, stroke=LINE)
    x = M + w + 30; w2 = W - M - x
    items = [
        "**Steady state looks good:** 22.5 W heater, exchanger effectiveness 0.949, 27.1 °C out, 3.0 min at the boil, 90 % removal.",
        f"**A real run is different:** the warm-up overflow heats the jug to about 58 °C, so the first water arrives at {R['first']:.0f} min and leaves at {R['outMax']:.0f} °C.",
        f"**The pump thermostat fixes it:** the jug stays at 25 °C, first water at {RS['first']:.0f} min, 27 °C out, and {RS['Wh']:.0f} Wh per jug instead of {R['Wh']:.0f} Wh.",
        "**Station 06** reads 99.5 °C: the crust is caught while the water is still at the boil, as the concept intends."]
    bl, bh_ = bullets(x + 28, y + 86, items, 17, w2 - 56, 14)
    b += card(x, y, w2, bh_ + 100) + label(x + 28, y + 42, "How to read them", 13, INK) + bl
    b += footer("Screenshots from MPx_BoilLoop_Mini_v05_Cutaway.html")
    add("06_sim_readouts", "Cutaway readouts", b)


# 07 ---------------------------------------------------------------------------------------
def s07():
    b, _ = hdr(7, "The calculations behind the numbers",
               "Eight hand-checkable equations from the tube model (tube_sizing_sim.py) and the cutaway model (model.mjs).")
    cards = [
        ("1  Exchanger effectiveness", "ε = (1 − e^{−N(1−C)}) / (1 − C·e^{−N(1−C)})",
         "Counterflow, C_{r} = 0.985; NTU from laminar coil flow with Dean enhancement, 2.4 m of 3/16″ in 3/8″", "ε = 0.949", "At 1.2 L/h; 0.934 at 1.6 L/h."),
        ("2  Heater budget", "P = ṁc_{p}(1−ε)ΔT + ṁ f h_{fg} + UA(T_{b} − T_{a})",
         "5.3 W sensible + 11.3 W steam (1.5 %) + 6.0 W losses\nwithout the exchanger: 121 W", "22.5 W", "A 60 W heater has headroom while running."),
        ("3  Time at the boil", "t = V_{boil} / Q",
         "61 mL ÷ (1.2 L/h = 20 mL/min)", "3.05 min", "Yu et al. boiled for minutes: 3 min is the minimum we set."),
        ("4  Lime formed", "lime = H − 20.3 mg/L",
         "PHREEQC, vented boil at 100 °C\n285 − 20.3 mg/L as CaCO₃", "265 mg/L", "0.13 g of lime per 0.5 L jug into the drawer."),
        ("5  Microplastic removal", "R = 1 − e^{−0.00864 · lime}",
         "Fitted to Yu et al. 2024 (25 % soft, 34 % at 80, 84 % at 180, 90 % at 300 mg/L)\n1 − exp(−2.29) = 0.90", "90 %", "At 80 mg/L: 40 %. Hard water is the whole mechanism."),
        ("6  Outlet temperature", "T_{hot} = T_{j} + (1 − ε)(T_{b} − T_{j})",
         "25 + 0.051 × 74.5 = 28.8 °C leaving the exchanger\nbody coil in the finned shell trims it", "27.1 °C", "Steady state only; the real run starts with a hot jug."),
        ("7  Energy per litre (real run)", "E/V = ∫P dt / V_{out}",
         f"as drawn: {R['Wh']:.0f} Wh ÷ {R['cup'] / 1000:.2f} L\nwith pump thermostat: {RS['Wh']:.0f} Wh ÷ {RS['cup'] / 1000:.2f} L", f"{WH_L:.0f} Wh/L", f"{WH_LS:.0f} Wh/L with the fix. A 90 Wh bank gives 0.7–1.2 L, not 3 L."),
        ("8  What limits flow", "Q ≤ V_{boil} / 3 min ;  P(Q) ≤ 60 W",
         "dwell: 61 mL ÷ 3 min = 1.22 L/h\nheater: P = 60 W at 2.9 L/h", "1.2 L/h max", "15 L/h needs ~580 W and a 750 mL boil coil."),
    ]
    cols, gap = 4, 22
    w = (W - 2 * M - gap * (cols - 1)) / cols; h = 360; y = 252
    for i, (t, f, sub, res, note) in enumerate(cards):
        x = M + (i % cols) * (w + gap); yy = y + (i // cols) * (h + gap)
        b += card(x, yy, w, h)
        b += T(x + 24, yy + 40, t, 18, 600)
        b += rect(x + 24, yy + 60, w - 48, 54, GREY_BG, 8)
        fs = 19
        while fw(f, fs, 500) > w - 72 and fs > 11:
            fs -= 0.5
        b += F(x + 36, yy + 94, f, fs, 500, INK)
        sub2 = sub.replace("_{r}", "r")
        p, ph = P(x + 24, yy + 148, sub2, 15.5, w - 48, 22, 400, MUTED)
        b += p
        b += T(x + 24, yy + 148 + ph + 44, res, 36, 600, RED if i == 7 else ORANGE, ls=-0.5)
        p, _ = P(x + 24, yy + 148 + ph + 76, note, 15.5, w - 48, 21, 400, MUTED)
        b += p
    b += footer("Inputs: v0.5 drawings (tube sizes, 61 mL boil coil), 60 W heater, 1.5 % steam, loss UA 0.08 W/K, PHREEQC lime, Yu et al. 2024")
    add("07_calculations", "Calculations", b)


# 08 ---------------------------------------------------------------------------------------
def s08():
    b, _ = hdr(8, "Result 1 · Flow: 1.2 L/h, a twelfth of our 15 L/h target",
               "Two limits stack up: the 3 minutes at the boil caps flow at 1.22 L/h, and the 60 W heater caps it at 2.9 L/h. Reaching 15 L/h is a different product.")
    y = 250; w = (W - 2 * M - 30) / 2; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Heater power needed vs flow (25 °C water)", 20, 600)
    c = Chart(M + 10, y + 70, w - 30, 515, (0.4, 20), (5, 2000), xlog=True, pad=(80, 20, 30, 64))
    # log y helper
    ylog = lambda v: math.log10(v)
    c.yd = (math.log10(5), math.log10(2000))
    Yl = lambda v: c.Y(math.log10(v))
    for v in [10, 30, 100, 300, 1000]:
        c.parts.append(line(c.px0, Yl(v), c.px1, Yl(v), "#ECEAE4"))
        c.parts.append(T(c.px0 - 10, Yl(v) + 5, f"{v}", 14, 400, MUTED, "end"))
    for v in [0.5, 1, 2, 5, 10, 15, 20]:
        c.parts.append(line(c.X(v), c.py0, c.X(v), c.py0 + 5, FAINT))
        c.parts.append(T(c.X(v), c.py0 + 24, f"{v:g}", 14, 400, MUTED, "middle"))
    c.parts.append(line(c.px0, c.py0, c.px1, c.py0, FAINT, 1.2))
    c.parts.append(T((c.px0 + c.px1) / 2, c.py0 + 50, "flow, L/h (log)", 15, 500, MUTED, "middle"))
    c.parts.append(f'<text transform="translate({c.x + 16},{(c.py0 + c.py1) / 2}) rotate(-90)" font-size="15" font-weight="500" fill="{MUTED}" text-anchor="middle">heater power, W (log)</text>')
    USED[500].update("heater power, W (log)")
    fl = D["flow"]
    # with exchanger: modelled 0.4–3 L/h, extrapolated (eps fit) to 15 L/h
    pts_m = [(f["Q"], f["heater"]) for f in fl if f["Q"] <= 1.8]
    pts_x = [(f["Q"], f["heater"]) for f in fl if f["Q"] >= 1.8] + [(15, A15["heater"])]
    nox = [(f["Q"], f["noX"]) for f in fl] + [(15, A15["noX"]), (20, A15["noX"] * 20 / 15)]
    path = lambda pts, col, sw, dash=None: c.parts.append(f'<path d="M{" L".join(f"{c.X(a):.1f} {Yl(v):.1f}" for a, v in pts)}" fill="none" stroke="{col}" stroke-width="{sw}"{f" stroke-dasharray={chr(34)}{dash}{chr(34)}" if dash else ""}/>')
    path(nox, FAINT, 2.4, "7 6")
    path(pts_m, INK, 3)
    path(pts_x, INK, 2.4, "3 5")
    c.parts.append(line(c.px0, Yl(60), c.px1, Yl(60), RED, 1.4, "6 5") + T(c.X(7), Yl(60) + 20, "60 W heater", 14, 600, RED))
    for q, txt, col in [(1.22, "3 min boil limit", ORANGE), (15, "target 15 L/h", INK)]:
        c.parts.append(line(c.X(q), c.py0, c.X(q), c.py1, col, 1.3, "6 5"))
        c.parts.append(T(c.X(q) + (6 if q < 10 else -6), c.py1 + 16, txt, 14, 600, col, "start" if q < 10 else "end"))
    c.parts.append(f'<circle cx="{c.X(1.2):.1f}" cy="{Yl(S12["heater"]["total"]):.1f}" r="6" fill="{ORANGE}" stroke="#fff" stroke-width="2.5"/>')
    c.parts.append(T(c.X(1.2) + 10, Yl(S12["heater"]["total"]) + 24, "v0.5: 23 W", 15, 600, ORANGE))
    c.parts.append(f'<circle cx="{c.X(15):.1f}" cy="{Yl(A15["heater"]):.1f}" r="6" fill="{RED}" stroke="#fff" stroke-width="2.5"/>')
    c.parts.append(T(c.X(15) - 10, Yl(A15["heater"]) - 12, f"{A15['heater']:.0f} W", 15, 600, RED, "end"))
    c.parts.append(T(c.X(4.5), Yl(330), "no exchanger", 14, 600, MUTED))
    c.parts.append(T(c.X(2.2), Yl(30), "with exchanger", 14, 600, INK))
    b += c.svg()
    bl, _ = bullets(M + 30, y + 636, [
        "The exchanger cuts the heater from 121 W to **23 W** at 1.2 L/h. Above about 1.8 L/h the curve is extrapolated (dotted).",
        f"At 15 L/h even with the exchanger: about **{A15['heater']:.0f} W**, far beyond what USB-C can supply (240 W at most)."], 17, w - 60, 10)
    b += bl
    x = M + w + 30
    b += card(x, y, w, h)
    b += T(x + 30, y + 46, "Litres per hour, compared", 20, 600)
    rows = [("Our requirement 2.1", 15, INK), ("Heater limit (60 W)", D["qmax60"], AMBER), ("v0.5 design flow", 1.2, ORANGE),
            ("Average over a jug, with thermostat", RS["cup"] / 1000 / (RS["lastWater"] / 60), RED), ("Average over a jug, as drawn", R["cup"] / 1000 / (R["lastWater"] / 60), RED)]
    cx0 = x + 360; cx1 = x + w - 70; yy = y + 110; rh = 74
    sc = lambda v: cx0 + v / 16 * (cx1 - cx0)
    for v in [0, 4, 8, 12, 16]:
        b += line(sc(v), yy - 10, sc(v), yy + rh * len(rows), "#EFEDE7")
        b += T(sc(v), yy + rh * len(rows) + 24, f"{v}", 14, 400, MUTED, "middle")
    b += T((cx0 + cx1) / 2, yy + rh * len(rows) + 50, "L/h", 15, 500, MUTED, "middle")
    for i, (k, v, col) in enumerate(rows):
        ry = yy + i * rh
        p, _ = P(x + 30, ry + 22, k, 16, 310, 21, 500, INK)
        b += p
        b += rect(cx0, ry + 4, max(3, sc(v) - cx0), 30, col, 4)
        b += T(sc(v) + 8, ry + 26, f"{v:.2f}" if v < 1 else (f"{v:.1f}" if v < 10 else f"{v:.0f}"), 16, 600, col)
    bl, _ = bullets(x + 30, y + 636, [
        f"Counting warm-up, a 0.5 L jug takes **{R['lastWater']:.0f} min** as drawn ({R['cup'] / 1000 / (R['lastWater'] / 60):.2f} L/h) or **{RS['lastWater']:.0f} min** with the thermostat.",
        "3 L a day (requirement 1.1) means about 2.5 h of running and six jug refills."], 17, w - 60, 10)
    b += bl
    b += footer("model.mjs steady() and run(); ε fit valid to 1.6 L/h, extrapolated beyond")
    add("08_results_flow", "Results: flow", b)


# 09 ---------------------------------------------------------------------------------------
def s09():
    b, _ = hdr(9, "Result 2 · Warm-up decides the first 40 minutes",
               "As drawn, the warm-up overflow returns boiling water to the jug. That delays the first water and makes it come out hot. Starting the pump only when the core is ready fixes both.")
    y = 250; w = (W - 2 * M - 30) / 2; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Water delivered vs time from switch-on", 20, 600)
    c = Chart(M + 10, y + 70, w - 30, 515, (0, 70), (0, 520), pad=(80, 20, 30, 64))
    c.axes([0, 10, 20, 30, 40, 50, 60, 70], [0, 100, 200, 300, 400, 500], "minutes from switch-on", "water out, mL", yfmt=lambda v: f"{v:.0f}")
    c.path([(p[0], p[3]) for p in R["pts"]], INK, 3)
    c.path([(p[0], p[3]) for p in RS["pts"]], ORANGE, 3)
    c.dot(R["first"], 0, INK)
    c.text(R["first"], 0, f"first water {R['first']:.0f} min", 15, 600, INK, "end", -10, -12)
    c.dot(RS["first"], 0, ORANGE)
    c.text(24, 330, "pump thermostat", 15, 600, ORANGE, "end", 0, 0)
    c.text(55, 140, "as drawn", 15, 600, INK)
    b += c.svg()
    bl, _ = bullets(M + 30, y + 636, [
        f"As drawn: **{R['first']:.0f} min** to first water (the concept sheet said about 15), jug finished at **{R['lastWater']:.0f} min**.",
        f"With the thermostat: **{RS['first']:.0f} min** to first water, jug finished at **{RS['lastWater']:.0f} min**."], 17, w - 60, 10)
    b += bl
    x = M + w + 30
    b += card(x, y, w, h)
    b += T(x + 30, y + 46, "Temperatures during the run", 20, 600)
    c = Chart(x + 10, y + 70, w - 30, 515, (0, 70), (20, 105), pad=(80, 20, 30, 64))
    c.axes([0, 10, 20, 30, 40, 50, 60, 70], [20, 40, 60, 80, 100], "minutes from switch-on", "°C", yfmt=lambda v: f"{v:.0f}")
    c.path([(p[0], p[1]) for p in R["pts"]], FAINT, 2, "3 4")
    c.path([(p[0], p[2]) for p in R["pts"]], BLUEW, 2.6)
    outs = [(p[0], p[4]) for p in R["pts"] if p[3] > 1]
    c.path(outs, INK, 3)
    outs2 = [(p[0], p[4]) for p in RS["pts"] if p[3] > 1]
    c.path(outs2, ORANGE, 3)
    c.text(2, 96, "core", 14, 600, MUTED)
    c.text(26, 62, "jug, as drawn", 14, 600, BLUEW)
    c.text(R["first"] + 1, R["outMax"] + 5, "water out, as drawn", 14, 600, INK)
    c.text(12, 23.2, "water out, with thermostat", 14, 600, ORANGE)
    b += c.svg()
    bl, _ = bullets(x + 30, y + 636, [
        f"As drawn, the overflow heats the jug to about 58 °C, so water leaves at up to **{R['outMax']:.0f} °C**: drinkable, but not the 27 °C promised.",
        "With the thermostat the jug stays cold and the outlet holds **27 °C** in a 25 °C room."], 17, w - 60, 10)
    b += bl
    b += footer("model.mjs run(): 1.2 L/h, 285 mg/L, 25 °C, tubes primed from the last run")
    add("09_results_warmup", "Results: warm-up and temperature", b)


# 10 ---------------------------------------------------------------------------------------
def s10():
    b, _ = hdr(10, "Result 3 · Removal depends on the water, energy on the warm-up",
               "Boiling doesn't remove plastic by itself: lime from hard water traps it. And a power bank goes much less far than the concept sheet said.")
    y = 250; w = (W - 2 * M - 30) / 2; h = 740
    b += card(M, y, w, h)
    b += T(M + 30, y + 46, "Microplastic removal vs water hardness", 20, 600)
    c = Chart(M + 10, y + 70, w - 30, 515, (0, 400), (0, 1.0), pad=(80, 20, 30, 64))
    c.zone(0, 80, 0, 1, "#FBEFEC")
    c.axes([0, 100, 200, 300, 400], [0, 0.25, 0.5, 0.75, 1.0], "hardness, mg/L as CaCO₃", "share removed", yfmt=lambda v: f"{v * 100:.0f} %")
    c.hline(0.9, MUTED, "6 5", "90 % (requirement 6.1)", "left", 14, 20)
    c.path(D["removal"], INK, 3)
    for hh, v in [(15, 0.25), (80, 0.34), (180, 0.84), (300, 0.90)]:
        c.parts.append(f'<rect x="{c.X(hh) - 6:.1f}" y="{c.Y(v) - 6:.1f}" width="12" height="12" fill="{ORANGE}" transform="rotate(45 {c.X(hh):.1f} {c.Y(v):.1f})"/>')
    c.text(225, 0.70, "model fit", 15, 600, INK)
    c.text(180, 0.84, "Yu et al. 2024", 15, 600, ORANGE, "end", -14, 6)
    c.dot(285, D["removalAt"]["285"], ORANGE)
    c.text(285, D["removalAt"]["285"], "design point 285", 14, 600, ORANGE, "start", 10, 24)
    c.text(40, 0.05, "soft water", 14, 600, RED, "middle")
    b += c.svg()
    bl, _ = bullets(M + 30, y + 636, [
        "Reaches **90 %** only above about **290 mg/L**. At 180 mg/L the fit gives 75 % (Yu measured 84 %); at 80 mg/L about **40 %**.",
        "So the first test is the hardness of the water we target. The fit stays within about 10 points of Yu's four measurements."], 17, w - 60, 10)
    b += bl
    x = M + w + 30
    b += card(x, y, w, h)
    b += T(x + 30, y + 46, "Litres from a 90 Wh power bank", 20, 600)
    rows = [("Concept sheet claim", 3.0, FAINT), ("Steady state only (23 W at 1.2 L/h)", 90 / (S12["heater"]["total"] / 1.2), AMBER),
            ("Full run, with pump thermostat", 90 / WH_LS, ORANGE), ("Full run, as drawn", 90 / WH_L, RED)]
    cx0 = x + 360; cx1 = x + w - 70; yy = y + 110; rh = 92
    sc = lambda v: cx0 + v / 5 * (cx1 - cx0)
    for v in [0, 1, 2, 3, 4, 5]:
        b += line(sc(v), yy - 10, sc(v), yy + rh * len(rows), "#EFEDE7")
        b += T(sc(v), yy + rh * len(rows) + 24, f"{v}", 14, 400, MUTED, "middle")
    b += T((cx0 + cx1) / 2, yy + rh * len(rows) + 50, "litres per 90 Wh (no converter losses)", 15, 500, MUTED, "middle")
    for i, (k, v, col) in enumerate(rows):
        ry = yy + i * rh
        p, _ = P(x + 30, ry + 24, k, 16, 310, 21, 500, INK)
        b += p
        b += rect(cx0, ry + 6, max(3, sc(v) - cx0), 32, col, 4)
        b += T(sc(v) + 8, ry + 29, f"{v:.1f} L", 16, 600, col)
    bl, _ = bullets(x + 30, y + 636, [
        f"Warm-up costs more than running: **{R['Wh']:.0f} Wh** for one jug as drawn, **{RS['Wh']:.0f} Wh** with the thermostat.",
        "So the power bank use case works best for long runs, not single jugs. Mains USB-C is the realistic supply."], 17, w - 60, 10)
    b += bl
    b += footer("Removal: 1 − e^(−0.00864 · (H − 20.3)), fitted to Yu et al. 2024 (Environ. Sci. Technol. Lett. 11, 273–279)")
    add("10_results_removal_energy", "Results: removal and energy", b)


# 11 ---------------------------------------------------------------------------------------
REQ = [
    (1, "6.1", "Removal ≥ 90 % by count, 1 µm–5 mm (stretch 99 %)", "90 % at 285 mg/L; about 40 % at 80 mg/L; 25 µm mesh catches the crust", "Sim", "partial"),
    (2, "3.2", "Filter medium sheds no secondary micro/nanoplastic", "Steel mesh and tubes; but the PharMed pump tube wears in the water path", "Design", "risk"),
    (3, "6.2", "Detection false +/− ≤ 10 % vs reference microscopy", "No detection in this concept; would pair with C05", "—", "na"),
    (4, "10.2", "Captured microplastics stay contained", "Lime crust in the drawer; rinsing it into a sink releases it", "Design", "risk"),
    (5, "4.1", "Result through ≥ 1 user feedback channel", "Dial thermometer only; no microplastic information", "Design", "fail"),
    (6, "11.1", "Retail price ₹1,500–6,000", "v0.5 not costed; v0.4 BOM implied ₹6,650 retail, v0.5 adds a pump", "BOM", "risk"),
    (7, "3.1", "Water-contact parts food-contact safe", "316L, borosilicate, FDA silicone, PharMed tube", "Spec", "design"),
    (7, "3.4", "No leachables above IS 10500", "316L at 100 °C plus citric descale; not tested", "Spec", "design"),
    (9, "2.1", "Flow rate ≥ 15 L/h", "1.2 L/h (0.45–0.84 L/h including warm-up)", "Sim", "fail"),
    (9, "1.1", "Per-use capacity for 1–3 L/day", "3 L takes about 2.5 h and six refills of the 0.5 L jug", "Sim", "partial"),
    (9, "10.1", "Disposal pathway for spent filters (W)", "Steel mesh is reusable; lime + plastic catch has no defined route", "—", "open"),
    (9, "1.2", "Non-destructive sampling (W)", "Drawer catch can be sampled, but the plastic is locked in lime", "Design", "partial"),
    (9, "5.3", "Display legible outdoors (W)", "No display; dial thermometer", "—", "na"),
    (14, "9.1", "Filter rated ≥ 100 L or 3 months", "Mesh reusable; cartridge clogging and tube scaling not modelled", "—", "open"),
    (14, "7.1", "Filter swap tool-free in ≤ 30 s", "Twist-out drawer; not timed", "Design", "design"),
    (14, "4.2", "Alert near filter end-of-life", "None", "Design", "fail"),
    (14, "5.2", "Spout parts detachable and washable", "Spout is a fixed steel tube", "Design", "fail"),
    (14, "8.2", "Usable at 5–45 °C", "Steady outlet = room + 2 °C; shell stays near room temperature", "Sim", "pass"),
    (19, "3.3", "Housing UV and impact resistant (W)", "Aluminium shell; glass jug on top", "Design", "partial"),
    (19, "3.5", "Survives 1 m drop (W)", "2.7 kg with a glass jug; not tested", "—", "risk"),
    (21, "5.1", "Actuation force ≤ 50 N (W)", "No manual actuation", "Design", "met"),
    (21, "8.1", "Noise ≤ 60 dB(A) (W)", "Peristaltic pump + boiling; not measured", "—", "open"),
]


def s11():
    b, _ = hdr(11, "Our 22 technical requirements: what Boil-Loop meets and what it doesn't",
               "Ranked by our weighted objective tree. **Pass · sim**: the simulation shows it. **By design**: the choice should meet it, but nothing has tested it yet.")
    y = 238; cnt = {}
    for r in REQ:
        cnt[r[5]] = cnt.get(r[5], 0) + 1
    xx = M
    for k in ["pass", "met", "design", "partial", "fail", "risk", "open", "na"]:
        t, fg, bg = STATUS[k]
        cs, cw = chip(xx, y, f"{t}  {cnt.get(k, 0)}", fg, bg, 15, 32)
        b += cs
        xx += cw + 10
    cols = [("Rank", 70), ("#", 64), ("Requirement", 560), ("Boil-Loop v0.5 result", 660), ("Checked by", 140), ("Status", 266)]
    ty = 270
    b += rect(M, ty, W - 2 * M, 36, GREY_BG, 6)
    cx = M + 14; xs = []
    for k, cw in cols:
        xs.append(cx); b += T(cx, ty + 24, k, 14, 600, MUTED); cx += cw
    rh = 29.4
    for i, (rank, num, req, res, how, st) in enumerate(REQ):
        ry = ty + 36 + i * rh
        if i % 2:
            b += rect(M, ry, W - 2 * M, rh, "#FAF9F6")
        base = ry + rh / 2 + 6
        b += T(xs[0], base, str(rank), 16, 500, MUTED) + T(xs[1], base, num, 16, 600, INK) + T(xs[2], base, req, 16, 500, INK)
        fz = 16
        while tw(res, fz) > cols[3][1] - 16:
            fz -= 0.5
        b += T(xs[3], base, res, fz, 400, MUTED) + T(xs[4], base, how, 15, 400, MUTED)
        t, fg, bg = STATUS[st]
        cs, _ = chip(xs[5], ry + rh / 2, t, fg, bg, 13, 22)
        b += cs
        if rank in (5, 9, 19) and (i == 0 or REQ[i - 1][0] != rank):
            b += line(M, ry, W - M, ry, "#CFCDC6", 1.2)
    yb = ty + 36 + len(REQ) * rh + 16
    p, _ = P(M, yb + 14, "Only one Tier 1 item is even partly met, and only in hard water. Flow (2.1) misses by 12×. Detection (6.2, 4.1) is outside this concept.", 17, W - 2 * M, 24, 400, MUTED, bfill=INK)
    b += p
    b += footer("Requirements: MPx_Weighted_Objective_Tree.docx (22 items, D/W). W = wish")
    add("11_requirements_team_list", "Requirements met and not met", b)


# 12 ---------------------------------------------------------------------------------------
def s12():
    b, _ = hdr(12, "What the simulation proves, and what only a bench can",
               "The heat side is well modelled and mostly passes. The chemistry, the scaling and the shedding are assumptions until we boil real water.")
    y = 250; lw = 820
    b += card(M, y, lw, 740)
    b += label(M + 28, y + 40, "Engineering checks from the models", 13, INK)
    checks = [("pass", "Heater at 1.2 L/h", "22.5 W of 60 W"), ("pass", "Steady outlet, 25 °C room", "27.1 °C"), ("pass", "Shell surface", "26.8 °C, safe to hold"),
              ("pass", "Time at the boil", "3.05 min ≥ 3"), ("pass", "Unboiled water blocked", "wax gate shut below 92 °C"), ("pass", "Removal at 285 mg/L", "90 %"),
              ("fail", "Removal at 80 mg/L", "40 %"), ("fail", "Flow", "1.2 L/h vs 15"), ("fail", "First water, as drawn", f"{R['first']:.0f} min vs ~15 claimed"),
              ("fail", "Outlet in a real run, as drawn", f"{R['outMax']:.0f} °C"), ("fail", "90 Wh power bank", f"{90 / WH_L:.1f} L vs 3 L claimed"), ("fail", "Mass", "2.73 kg vs 1.3 kg claimed")]
    ty = y + 66
    b += rect(M + 16, ty, lw - 32, 34, GREY_BG, 6)
    b += T(M + 28, ty + 23, "Check", 14, 600, MUTED) + T(M + 400, ty + 23, "Result", 14, 600, MUTED) + T(M + lw - 130, ty + 23, "Status", 14, 600, MUTED)
    for i, (st, k, v) in enumerate(checks):
        ry = ty + 34 + i * 44
        if i % 2:
            b += rect(M + 16, ry, lw - 32, 44, "#FAF9F6")
        b += T(M + 28, ry + 28, k, 16, 500, INK) + T(M + 400, ry + 28, v, 16, 400, MUTED)
        t, fg, bg = STATUS[st]
        cs, _ = chip(M + lw - 130, ry + 22, "pass" if st == "pass" else "fail", fg, bg, 13, 24)
        b += cs
    x = M + lw + 30; w = W - M - x
    b += card(x, y, w, 740)
    b += label(x + 28, y + 40, "Assumptions to replace with measurements", 13, INK)
    cols = [("Assumption", 270), ("Value used", 190), ("Drives", 150), ("Bench test", 230)]
    rows = [("Lime formed in a vented boil", "H − 20.3 mg/L (PHREEQC)", "Removal (6.1)", "1 · hardness before and after, our tap and borewell water"),
            ("Removal vs lime", "Yu et al. fit, kettle + mesh", "Removal (6.1)", "2 · PS bead or Nile red count, boiled vs not"),
            ("3 min is enough", "dwell = 3.05 min", "Removal, flow", "3 · run 2, 4 and 6 min"),
            ("Exchanger ε with Dean flow", "0.949 at 1.2 L/h", "Heater, outlet", "4 · thermocouples on all four ports"),
            ("Steam 1.5 %, loss 0.08 W/K", "11 W + 6 W", "Heater, energy", "4 · power meter on USB-C"),
            ("Tube and mesh scaling", "not modelled", "Life (9.1), flow", "5 · 50 L run, weigh scale, pressure"),
            ("Pump tube shedding", "not modelled", "Shedding (3.2)", "6 · blank run, count particles out")]
    cx = x + 28; xs = []
    for k, cw in cols:
        xs.append(cx); cx += cw
    ty = y + 66
    b += rect(x + 16, ty, w - 32, 34, GREY_BG, 6)
    for (k, _), xx in zip(cols, xs):
        b += T(xx, ty + 23, k, 14, 600, MUTED)
    ry = ty + 34
    for i, r in enumerate(rows):
        parts, hs = "", []
        for j, (val, (k, cw)) in enumerate(zip(r, cols)):
            p, hh = P(xs[j], ry + 28, val, 15.5, cw - 18, 21, 600 if j == 0 else 400, INK if j in (0, 3) else MUTED)
            parts += p; hs.append(hh)
        rh = max(hs) + 22
        if i % 2:
            b += rect(x + 16, ry, w - 32, rh, "#FAF9F6")
        b += parts
        ry += rh
    b += rect(x + 16, y + 740 - 132, w - 32, 116, ORANGE_BG, 10)
    b += label(x + 40, y + 740 - 96, "CED lecture 9: three kinds of simulation", 13, ORANGE)
    b += status_icon(x + 52, y + 740 - 52, "done") + T(x + 72, y + 740 - 46, "Analytical (slide 7)", 17, 600)
    b += status_icon(x + 282, y + 740 - 52, "done") + T(x + 302, y + 740 - 46, "Virtual (slides 5–6)", 17, 600)
    b += status_icon(x + 512, y + 740 - 52, "now") + T(x + 532, y + 740 - 46, "Physical: tests 1–6, next", 17, 600)
    b += footer("tube_sizing_sim.py (CoolProp properties), model.mjs (transient), PHREEQC chemistry from the v0.2 study")
    add("12_validated_vs_not", "What the simulation proves", b)


# FMEA -------------------------------------------------------------------------------------
FMEA = [
    ("Water chemistry", "Removal collapses in soft water", "User thinks the water is clean; 25–40 % removed", "Target water below ~150 mg/L hardness", "Note on the concept sheet", 7, 8, 8, "Hardness strip in the box; show expected removal per hardness; test a calcium-dosing cartridge", 4, 8, 3, "6.1"),
    ("Drawer rinse", "Caught crust rinsed into the sink", "Microplastics go back to the environment", "Twist-out drawer is rinsed under a tap", "None", 8, 6, 8, "Dissolve the crust in citric acid in a cup, filter on paper, dry and bin", 3, 6, 4, "10.2"),
    ("Pump tube (PharMed)", "Tube wear sheds particles", "The purifier adds polymer particles", "Rollers abrade the tube every turn; spallation", "Pump on the cold side", 6, 7, 8, "Steel diaphragm or gear pump, or gravity feed (v0.4); blank-water shedding test", 3, 7, 5, "3.2"),
    ("Mini tubes and boil coil", "Lime scales the walls", "Flow drops, heater overheats, pump stalls", "The same lime that traps plastic deposits on hot walls", "None", 8, 6, 6, "Automatic citric-acid descale cycle; smooth 316L; pressure check on the pump", 4, 6, 4, "9.1"),
    ("Boil dwell", "Too little time at the boil", "Less lime forms, removal falls", "Flow set high; scale shrinks coil volume", "Fixed pump speed", 5, 7, 7, "Lock flow at ≤ 1.2 L/h; dwell test at 2/4/6 min", 3, 7, 5, "6.1"),
    ("Wax gate", "Sticks open", "Unboiled water reaches the spout", "Wax actuator failure; lime on the seat", "None", 3, 8, 8, "Gate after the mesh, away from lime; cycle test; dial check in the manual", 2, 8, 5, "6.1"),
    ("Tube joints (30+ fittings)", "Hot leak", "Hot water in the base near electrics", "Thermal cycling of compression fittings", "20 kPa leak test", 5, 7, 5, "Brazed joints in production; drip path away from electrics", 2, 7, 4, "3.5"),
    ("Tubes between runs", "Stagnant water grows biofilm", "Odour; first water from the cold side not boiled", "Tubes stay primed between uses", "Next run boils it", 5, 5, 6, "Drain mode; first 60 mL to waste", 3, 5, 3, "3.1"),
    ("316L at 100 °C", "Metal leaching after descale", "Ni/Cr above IS 10500", "Acid descale, weld tint, poor passivation", "316L", 3, 8, 6, "Passivate after descale; leach test after 20 cycles", 1, 8, 4, "3.4"),
    ("Lime-trap cartridge", "Mesh clogs", "Back-pressure, overflow, no output", "~0.13 g of lime per jug at 285 mg/L", "Twist-out rinse", 7, 5, 4, "Size the cartridge for a week; overflow is the visible cue", 4, 5, 3, "9.1"),
    ("Mini-tube heater", "Steam bursts in the 1/8″ coil", "Hot water spurts from the vent or spout", "Boiling in a 3 mm tube", "Boil only in the vented coil", 4, 8, 4, "Cap heater-coil outlet at ~98 °C; vent splash guard", 2, 8, 3, "—"),
    ("Vent and cap", "Steam on the hand", "Scald when lifting the jug", "Vent standpipe exits at the top", "Insulated core", 4, 8, 3, "Vent shield; cool-touch cap", 2, 8, 3, "—"),
    ("Power bank use", "Runs out early", "Only ~0.7 L per 90 Wh", "Warm-up energy", "None", 8, 4, 3, "Pump thermostat (~1.2 L); market as mains USB-C", 5, 4, 3, "1.1"),
    ("Warm-up overflow", "Jug heats; first water late and hot", "38 min wait; 45 °C out", "Overflow returns ~100 °C water to the jug", "None", 9, 5, 2, "KSD301 98 °C pump thermostat: 9 min, 27 °C", 2, 5, 2, "8.2"),
    ("Dial thermometer", "Reads high or drifts", "User trusts unboiled water", "Bimetal drift", "None", 3, 5, 6, "Calibrate at the boil; gate is the real safeguard", 2, 5, 4, "4.1"),
    ("Heater, jug empty", "Dry boil", "Smell; scale baked on", "Pump keeps running dry", "130 °C KSD301 + 152 °C TCO", 8, 4, 2, "Pump stops with the heater cut-off", 4, 4, 2, "—"),
    ("Glass jug", "Breaks", "Cuts, spill", "Drop, knock", "Borosilicate 3.3", 4, 7, 2, "Steel jug option with a sight window", 2, 7, 2, "3.5"),
    ("Whole unit", "Tips over while hot", "Hot spill", "388 mm tall on a 170 × 120 base", "None", 3, 7, 2, "Wider base; tilt switch on the heater", 2, 7, 2, "3.5"),
    ("USB-C supply", "Under-powered charger", "Never reaches the boil; no water", "45 W charger or PD at 15 V", "20 V PD trigger", 5, 4, 3, "LED for 20 V; 65 W on the box", 2, 4, 2, "—"),
    ("Flow", "1.2 L/h for a household", "Too slow for daily use", "3 min dwell, 60 W heater", "None", 10, 5, 1, "Not fixable within the concept; reposition as a slow batch purifier", 10, 5, 1, "2.1"),
]


def rn(r): return r[5] * r[6] * r[7]
def rn2(r): return r[9] * r[10] * r[11]


FMEA.sort(key=lambda r: -rn(r))
NCRIT = sum(1 for r in FMEA if rn(r) > 125)


def s13():
    b, _ = hdr(13, "Design FMEA: method",
               "Pahl & Beitz §10.4: list how each part and use step can fail, what the user notices, and why. Then rate, rank and fix.")
    y = 240
    steps = [("1", "Risk analysis", "Failures, consequences, causes; measures that avoid or detect them"),
             ("2", "Risk assessment", "Rate occurrence O, severity S, and detection D (easy to detect = low D)"),
             ("3", "Risk number", "RN = O × S × D, from 1 to 1000. **RN > 125 is critical**"),
             ("4", "Risk minimisation", "Design change for each critical item, then re-rate for a new RN")]
    w = (W - 2 * M - 3 * 22) / 4
    for i, (n, t, d) in enumerate(steps):
        x = M + i * (w + 22)
        b += card(x, y, w, 156) + num_badge(x + 40, y + 44, n, 20, ORANGE, size=18) + T(x + 74, y + 52, t, 22, 600)
        p, _ = P(x + 28, y + 100, d, 17, w - 56, 24, 400, MUTED, bfill=INK)
        b += p
    y2 = y + 178
    scales = [("Occurrence O", [("1–2", "Unlikely: a design feature prevents it"), ("3–4", "Occasional"), ("5–6", "Likely over a year of use"), ("7–8", "Frequent: most users, often"), ("9–10", "Certain: the simulation shows it every time")]),
              ("Severity S", [("1–2", "User barely notices"), ("3–4", "Slower or less convenient"), ("5–6", "Function degraded"), ("7–8", "Hygiene risk, scald or contaminant released"), ("9–10", "Untreated water delivered as treated")]),
              ("Detection D", [("1–2", "Obvious at once"), ("3–4", "User notices within a use"), ("5–6", "Found only by inspection or test"), ("7–8", "Hidden from the user"), ("9–10", "Cannot be detected")])]
    w3 = (W - 2 * M - 2 * 22) / 3
    for i, (t, rows) in enumerate(scales):
        x = M + i * (w3 + 22)
        b += card(x, y2, w3, 282) + T(x + 28, y2 + 42, t, 20, 600)
        for j, (k, v) in enumerate(rows):
            ry = y2 + 82 + j * 42
            shade = ["#EAF4ED", "#F3F2EE", "#F8EBCF", "#FCE7DD", "#FADFDB"][j]
            b += rect(x + 28, ry - 20, 62, 30, shade, 6) + T(x + 59, ry + 1, k, 15, 600, INK, "middle") + T(x + 104, ry + 1, v, 16, 400, INK)
    y3 = y2 + 304
    b += card(M, y3, W - 2 * M, 150)
    b += label(M + 30, y3 + 38, "Worked example: water chemistry", 13, INK)
    r0 = FMEA[0]
    cells = [("Failure", r0[1]), ("Effect", "User thinks the water is clean"), ("Cause", "Soft target water"),
             ("Rating", f"O {r0[5]} × S {r0[6]} × D {r0[7]}"), ("RN", f"{rn(r0)} · critical"), ("Action", "Hardness strip + removal estimate"), ("New RN", f"{r0[9]} × {r0[10]} × {r0[11]} = {rn2(r0)}")]
    cw = (W - 2 * M - 60) / len(cells)
    for i, (k, v) in enumerate(cells):
        x = M + 30 + i * cw
        b += T(x, y3 + 76, k, 14, 600, MUTED)
        col = RED if k == "RN" else (GREEN if k == "New RN" else INK)
        p, _ = P(x, y3 + 104, v, 17, cw - 24, 22, 600 if k in ("RN", "New RN", "Rating") else 400, col)
        b += p
        if i:
            b += line(x - 14, y3 + 62, x - 14, y3 + 128, LINE)
    y4 = y3 + 172
    b += card(M, y4, W - 2 * M, 990 - y4, ORANGE_BG, "#F4C9B5")
    p, _ = P(M + 30, y4 + 36, f"**Scope:** v0.5 as drawn (jug, pump, exchanger, heater, boil coil, lime drawer, wax gate, body coil, electrics) and three use steps (warm-up, producing, cleaning). **20 failure modes, {NCRIT} critical.** "
             "Ratings use the model where it gives numbers; the rest is judgement for the team to review.", 17, W - 2 * M - 60, 24, 400, INK)
    b += p
    b += footer("Pahl & Beitz, Engineering Design 3e (2007), §10.4 and Fig. 10.11; CED lecture 2, slide 36")
    add("13_fmea_method", "FMEA method", b)


def fmea_table(n, rows, start, title, sub):
    b, _ = hdr(n, title, sub)
    cols = [("#", 38), ("Part / function", 176), ("Failure mode", 190), ("Effect on user", 200), ("Cause", 212), ("Current control", 150),
            ("O", 36), ("S", 36), ("D", 36), ("RN", 62), ("Recommended action", 380), ("New RN", 86), ("Req.", 56)]
    x = M; xs = []
    for k, cw in cols:
        xs.append(x); x += cw
    ty = 246
    b += rect(M - 8, ty, W - 2 * M + 16, 38, INK, 6)
    for (k, cw), xx in zip(cols, xs):
        anc = "middle" if k in ("O", "S", "D", "RN", "New RN") else "start"
        b += T(xx + (cw / 2 if anc == "middle" else 6), ty + 25, k, 14, 600, "#fff", anc)
    ry = ty + 38
    for i, r in enumerate(rows):
        parts, hs = "", []
        for j, t in enumerate(r[:5]):
            k, cw = cols[j + 1]
            p, h = P(xs[j + 1] + 6, ry + 27, t, 15, cw - 16, 20, 600 if j == 0 else 400, INK if j < 2 else MUTED)
            parts += p; hs.append(h)
        p, h = P(xs[10] + 6, ry + 27, r[8], 15, cols[10][1] - 16, 20, 400, INK)
        parts += p; hs.append(h)
        rh = max(hs) + 16
        if i % 2:
            b += rect(M - 8, ry, W - 2 * M + 16, rh, "#FAF9F6")
        b += parts + T(xs[0] + 6, ry + 27, str(start + i), 15, 600, MUTED)
        for j, v in zip((6, 7, 8), (r[5], r[6], r[7])):
            b += T(xs[j] + 18, ry + 27, str(v), 16, 500, INK, "middle")
        R_ = rn(r); crit = R_ > 125
        cs, _ = chip(xs[9] + 4, ry + 21, f"{R_}", "#fff" if crit else INK, RED if crit else GREY_BG, 15, 26)
        b += cs
        cs, _ = chip(xs[11] + 12, ry + 21, f"{rn2(r)}", GREEN if rn2(r) <= 125 else RED, GREEN_BG if rn2(r) <= 125 else RED_BG, 15, 26)
        b += cs + T(xs[12] + 6, ry + 27, r[12], 14, 600, MUTED)
        ry += rh
        b += line(M - 8, ry, W - M + 8, ry, "#ECEAE4")
    return b, ry


def s14():
    b, _ = fmea_table(14, FMEA[:10], 1, "Design FMEA (1/2): the ten highest risks",
                      "Sorted by risk number. Red RN is critical (> 125). New RN is the re-rating once the action is in the design.")
    b += footer("O occurrence · S severity · D detection, 1–10 each; RN = O × S × D. Draft ratings, for team review")
    add("14_fmea_table_1", "FMEA table 1", b)


def s15():
    b, ry = fmea_table(15, FMEA[10:], 11, "Design FMEA (2/2): the remaining ten",
                       "One more critical item: steam bursts. The flow row shows where RN falls short: a certain, obvious failure scores low.")
    b += card(M, ry + 26, W - 2 * M, 92, GREY_BG, GREY_BG)
    p, _ = P(M + 28, ry + 62, "**Why flow scores only 50:** it happens every time (O 10) but everyone notices at once (D 1), so the RN is low. "
             "FMEA ranks hidden risks; it doesn't judge whether the concept meets its requirements. That is what slide 11 does.", 17, W - 2 * M - 56, 24, 400, MUTED, bfill=INK)
    b += p
    b += footer("O occurrence · S severity · D detection, 1–10 each; RN = O × S × D. Draft ratings, for team review")
    add("15_fmea_table_2", "FMEA table 2", b)


def s16():
    b, _ = hdr(16, f"FMEA result: {NCRIT} critical risks, mostly chemistry and hygiene",
               "The heat side is in good shape. The risks are in what the water does to the device (scale) and what the device could add to the water (pump tube, leaching).")
    y = 250; w = 1060
    b += card(M, y, w, 740) + T(M + 30, y + 46, "Risk number per failure mode, before → after", 20, 600)
    x0 = M + 380; x1 = M + w - 50
    sc = lambda v: x0 + v / 500 * (x1 - x0)
    top = y + 92; rh = 30
    for v in [0, 100, 200, 300, 400, 500]:
        b += line(sc(v), top - 8, sc(v), top + rh * 20, "#EFEDE7") + T(sc(v), top + rh * 20 + 22, str(v), 14, 400, MUTED, "middle")
    b += line(sc(125), top - 20, sc(125), top + rh * 20, RED, 1.4, "6 5") + T(sc(125) + 6, top - 18, "critical > 125", 14, 600, RED)
    for i, r in enumerate(FMEA):
        yy = top + i * rh
        b += T(M + 30, yy + 19, str(i + 1), 14, 600, MUTED) + T(M + 58, yy + 19, r[1], 14, 500, INK)
        R_, R2 = rn(r), rn2(r)
        b += rect(x0, yy + 6, sc(R_) - x0, 18, RED if R_ > 125 else "#C9C6BE", 3)
        b += f'<circle cx="{sc(R2):.1f}" cy="{yy + 15}" r="7" fill="{GREEN}" stroke="#fff" stroke-width="2"/>'
        b += T(sc(R_) + 8, yy + 20, str(R_), 13, 600, RED if R_ > 125 else MUTED)
    ly = y + 740 - 26
    b += rect(M + 30, ly - 11, 24, 12, RED, 3) + T(M + 62, ly, "RN now", 14, 500, MUTED)
    b += f'<circle cx="{M + 162}" cy="{ly - 5}" r="7" fill="{GREEN}"/>' + T(M + 176, ly, "RN after the action", 14, 500, MUTED)
    x = M + w + 30; w2 = W - M - x
    b += card(x, y, w2, 740) + label(x + 28, y + 42, "Changes for a v0.6, in priority order", 13, INK)
    acts = [("Hardness gate", "Strip test in the box and a removal estimate per hardness (6.1)"),
            ("Crust disposal", "Citric-acid dissolve, paper filter, dry and bin (10.2)"),
            ("Pump without a wearing tube", "Steel diaphragm or gear pump, or gravity feed as in v0.4 (3.2)"),
            ("Automatic descale cycle", "Citric acid through the coils on a schedule (9.1)"),
            ("Pump thermostat", "KSD301 98 °C: first water in 9 min at 27 °C"),
            ("Flow lock and gate placement", "≤ 1.2 L/h; wax gate after the mesh"),
            ("Brazed joints, drain mode", "Fewer leak paths; no stagnant water"),
            ("Steam shield, wider base, 65 W label", "")]
    yy = y + 88
    for i, (t, d) in enumerate(acts):
        b += num_badge(x + 42, yy - 6, i + 1, 14, ORANGE if i < 5 else INK, size=13)
        p, h = P(x + 68, yy, t, 18, w2 - 96, 24, 600)
        b += p
        if d:
            p2, h2 = P(x + 68, yy + h + 2, d, 15.5, w2 - 96, 21, 400, MUTED)
            b += p2; h += h2 + 2
        yy += h + 16
    b += rect(x + 16, y + 740 - 136, w2 - 32, 120, ORANGE_BG, 10)
    p, _ = P(x + 40, y + 740 - 96, "**None of these fixes the flow.** After the actions every RN is at or below 105, but 1.2 L/h remains. That is a product decision, not an FMEA one.", 16.5, w2 - 80, 23, 400, INK)
    b += p
    b += footer(f"All 20 failure modes re-rated to ≤ {max(rn2(r) for r in FMEA)} after the actions; ratings to be confirmed by bench tests 1–6")
    add("16_fmea_result", "FMEA result", b)


def s17():
    b, _ = hdr(17, "Next steps: two cheap tests decide whether to continue",
               "The heat side is proven on paper. Before spending on v0.6, boil our own water and decide whether 1.2 L/h is acceptable.")
    y = 252
    phases = [("Week 1", "Hardness of our water", ["Strip or EDTA titration: IISc tap, borewell, packaged", "If < ~200 mg/L: removal < 80 %"], ORANGE),
              ("Week 1", "Decide on flow", ["Is 1.2 L/h acceptable as a slow, overnight purifier?", "If not: stop or rethink"], ORANGE),
              ("Week 2", "Kettle bench test", ["Boil 2/4/6 min, filter on 25 µm mesh", "Count with Nile red, boiled vs not"], INK),
              ("Week 2–3", "Heat-side rig", ["Tube-in-tube + heater on a bench PSU", "Measure ε, power, warm-up"], INK),
              ("Week 4", "Close the loop", ["Measured values into model.mjs", "Re-run requirements and FMEA"], INK),
              ("Then", "v0.6 or stop", ["v0.6 with the FMEA changes", "or keep as a lab method for C05 samples"], MUTED)]
    n = len(phases); gap = 18; w = (W - 2 * M - gap * (n - 1)) / n
    for i, (wk, t, items, col) in enumerate(phases):
        x = M + i * (w + gap)
        b += card(x, y, w, 300) + rect(x, y, w, 8, col, 0) + label(x + 24, y + 46, wk, 13, col if col != MUTED else FAINT)
        p, h = P(x + 24, y + 82, t, 22, w - 48, 27, 600)
        b += p
        bl, _ = bullets(x + 24, y + 98 + h + 12, items, 16, w - 48, 8, col if col != MUTED else FAINT)
        b += bl
    y2 = y + 324
    b += card(M, y2, W - 2 * M, 990 - y2) + label(M + 30, y2 + 42, "Bench tests: what each one measures, and the requirement it settles", 13, INK)
    tests = [("1", "Hardness before and after boiling", "lime actually formed", "6.1"), ("2", "Nile red count, boiled vs unboiled", "real removal on our water", "6.1, 1.2"),
             ("3", "Boil for 2, 4 and 6 min", "minimum time at the boil", "6.1, 2.1"), ("4", "Thermocouples + USB-C power meter", "ε, heater power, warm-up", "2.1, 1.1"),
             ("5", "50 L endurance run", "scale on tubes and mesh, pressure", "9.1"), ("6", "Blank-water run through the pump", "particles shed by the pump tube", "3.2"),
             ("7", "Leach test after 20 descales", "metals vs IS 10500", "3.4"), ("8", "Drop, tip and leak checks", "joints, jug, stability", "3.5")]
    cw = (W - 2 * M - 60) / 4
    for i, (n_, t, m_, r) in enumerate(tests):
        x = M + 30 + (i % 4) * cw; yy = y2 + 100 + (i // 4) * 150
        b += num_badge(x + 16, yy - 6, n_, 16, INK, size=15)
        p, h = P(x + 44, yy, t, 18, cw - 70, 24, 600)
        b += p
        p, h2 = P(x + 44, yy + h + 4, f"Measures {m_}", 16, cw - 70, 22, 400, MUTED)
        b += p
        cs, _ = chip(x + 44, yy + h + h2 + 18, f"settles {r}", ORANGE, ORANGE_BG, 13, 24)
        b += cs
    b += footer("Tests 1–3 need only a kettle, a mesh and the Nile red kit already planned for C05")
    add("17_next_steps", "Next steps", b)


for f in [s01, s02, s03, s04, s05, s06, s07, s08, s09, s10, s11, s12, s13, s14, s15, s16, s17]:
    f()
css = font_css()
os.makedirs("out", exist_ok=True)
for fn, title, body in SL:
    open(f"out/MPx_BoilLoop_v05_{fn}.svg", "w").write(document(body, css, title))
print(len(SL), "slides; critical", NCRIT, "max new RN", max(rn2(r) for r in FMEA))
for r in FMEA:
    print(rn(r), rn2(r), r[0], "|", r[1])
